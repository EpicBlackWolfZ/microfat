# Retained hosted selector characterizations

Source: 39a7fccc97061b588a9ef17bc104ebcbb328aa89.
Run: 40111512777, attempt 1. Each architecture is a separate fixed cohort.
Each contains 304 selector benchmark rows and 32 current-only process-context
rows, with eight reported repetitions per group. Both cohorts are complete and
both unchanged adoption gates fail. The production selector is retained.

The ten raw `selection-study/` files per architecture were extracted only after
validating the original runtime artifact ZIP's GitHub SHA-256 digest and byte
size. The per-architecture independent audit verifies each selected raw member
against that original ZIP. Full runtime ZIPs remain in the local research output;
this archive retains their exact metadata, digest/fetch ledger and the complete
selection-study subsets. It does not contain the unrelated runtime binaries.

`protocol.md` is the unchanged prospective hosted protocol. Per-architecture
JSON/Markdown summaries retain every fixture, expected error, raw benchmark row,
iteration count, median/range, B/op, allocs/op and gate outcome. No observations
were trimmed, replaced or pooled. These descriptive repeated microbenchmarks
establish no population confidence interval or candidate-attributable launch or
service-p99 effect. Hosted machines and readable cgroups do not establish host
isolation or an imposed memory limit. Compiler/tool hashes are observations;
compiler binaries are not provided for independent hash replay.

To replay, extract to a directory of your choice. Verify `MANIFEST.sha256` from
that directory. From a microfat Git checkout containing the frozen source object,
run the following, substituting the absolute extraction path:

```bash
node /absolute/extraction/path/analyze-hosted.cjs amd64 /absolute/extraction/path/amd64/selection-study
node /absolute/extraction/path/analyze-hosted.cjs arm64 /absolute/extraction/path/arm64/selection-study
```

No benchmark or payload is executed. Source verification uses `git show` against
the exact frozen commit. The replay emits `complete: true` and both gate fields
false for each retained cohort. An incomplete verification exits nonzero; this
exit behavior is the only change from the original collection-side analyzer.

`qualification/` preserves the initial run's full job conclusions and the
separate ARM64 Homebrew failure: installed v0.3.0 checking release v0.2.5 received
HTTP 403. Its original 5,023-byte failure artifact ZIP and metadata are retained,
with a short job-log excerpt. Both native runtime jobs succeeded; the initial
overall run and dependent `CI Complete` failed because Homebrew failed. Final-head
source qualification is a separate CI run after evidence retention and removal
of the temporary timing step. No new timing cohort is created by that cleanup.
