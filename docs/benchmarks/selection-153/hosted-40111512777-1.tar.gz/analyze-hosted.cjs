const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const expectedSource = '39a7fccc97061b588a9ef17bc104ebcbb328aa89';
const arch = process.argv[2];
assert.ok(['amd64', 'arm64'].includes(arch));
const dir = path.resolve(process.argv[3]);
const outputDir = path.dirname(dir);
const read = name => fs.readFileSync(path.join(dir, name), 'utf8');
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const median = values => {
  const sorted = [...values].sort((a,b) => a-b);
  const mid = Math.floor(sorted.length/2);
  return sorted.length%2 ? sorted[mid] : (sorted[mid-1]+sorted[mid])/2;
};
const stats = values => ({median:median(values),min:Math.min(...values),max:Math.max(...values)});
const fixtures = ['amd64_sparse','amd64_dense','amd64_cap','amd64_disable','amd64_force','amd64_normalization',
  'amd64_unknown','amd64_unavailable','arm64_sparse_v8_0','arm64_sparse_v8_2','arm64_sparse_v9_0_no_v8_9',
  'arm64_dense_all16','arm64_cap','arm64_disable','arm64_force','arm64_force_unavailable',
  'arm64_force_incompatible','arm64_unknown','arm64_unavailable'];
const errorFixtures = new Set(['amd64_unknown','amd64_unavailable','arm64_force_unavailable',
  'arm64_force_incompatible','arm64_unknown','arm64_unavailable']);
const sourcePaths = ['docs/requirements-exact-selection-hosted.md','internal/microarch/microarch.go',
  'internal/microarch/selection_benchmark_test.go','internal/microarch/selection_reference_test.go',
  'tests/e2e/selection_benchmark_test.go','go.mod','go.sum'];
const verification = [];
function verify(name, fn) {
  try { fn(); verification.push({name,passed:true}); }
  catch (error) { verification.push({name,passed:false,error:String(error)}); }
}
verify('source matches frozen source', () => assert.equal(read('source.txt').trim(),expectedSource));
verify('clean status before and after', () => {
  assert.equal(read('status-before.txt'),''); assert.equal(read('status-after.txt'),'');
});
const sourceHashes = [];
verify('seven source hashes match Git objects at frozen source', () => {
  const lines = read('source-sha256.txt').trim().split('\n');
  assert.equal(lines.length,sourcePaths.length);
  for (const line of lines) {
    const match = line.match(/^([a-f0-9]{64})  (.+)$/); assert.ok(match,line);
    const [_,actual,sourcePath] = match;
    assert.ok(sourcePaths.includes(sourcePath),sourcePath);
    const expected = sha(cp.execFileSync('git',['show',expectedSource+':'+sourcePath],{maxBuffer:16*1024*1024}));
    assert.equal(actual,expected,sourcePath);
    sourceHashes.push({path:sourcePath,sha256:actual});
  }
  assert.equal(new Set(sourceHashes.map(x=>x.path)).size,sourcePaths.length);
});
verify('post-collection source hash recheck', () => {
  const lines = read('source-recheck.txt').trim().split('\n');
  assert.deepEqual([...lines].sort(),sourcePaths.map(p=>p+': OK').sort());
});
const toolchain = read('toolchain.txt').trim().split('\n');
verify('native Go 1.27.3 local Linux toolchain', () => {
  assert.equal(toolchain[0],'go version go1.27.3 linux/'+arch);
  assert.equal(toolchain[1],'linux'); assert.equal(toolchain[2],arch); assert.equal(toolchain[4],'local');
  assert.equal(toolchain.length,8);
  for (const line of toolchain.slice(5)) assert.match(line,/^[a-f0-9]{64}  \//);
  assert.match(toolchain[5],/\/bin\/go$/); assert.match(toolchain[6],/\/compile$/); assert.match(toolchain[7],/\/link$/);
});
const host = read('host.txt');
verify('native uname and CPU identity', () => {
  assert.match(host,new RegExp('^Linux .+ '+(arch==='amd64'?'x86_64':'aarch64')+'$','m'));
  assert.match(host,/^Architecture:\s+(x86_64|aarch64)$/m);
  assert.match(host,/^Model name:\s+.+$/m);
  assert.match(host,/current affinity list:/);
});
function parse(file,prefix,names) {
  const raw = read(file); const groups = {}; const parseErrors=[];
  for(const line of raw.split('\n')) {
    if(!line.startsWith(prefix+'/')) continue;
    const match=line.match(/^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns\/op\s+(\d+) B\/op\s+(\d+) allocs\/op\s*$/);
    if(!match){parseErrors.push(line);continue;}
    const name=match[1].slice(prefix.length+1);
    (groups[name]??=[]).push({iterations:Number(match[2]),ns:Number(match[3]),bytes:Number(match[4]),allocs:Number(match[5])});
  }
  const explicitFailures=raw.split('\n').filter(x=>/^FAIL\b|^--- FAIL|^panic:|^fatal error:|^--- BENCH/.test(x));
  verify(file+' PASS, native identity and complete fixed groups/repetitions',()=>{
    assert.match(raw,/^PASS$/m); assert.match(raw,/^goos: linux$/m); assert.match(raw,new RegExp('^goarch: '+arch+'$','m'));
    assert.deepEqual(parseErrors,[]);assert.deepEqual(explicitFailures,[]);
    assert.deepEqual(Object.keys(groups).sort(),[...names].sort());
    for(const [name,rows] of Object.entries(groups)){
      assert.equal(rows.length,8,name); assert.ok(rows.every(x=>x.iterations>0),name);
    }
  });
  return {rows:Object.values(groups).reduce((n,x)=>n+x.length,0),parse_errors:parseErrors,explicit_failures:explicitFailures,
    groups:Object.fromEntries(Object.entries(groups).map(([name,samples])=>[name,{repetitions:samples.length,
      ns:stats(samples.map(x=>x.ns)),bytes:stats(samples.map(x=>x.bytes)),allocs:stats(samples.map(x=>x.allocs)),samples}]))};
}
const selection=parse('selection.txt','BenchmarkSelectVariantForHost',fixtures.flatMap(x=>[x+'/current',x+'/exact_mask']));
const context=parse('process-context.txt','BenchmarkSelectionCompleteProcessContext',['native','memfd','cold-cache','warm-cache']);
const comparisons={};
for(const name of fixtures){
  const current=selection.groups[name+'/current'];const candidate=selection.groups[name+'/exact_mask'];
  if(!current||!candidate)continue;
  const saving=current.ns.median-candidate.ns.median;
  const ratio=candidate.ns.median/current.ns.median;
  comparisons[name]={expected_failure:errorFixtures.has(name),current,candidate,median_saving_ns:saving,
    candidate_to_current_ratio:ratio,median_relative_saving:1-ratio,
    fewer_allocations:candidate.allocs.median<current.allocs.median,
    time_nonregression:candidate.ns.median<=1.05*current.ns.median,
    allocation_nonregression:candidate.allocs.median<=current.allocs.median,
    sparse_gate:saving>=100000&&ratio<=0.75&&candidate.allocs.median<current.allocs.median};
}
const sparse=['arm64_sparse_v8_0','arm64_sparse_v8_2','arm64_sparse_v9_0_no_v8_9'];
const sparseGate=sparse.every(name=>comparisons[name]?.sparse_gate);
const nonregressionGate=Object.values(comparisons).every(x=>x.expected_failure||(x.time_nonregression&&x.allocation_nonregression));
const complete=verification.every(x=>x.passed);
const report={schema:2,architecture:arch,source:expectedSource,verification,complete,toolchain,source_hashes:sourceHashes,
  host,cgroup:read('cgroup.txt'),selection,comparisons,process_context:context,
  gates:{sparse:sparseGate,successful_representative_nonregression:nonregressionGate},
  disposition:'retain_current_selector',characterization:complete?'complete':'incomplete',
  limitations:['separate fixed native architecture cohort; no pooling with local or other architecture',
    'descriptive medians and ranges, not population confidence bounds',
    'readable cgroup constraints do not establish host isolation',
    'current-only process context establishes no candidate-attributable launch savings or service p99',
    'parent allocations are not child allocations or RSS',
    'toolchain binary hashes are retained observations; binaries were not supplied for independent hash replay']};
fs.writeFileSync(path.join(outputDir,arch+'-summary-independent.json'),JSON.stringify(report,null,2)+'\n');
let md='# '+arch+' hosted cohort\n\nSource: `'+expectedSource+'`. Complete: '+complete+'. Sparse gate: '+sparseGate+
  '. Representative nonregression gate: '+nonregressionGate+'. Disposition: retain current selector.\n\n';
md+='All times below are ns/op; each median [min, max] retains eight samples. B/op and allocs/op are median [min, max].\n\n';
md+='| Fixture | Expected error | Current ns | Candidate ns | Saving ns | Saving % | Current B | Candidate B | Current alloc | Candidate alloc | <=5% time regression | Allocation nonregression |\n';
md+='|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|\n';
const number=x=>Number(x.toFixed(6)).toString();
const fmt=s=>`${number(s.median)} [${number(s.min)}, ${number(s.max)}]`;
for(const [name,x] of Object.entries(comparisons))md+=`| ${name} | ${x.expected_failure} | ${fmt(x.current.ns)} | ${fmt(x.candidate.ns)} | ${number(x.median_saving_ns)} | ${(100*x.median_relative_saving).toFixed(3)} | ${fmt(x.current.bytes)} | ${fmt(x.candidate.bytes)} | ${fmt(x.current.allocs)} | ${fmt(x.candidate.allocs)} | ${x.time_nonregression} | ${x.allocation_nonregression} |\n`;
md+='\n| Current-only process mode | ns/op | B/op | allocs/op |\n|---|---:|---:|---:|\n';
for(const [name,x] of Object.entries(context.groups))md+=`| ${name} | ${fmt(x.ns)} | ${fmt(x.bytes)} | ${fmt(x.allocs)} |\n`;
md+='\nVerification:\n\n'+verification.map(x=>'- '+x.name+': '+(x.passed?'PASS':x.error)).join('\n')+'\n';
fs.writeFileSync(path.join(outputDir,arch+'-summary-independent.md'),md);
console.log(JSON.stringify({arch,complete,rows:selection.rows,context_rows:context.rows,gates:report.gates,
  failed_verification:verification.filter(x=>!x.passed),successful_regressions:Object.entries(comparisons)
  .filter(([_,x])=>!x.expected_failure&&(!x.time_nonregression||!x.allocation_nonregression)).map(([name])=>name)},null,2));

if (!complete) process.exitCode = 1;
