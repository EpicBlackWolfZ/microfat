# Independent audit: hosted native amd64 characterization

No discrepancy found. The fixed hosted amd64 cohort is complete and independently
supports **retain the current selector** under the unchanged prospective criteria.
This audit ran no measurements or tests.

## Artifact, source and metadata

- Artifact `12567266928`, `runtime-source-amd64-40111512777-1`, is 68,828,942
  bytes. Independently hashing the retained ZIP agrees with the recorded GitHub
  digest: `sha256:8f4007d34c179abe86751dc31e224472a6861131eadeca6d1ce881e10e3122be`.
- The metadata identifies run `40111512777`, attempt 1, and frozen source
  `39a7fccc97061b588a9ef17bc104ebcbb328aa89`. All 10 extracted selection-study
  files agree byte for byte with their ZIP members.
- Both recorded Git statuses are clean. All seven source/protocol hashes match
  Git objects at that frozen source; the post-collection recheck contains exactly
  the seven expected `OK` entries.
- Recorded toolchain is Go 1.27.3, Linux/amd64, `GOTOOLCHAIN=local`, with Go,
  compiler and linker hashes retained. Remote executable bytes were not supplied
  for independent binary hash replay.
- Host identity is native x86_64, AMD EPYC 9V45, four visible logical CPUs and
  affinity 0–3. Process/ancestor cgroup files were captured before collection:
  readable process/system-slice quota and memory ceilings are `max`, while root
  quota/memory files are explicitly unavailable. These are observations and do
  not establish dedicated hardware, an idle VM or resource isolation.
- The retained native requirements/reference correctness log ends in `PASS`
  without a failure marker. This does not establish that the complete workflow
  or unrelated qualification jobs passed.

## Independent numerical replay

Independently parsed every raw row and recomputed sample lists, iteration counts,
medians, ranges, B/op, allocs/op and derived comparisons in the JSON summary:

- Selection: **19 fixtures × 2 implementations × 8 repetitions = 304 rows**,
  exactly eight samples in each of 38 groups, final `PASS`.
- Current-only process context: **4 modes × 8 repetitions = 32 rows**, exactly
  eight samples per mode, final `PASS`.
- All JSON statistics agree with raw values. The Markdown summary agrees with
  those retained statistics. No rows were excluded or replaced.

Sparse ARM feature-fixture median savings on this native amd64 machine are
**0.13615 µs**, **0.85115 µs** and **2.09335 µs**, respectively for v8.0, v8.2
and v9.0 without v8.9. Every fixture misses the 100 µs gate. The v8.0 fixture
also retains three allocations rather than reducing them. These ARM feature
inputs remain synthetic on the amd64 host.

Five successful AMD fixtures exceed the 5% median-time nonregression ceiling:
sparse **14.030%**, dense **8.187%**, cap **10.237%**, force **9.111%** and
normalization **10.141%**. Disabled is **3.807%** slower and remains within that
ceiling. Normalization additionally increases **456 → 472 B/op** and
**21 → 22 allocs/op**. Thus the successful-representative gate also fails.
Dense ARM improves **19671 → 2335.5 ns**, but cannot override failed gates.

The six intentional error fixtures remain reported separately. Negative observed
comparisons include AMD unknown **+73.913%**, AMD unavailable **+43.945%** and
ARM unknown **+137.743%**; these do not enter the successful-fixture gate.

Current-only process medians are native **0.824747 ms**, memfd **4.5314785 ms**,
cold extracted-payload cache **6.966918 ms** and warm extracted-payload cache
**2.702473 ms**. The parent counters are not child allocations or RSS. No
candidate launcher is executed, so these timings establish no candidate-
attributable launch saving or service p99.

This is one separately retained native amd64 hosted characterization. It is not
pooled with the exploratory local cohort or any native arm64 cohort, does not
repair the local contention disclosure and cannot rescue promotion. Later
documentation-only evidence integration and final-head CI have separate source
identities and do not replace this measured source.
