# amd64 hosted cohort

Source: `39a7fccc97061b588a9ef17bc104ebcbb328aa89`. Complete: true. Sparse gate: false. Representative nonregression gate: false. Disposition: retain current selector.

All times below are ns/op; each median [min, max] retains eight samples. B/op and allocs/op are median [min, max].

| Fixture | Expected error | Current ns | Candidate ns | Saving ns | Saving % | Current B | Candidate B | Current alloc | Candidate alloc | <=5% time regression | Allocation nonregression |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| amd64_sparse | false | 292.95 [288, 300.8] | 334.05 [330.4, 344.8] | -41.1 | -14.030 | 232 [232, 232] | 232 [232, 232] | 5 [5, 5] | 5 [5, 5] | false | true |
| amd64_dense | false | 591.15 [588.5, 598.1] | 639.55 [634.2, 645.5] | -48.4 | -8.187 | 344 [344, 344] | 344 [344, 344] | 5 [5, 5] | 5 [5, 5] | false | true |
| amd64_cap | false | 523.6 [518.2, 530.2] | 577.2 [563.6, 589.6] | -53.6 | -10.237 | 384 [384, 384] | 384 [384, 384] | 7 [7, 7] | 7 [7, 7] | false | true |
| amd64_disable | false | 644.9 [634, 649.5] | 669.45 [661.7, 683.7] | -24.55 | -3.807 | 400 [400, 400] | 400 [400, 400] | 8 [8, 8] | 8 [8, 8] | true | true |
| amd64_force | false | 353.4 [350.6, 356.6] | 385.6 [370.7, 395.1] | -32.2 | -9.111 | 104 [104, 104] | 104 [104, 104] | 3 [3, 3] | 3 [3, 3] | false | true |
| amd64_normalization | false | 840.65 [834.9, 903.6] | 925.9 [916, 932.6] | -85.25 | -10.141 | 456 [456, 456] | 472 [472, 472] | 21 [21, 21] | 22 [22, 22] | false | false |
| amd64_unknown | true | 64.17 [62.97, 65.12] | 111.6 [107.3, 115.8] | -47.43 | -73.913 | 16 [16, 16] | 16 [16, 16] | 1 [1, 1] | 1 [1, 1] | false | true |
| amd64_unavailable | true | 75.48 [73.74, 78.83] | 108.65 [107.1, 111] | -33.17 | -43.945 | 16 [16, 16] | 16 [16, 16] | 1 [1, 1] | 1 [1, 1] | false | true |
| arm64_sparse_v8_0 | false | 397.05 [395.4, 402.9] | 260.9 [258.5, 264.4] | 136.15 | 34.290 | 104 [104, 104] | 104 [104, 104] | 3 [3, 3] | 3 [3, 3] | true | true |
| arm64_sparse_v8_2 | false | 1308.5 [1294, 1319] | 457.35 [453.9, 472.2] | 851.15 | 65.048 | 704 [704, 704] | 248 [248, 248] | 8 [8, 8] | 5 [5, 5] | true | true |
| arm64_sparse_v9_0_no_v8_9 | false | 2583.5 [2578, 2640] | 490.15 [482.8, 494] | 2093.35 | 81.028 | 2088 [2088, 2088] | 248 [248, 248] | 13 [13, 13] | 5 [5, 5] | true | true |
| arm64_dense_all16 | false | 19671 [19597, 19768] | 2335.5 [2312, 2440] | 17335.5 | 88.127 | 14432 [14432, 14432] | 1080 [1080, 1080] | 60 [60, 60] | 5 [5, 5] | true | true |
| arm64_cap | false | 2632 [2615, 2674] | 498.65 [493.8, 502.4] | 2133.35 | 81.054 | 2032 [2032, 2032] | 192 [192, 192] | 13 [13, 13] | 5 [5, 5] | true | true |
| arm64_disable | false | 2657 [2648, 2669] | 519.45 [516.9, 534.3] | 2137.55 | 80.450 | 2040 [2040, 2040] | 200 [200, 200] | 13 [13, 13] | 5 [5, 5] | true | true |
| arm64_force | false | 1736.5 [1709, 1790] | 450.95 [447.2, 454] | 1285.55 | 74.031 | 552 [552, 552] | 96 [96, 96] | 6 [6, 6] | 3 [3, 3] | true | true |
| arm64_force_unavailable | true | 3070 [3051, 3143] | 654.75 [649.9, 662.7] | 2415.25 | 78.673 | 2088 [2088, 2088] | 248 [248, 248] | 15 [15, 15] | 7 [7, 7] | true | true |
| arm64_force_incompatible | true | 3622.5 [3604, 3654] | 325.95 [323.9, 329.1] | 3296.55 | 91.002 | 3272 [3272, 3272] | 48 [48, 48] | 14 [14, 14] | 1 [1, 1] | true | true |
| arm64_unknown | true | 80.465 [79.11, 81.28] | 191.3 [188.7, 194.6] | -110.835 | -137.743 | 16 [16, 16] | 16 [16, 16] | 1 [1, 1] | 1 [1, 1] | false | true |
| arm64_unavailable | true | 1314.5 [1305, 1339] | 199.95 [198.3, 201.6] | 1114.55 | 84.789 | 1400 [1400, 1400] | 16 [16, 16] | 6 [6, 6] | 1 [1, 1] | true | true |

| Current-only process mode | ns/op | B/op | allocs/op |
|---|---:|---:|---:|
| native | 824747 [818074, 841465] | 20072 [20072, 20111] | 56 [56, 56] |
| memfd | 4531478.5 [4487821, 4593963] | 20072 [20072, 20072] | 56 [56, 56] |
| cold-cache | 6966918 [6834380, 7129547] | 20072 [20072, 20072] | 56 [56, 56] |
| warm-cache | 2702473 [2668414, 2727676] | 20072 [20072, 20072] | 56 [56, 56] |

Verification:

- source matches frozen source: PASS
- clean status before and after: PASS
- seven source hashes match Git objects at frozen source: PASS
- post-collection source hash recheck: PASS
- native Go 1.27.3 local Linux toolchain: PASS
- native uname and CPU identity: PASS
- selection.txt PASS, native identity and complete fixed groups/repetitions: PASS
- process-context.txt PASS, native identity and complete fixed groups/repetitions: PASS
