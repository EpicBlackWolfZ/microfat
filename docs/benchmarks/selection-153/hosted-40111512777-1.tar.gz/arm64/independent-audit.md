# Independent audit: hosted native arm64 characterization

No discrepancy found. This fixed native arm64 cohort is complete, and both
unchanged performance gates fail. Its disposition remains **retain the current
selector**. This audit performed no measurements, tests or reruns.

## Artifact and provenance

- Retained artifact `12566724515`, `runtime-source-arm64-40111512777-1`, is
  exactly **62,082,755 bytes**. Independent hashing agrees with its recorded
  GitHub digest:
  `sha256:aa3cb2a3c1333de885750d3341402b5a6d130faeefce6cc993396ce76694c561`.
- Metadata identifies run `40111512777`, attempt 1, source
  `39a7fccc97061b588a9ef17bc104ebcbb328aa89`. All 10 extracted selection-study
  files match the original ZIP members byte for byte.
- Both recorded source statuses are clean. All seven source/protocol hashes
  agree with Git objects at the frozen source, and the post-collection recheck
  contains exactly the expected seven successful entries.
- Recorded toolchain is **Go 1.27.3 Linux/arm64**, `GOTOOLCHAIN=local`; Go,
  compiler and linker hashes are retained observations. Remote executable bytes
  were not supplied for independent binary hash replay.
- Recorded native kernel/host identity is **aarch64, Neoverse-N2**, four visible
  CPUs, affinity 0–3. The pre-collection process and system-slice cgroup quota/
  memory ceilings read `max`; unavailable root values remain explicit. These
  observations establish neither an idle VM nor dedicated or isolated hardware.
- Retained requirements/reference and native ARM auxiliary-vector feature logs
  both end in `PASS` without failure markers. This audit does not infer that the
  whole workflow or unrelated qualification jobs succeeded from those logs.

## Complete independent numerical replay

Independently parsed raw measurements and recomputed all iteration lists,
sample values, medians, minima, maxima, B/op, allocs/op, comparisons and gates:

- **304 selector rows = 19 fixtures × 2 implementations × 8 repetitions**;
  every one of 38 groups has eight rows and raw output ends in `PASS`.
- **32 current-only process rows = 4 modes × 8 repetitions**; every mode has
  eight rows and raw output ends in `PASS`.
- All JSON statistics and all 19 Markdown selector-table rows agree with the
  independently recomputed raw values. No row was dropped or substituted.

The native ARM host executes the selector algorithm, while each supplied
feature set remains a fixture. These timings do not establish that this CPU
supports every represented ARM tier or validate AMD instructions on ARM.

Sparse ARM fixture median savings are **0.1265 µs** (v8.0), **1.159 µs** (v8.2)
and **2.96225 µs** (v9.0 without v8.9): all miss the **100 µs** gate. The v8.0
fixture also misses the **25%** gate at **19.689%**, and its allocations remain
**3 → 3**. The sparse gate therefore fails independently on this native host.

All six successful AMD-feature fixtures on this ARM host exceed the 5% ceiling:
sparse **14.505%**, dense **14.435%**, cap **17.310%**, disabled **12.876%**,
force **21.874%**, normalization **13.578%** slower in the observed medians.
Normalization additionally increases **456 → 472 B/op** and **21 → 22
allocs/op**. The representative nonregression gate also fails. Dense ARM improves
**28875 → 4050 ns**, saving **24.825 µs**, which cannot override failed gates.

All six intentional error fixtures remain separate. Negative observed median
comparisons include AMD unknown **+55.667%**, AMD unavailable **+39.749%** and
ARM unknown **+149.943%**. These do not enter the successful-fixture gate.

Current-only process medians are native **1.2005625 ms**, memfd **5.9832255 ms**,
cold extracted-payload cache **8.753120 ms**, warm extracted-payload cache
**3.4975875 ms**. The cold-cache range **8.439231–12.517000 ms** is preserved
in full. Parent counters do not measure child allocations or RSS, and no
candidate launcher was executed: there is no candidate-attributable launch or
service-p99 conclusion.

This native arm64 cohort remains separate from native amd64 and the exploratory
local workstation cohort. No pooled estimate, replacement, retrospective gate
change or rescue of promotion follows from it. Final documentation/evidence
integration and final-head CI retain their own source identities.
