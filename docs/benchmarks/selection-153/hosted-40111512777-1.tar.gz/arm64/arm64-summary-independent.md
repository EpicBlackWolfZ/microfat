# arm64 hosted cohort

Source: `39a7fccc97061b588a9ef17bc104ebcbb328aa89`. Complete: true. Sparse gate: false. Representative nonregression gate: false. Disposition: retain current selector.

All times below are ns/op; each median [min, max] retains eight samples. B/op and allocs/op are median [min, max].

| Fixture | Expected error | Current ns | Candidate ns | Saving ns | Saving % | Current B | Candidate B | Current alloc | Candidate alloc | <=5% time regression | Allocation nonregression |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| amd64_sparse | false | 537.75 [532, 538.6] | 615.75 [611.5, 623.8] | -78 | -14.505 | 232 [232, 232] | 232 [232, 232] | 5 [5, 5] | 5 [5, 5] | false | true |
| amd64_dense | false | 1004.5 [995.2, 1013] | 1149.5 [1131, 1164] | -145 | -14.435 | 344 [344, 344] | 344 [344, 344] | 5 [5, 5] | 5 [5, 5] | false | true |
| amd64_cap | false | 924.05 [919.4, 1000] | 1084 [1055, 1094] | -159.95 | -17.310 | 384 [384, 384] | 384 [384, 384] | 7 [7, 7] | 7 [7, 7] | false | true |
| amd64_disable | false | 1064 [1057, 1070] | 1201 [1193, 1214] | -137 | -12.876 | 400 [400, 400] | 400 [400, 400] | 8 [8, 8] | 8 [8, 8] | false | true |
| amd64_force | false | 581.5 [579.7, 585.8] | 708.7 [704.9, 710.6] | -127.2 | -21.874 | 104 [104, 104] | 104 [104, 104] | 3 [3, 3] | 3 [3, 3] | false | true |
| amd64_normalization | false | 1554 [1536, 1717] | 1765 [1754, 1841] | -211 | -13.578 | 456 [456, 456] | 472 [472, 472] | 21 [21, 21] | 22 [22, 22] | false | false |
| amd64_unknown | true | 115.15 [108, 116] | 179.25 [177.9, 180.5] | -64.1 | -55.667 | 16 [16, 16] | 16 [16, 16] | 1 [1, 1] | 1 [1, 1] | false | true |
| amd64_unavailable | true | 131.45 [129.8, 133] | 183.7 [182.4, 185.5] | -52.25 | -39.749 | 16 [16, 16] | 16 [16, 16] | 1 [1, 1] | 1 [1, 1] | false | true |
| arm64_sparse_v8_0 | false | 642.5 [632.4, 651] | 516 [511.2, 521.6] | 126.5 | 19.689 | 104 [104, 104] | 104 [104, 104] | 3 [3, 3] | 3 [3, 3] | true | true |
| arm64_sparse_v8_2 | false | 1977.5 [1955, 2013] | 818.5 [814.8, 851.3] | 1159 | 58.609 | 704 [704, 704] | 248 [248, 248] | 8 [8, 8] | 5 [5, 5] | true | true |
| arm64_sparse_v9_0_no_v8_9 | false | 3856.5 [3843, 3923] | 894.25 [882.7, 923.8] | 2962.25 | 76.812 | 2088 [2088, 2088] | 248 [248, 248] | 13 [13, 13] | 5 [5, 5] | true | true |
| arm64_dense_all16 | false | 28875 [28558, 31166] | 4050 [3951, 4326] | 24825 | 85.974 | 14432 [14432, 14432] | 1080 [1080, 1080] | 60 [60, 60] | 5 [5, 5] | true | true |
| arm64_cap | false | 3936 [3918, 3964] | 938.45 [934.6, 943.7] | 2997.55 | 76.157 | 2032 [2032, 2032] | 192 [192, 192] | 13 [13, 13] | 5 [5, 5] | true | true |
| arm64_disable | false | 3960.5 [3936, 4144] | 968.3 [959.6, 1000] | 2992.2 | 75.551 | 2040 [2040, 2040] | 200 [200, 200] | 13 [13, 13] | 5 [5, 5] | true | true |
| arm64_force | false | 2532 [2469, 2550] | 797.8 [796.3, 801.3] | 1734.2 | 68.491 | 552 [552, 552] | 96 [96, 96] | 6 [6, 6] | 3 [3, 3] | true | true |
| arm64_force_unavailable | true | 4530.5 [4487, 4586] | 1177.5 [1173, 1237] | 3353 | 74.009 | 2088 [2088, 2088] | 248 [248, 248] | 15 [15, 15] | 7 [7, 7] | true | true |
| arm64_force_incompatible | true | 5589.5 [5409, 5803] | 582.35 [579.5, 584.9] | 5007.15 | 89.581 | 3272 [3272, 3272] | 48 [48, 48] | 14 [14, 14] | 1 [1, 1] | true | true |
| arm64_unknown | true | 130.45 [129.5, 132.3] | 326.05 [325.4, 327.8] | -195.6 | -149.943 | 16 [16, 16] | 16 [16, 16] | 1 [1, 1] | 1 [1, 1] | false | true |
| arm64_unavailable | true | 2044 [2035, 2099] | 328.1 [326.8, 331] | 1715.9 | 83.948 | 1400 [1400, 1400] | 16 [16, 16] | 6 [6, 6] | 1 [1, 1] | true | true |

| Current-only process mode | ns/op | B/op | allocs/op |
|---|---:|---:|---:|
| native | 1200562.5 [1178482, 1246477] | 15880 [15880, 15889] | 56 [56, 56] |
| memfd | 5983225.5 [5877194, 6257620] | 15848 [15848, 15848] | 56 [56, 56] |
| cold-cache | 8753120 [8439231, 12517000] | 15848 [15848, 15848] | 56 [56, 56] |
| warm-cache | 3497587.5 [3436643, 3634800] | 15848 [15848, 15848] | 56 [56, 56] |

Verification:

- source matches frozen source: PASS
- clean status before and after: PASS
- seven source hashes match Git objects at frozen source: PASS
- post-collection source hash recheck: PASS
- native Go 1.27.3 local Linux toolchain: PASS
- native uname and CPU identity: PASS
- selection.txt PASS, native identity and complete fixed groups/repetitions: PASS
- process-context.txt PASS, native identity and complete fixed groups/repetitions: PASS
