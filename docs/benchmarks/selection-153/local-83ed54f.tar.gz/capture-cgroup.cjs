const fs = require('node:fs');
const path = require('node:path');
const membership = fs.readFileSync('/proc/self/cgroup', 'utf8');
const relative = membership.split('\n').find(x => x.startsWith('0::'))?.slice(3);
const observations = [];
if (relative !== undefined) {
  let dir = path.join('/sys/fs/cgroup', relative);
  while (dir.startsWith('/sys/fs/cgroup')) {
    const values = {};
    for (const file of ['cpu.max', 'cpu.stat', 'memory.max', 'memory.high', 'memory.current', 'memory.events']) {
      try { values[file] = fs.readFileSync(path.join(dir, file), 'utf8'); }
      catch (error) { values[file] = {unavailable: error.code}; }
    }
    observations.push({directory: dir, values});
    if (dir === '/sys/fs/cgroup') break;
    dir = path.dirname(dir);
  }
}
fs.writeFileSync(path.join(__dirname, 'cgroup-post-cohort.json'), JSON.stringify({
  observed_at_utc: new Date().toISOString(), phase: 'post-cohort-only', membership, observations,
  limitation: 'Initial cgroup.txt captured root only; these later reads do not establish applied limits during timing.'
}, null, 2) + '\n');
