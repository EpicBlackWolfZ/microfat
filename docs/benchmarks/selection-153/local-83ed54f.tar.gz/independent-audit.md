# Independent audit of the frozen selection cohort

Decision: **retain the current production selector**. Both frozen performance
gates fail. The test-only exact-mask implementation remains useful comparative
evidence; this cohort does not qualify it for production adoption.

## Completeness and provenance

- Independently parsed `selection.txt`: all **19 fixtures × 2 implementations ×
  8 repetitions = 304 rows**, with exactly eight rows in each of 38 groups and
  a final `PASS`. No repetitions were removed or replaced.
- Independently parsed `process-context.txt`: all **4 modes × 8 repetitions =
  32 rows**, with exactly eight rows in each group and a final `PASS`.
- Independently recomputed every median, minimum, maximum, allocation counter,
  iteration list and comparison in `summary.json`; all agree with raw output.
- `source.txt` identifies clean commit
  `83ed54f4605a36bda222046bf0a611263b3824ed`. Recorded before/after status files
  and the before diff are empty. All eight hashes in `source-sha256.txt` match
  both the current files and those files at the frozen commit. The retained
  protocol copy matches the committed protocol byte for byte.
- Source review found the architecture alias fixes consistent with existing
  ranking behavior. The independent reference includes flattened requirements,
  missing LAHF/SAHF, ARM branch negatives, alias/policy combinations, original
  identifiers and sentinel errors. The candidate rebuilds host and available
  masks per timed call and applies the common policy engine. No additional
  measurements or tests were run for this audit.

## Frozen gate evaluation

Sparse ARM fixture medians and observed ranges, in nanoseconds:

| Fixture | Current median [min, max] | Mask median [min, max] | Saving | Allocs current → mask |
| --- | ---: | ---: | ---: | ---: |
| v8.0 | 807 [772.6, 835.9] | 645.05 [617.6, 681.5] | 0.16195 µs; 20.068% | 3 → 3 |
| v8.2 | 2421.5 [2389, 2643] | 1049.5 [989.5, 1148] | 1.372 µs; 56.659% | 8 → 5 |
| v9.0 without v8.9 | 4706 [4633, 4914] | 1216 [1085, 1236] | 3.490 µs; 74.161% | 13 → 5 |

Every sparse fixture misses the required 100 µs median saving. The v8.0 fixture
also misses the required 25% saving and fewer-allocation conditions.

All six successful AMD fixtures violate the 5% nonregression condition:

| Fixture | Current median ns | Mask median ns | Time increase |
| --- | ---: | ---: | ---: |
| sparse | 699.9 | 801.75 | 14.552% |
| dense | 1331.5 | 1510 | 13.406% |
| cap | 1240.5 | 1419.5 | 14.430% |
| disabled | 1455 | 1630 | 12.027% |
| force | 838.75 | 966 | 15.171% |
| normalization | 2092 | 2337.5 | 11.735% |

Normalization additionally increases 456 → 472 B/op and 21 → 22 allocs/op.
Dense ARM improves 34963.5 → 5195 ns, saving 29.7685 µs with 60 → 5 allocs/op;
this improvement cannot override the failed frozen gates.

All six expected-error fixtures remain separately reported in `summary.json`.
Negative medians include AMD unknown 151.65 → 235.85 ns (+55.523%), AMD
unavailable 178.2 → 245.8 ns (+37.935%) and ARM unknown 158.4 → 395.1 ns
(+149.432%); each retains one allocation. ARM force-unavailable improves
5661 → 1493.5 ns, force-incompatible 6286 → 658.55 ns, and unavailable
2301 → 434.7 ns. These error paths do not enter the successful-fixture gate.

## Process context and evidence limits

Current-only process medians [observed minimum, maximum], in milliseconds:

- Direct native: 1.179999 [1.146447, 1.207217].
- Full-stub memfd: 6.916642 [6.654620, 7.397993].
- Cold extracted-payload cache: 8.2192275 [8.086711, 8.550093].
- Warm extracted-payload cache: 3.727399 [3.579776, 3.929890].

Every mode reports 24296 B/op and 56 allocs/op in the benchmark parent. These
are not child memory measurements. The timed boundary includes `cmd.Output`,
process startup, launcher work and payload exit; cache preparation and marker/
stderr checks are outside timing. Child runtime settings follow the documented
normal behavior; `GOMAXPROCS=1` controls the parent.

The initial cgroup snapshot recorded root data only and omitted readable
process-relative quota/memory data. The original is preserved. The separately
timestamped `cgroup-post-cohort.json` explicitly cannot establish limits during
timing; its historical ancestor OOM counters cannot be attributed to this run.
OS page cache and shared-host interference remain uncontrolled.

These are descriptive repeated microbenchmarks on native amd64, with synthetic
ARM feature inputs. The process cohort executes no candidate launcher and
supports **no mask-attributable launch improvement, native ARM timing, child
RSS or service p99 claim**. Hosted correctness/dispatch qualification remains a
separate requirement and cannot rescue this failed local adoption decision.
