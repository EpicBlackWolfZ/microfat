const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const read = name => { try { return fs.readFileSync(name, 'utf8'); } catch (e) { return {unavailable:e.code}; } };
const membership = read('/proc/self/cgroup');
const relative = typeof membership === 'string' ? membership.split('\n').find(x => x.startsWith('0::'))?.slice(3) : undefined;
const observations = [];
if (relative !== undefined) {
  let dir = path.join('/sys/fs/cgroup', relative);
  while (dir.startsWith('/sys/fs/cgroup')) {
    observations.push({directory:dir, values:Object.fromEntries(['cpu.max','cpu.stat','cpu.pressure','cpuset.cpus.effective','memory.max','memory.high','memory.current','memory.events'].map(x => [x,read(path.join(dir,x))]))});
    if (dir === '/sys/fs/cgroup') break;
    dir = path.dirname(dir);
  }
}
const result = {observed_at_utc:new Date().toISOString(), phase:process.argv[2], membership, observations,
  cpu_pressure:read('/proc/pressure/cpu'), loadavg:read('/proc/loadavg'),
  proc_status:read('/proc/self/status'), uname:cp.execFileSync('uname',['-a'],{encoding:'utf8'}),
  lscpu:cp.execFileSync('lscpu',[],{encoding:'utf8'}),
  limitation:'Shared workstation; user reported gaming stopped. No imposed affinity, quota or isolation; snapshot is not a continuous record.'};
fs.writeFileSync(path.join(__dirname,'host-'+process.argv[2]+'.json'),JSON.stringify(result,null,2)+'\n');
