# Independent audit: requested local reassessment

No defect found in the retained cohort or its numerical summary. The separately
authorized reassessment is complete and both unchanged adoption gates fail:
**retain the current production selector**. This audit ran no benchmarks or tests.

## Source and cohort identity

- Measured source is `44eac8365494739266f73aae50d117ad66a383a7`. The retained
  prospective protocol is byte-identical to
  `docs/requirements-exact-selection-rerun.md` at that Git object.
- Before/after source statuses and the before diff are empty. All **nine**
  protocol/source/tool-pin hashes match both the measured Git object and current
  files. The hash recheck contains exactly the nine successful expected entries.
- Production, benchmark and test sources under `internal/` and `tests/` have no
  changes between original measured source `83ed54f4605a36bda222046bf0a611263b3824ed`
  and this reassessment. The candidate and fixtures were not tuned for the rerun.
- Recorded toolchain is Go 1.27.3, Linux/amd64, `GOTOOLCHAIN=local`; commands
  retain parent `GOMAXPROCS=1`, `-cpu=1`, 100 ms, eight repetitions and no
  race/coverage instrumentation. The documented preflight hash-path correction
  preceded source hashing and is not a replacement timing attempt.
- Independently parsed **304 selection rows = 19 exact expected fixture names ×
  current/exact-mask × eight repetitions**. All 38 groups contain exactly eight
  positive-iteration samples. Both architecture identity headers and final `PASS`
  are present; there are no failure, panic, fatal-error or benchmark-error markers.
- Independently parsed **32 current-only process rows = four exact expected
  modes × eight repetitions**, with the same identity/PASS/failure checks.
- Independently recomputed every iteration list, median, minimum, maximum,
  B/op, allocs/op, comparison, error-fixture classification and gate in
  `summary.json`; all agree with raw measurements. No samples were discarded.
  The hardened replay script asserts exact fixture/implementation/mode names,
  eight repetitions and absence of failure/panic markers. Independent execution
  of that script with reads/writes redirected to memory reproduces the unchanged
  `summary.json` bytes exactly, without any measurement or disk write.

## Unchanged gate decision

Sparse ARM fixture medians [minimum, maximum], in ns/op:

| Fixture | Current | Exact mask | Median saving | Allocs current → mask |
| --- | ---: | ---: | ---: | ---: |
| v8.0 | 743.7 [734.7, 750.2] | 598.95 [593.6, 617.8] | 0.14475 µs; 19.463% | 3 → 3 |
| v8.2 | 2230.5 [2222, 2282] | 942.2 [939.4, 960.9] | 1.2883 µs; 57.758% | 8 → 5 |
| v9.0 without v8.9 | 4394.5 [4362, 4456] | 1034 [1028, 1039] | 3.3605 µs; 76.471% | 13 → 5 |

All three miss the required **100 µs** saving. The v8.0 fixture also misses
**25%** and fewer-allocation conditions. Thus the sparse gate fails.

All six successful AMD-input fixtures exceed the **5%** median-time ceiling:
sparse **14.490%**, dense **11.562%**, cap **12.020%**, disabled **9.956%**,
force **14.332%**, normalization **11.840%** slower in these observed medians.
Normalization also increases **456 → 472 B/op** and **21 → 22 allocs/op**.
Thus the representative gate fails. Dense ARM improves **32489 → 4869.5 ns**,
saving **27.6195 µs** with **60 → 5 allocs/op**, without overriding either gate.

All six intentional error fixtures remain separate. Negative observed median
comparisons include AMD unknown **+59.029%**, AMD unavailable **+40.000%** and
ARM unknown **+148.000%**; each retains one allocation. Favorable ARM
force-unavailable, force-incompatible and unavailable error paths remain retained
and do not enter the successful-fixture gate.

Current-only process medians [minimum, maximum], in milliseconds:

- Direct native: **0.9511295 [0.927983, 1.006117]**.
- Full-stub memfd: **6.2081165 [5.943442, 6.474483]**.
- Cold extracted-payload cache: **7.0699855 [7.014987, 7.192845]**.
- Warm extracted-payload cache: **3.1205315 [3.038836, 3.145000]**.

All process groups retain parent medians **24296 B/op**, **56 allocs/op**.
These counters do not measure child allocations or RSS. No candidate launcher
was executed, so process context establishes no mask-attributable launch gain
or service-request p99.

## Host observations and limits

The native host remains AMD Ryzen 9 3950X, Linux x86_64, with 32 visible logical
CPUs and observed allowed CPU list **0–31**. Snapshots were retained before
(`18:16:03.323Z`), between (`18:16:44.678Z`) and after (`18:17:52.339Z`) the
serial commands on 2026-10-24. They include process-relative cgroup ancestors,
CPU pressure and system load; readable CPU/memory ceilings are `max`, root
quota/memory values are unavailable, and CPU-pressure average fields read zero
at the snapshots. Historical ancestor OOM counters remain unchanged.

The user reported gaming had stopped. Neither that report nor these discrete
snapshots proves continuous idleness, absence of interference, imposed affinity,
an imposed memory limit or hardware isolation. OS page cache remains uncontrolled.
The synthetic ARM feature fixtures on amd64 are algorithm observations rather
than native ARM timing evidence. Medians/ranges remain descriptive rather than
confidence bounds. This separate cohort neither pools with nor erases the
original exploratory local or hosted cohorts; final-head correctness/CI remains
a separate qualification requirement.

## Results-report transcription

Independently checked `docs/requirements-exact-selection-rerun-results.md`
against this raw-verified summary. All **19** displayed selector rows match the
current/candidate medians, ranges and allocation counts; nearest-integer display
rounding consistently uses ties to even. All **four** process rows match the
three-decimal millisecond summaries. All **nine** relative percentages, three
sparse savings and dense saving agree with the exact retained values.

The report correctly preserves user-reported gaming cessation as a report rather
than proof of idleness, distinguishes original/hosted/rerun cohorts and synthetic
ARM inputs, rejects candidate-attributable launch/child-memory claims, and keeps
performance evidence separate from final-head CI and conditional merge review.
No actionable transcription or interpretation defect was found.
