const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = require('node:path');
const dir = __dirname;
const median = xs => {
  const sorted = [...xs].sort((a, b) => a - b);
  const center = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[center] : (sorted[center - 1] + sorted[center]) / 2;
};
function parse(file, prefix, expectedGroups) {
  const raw = fs.readFileSync(path.join(dir, file), 'utf8');
  assert.match(raw, /^PASS$/m);
  assert.doesNotMatch(raw, /^(?:FAIL|--- FAIL:|panic:|fatal error:)/m);
  const groups = {};
  for (const line of raw.split('\n')) {
    const match = line.match(/^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns\/op\s+(\d+) B\/op\s+(\d+) allocs\/op$/);
    if (!match || !match[1].startsWith(prefix + '/')) continue;
    (groups[match[1].slice(prefix.length + 1)] ??= []).push({
      iterations: Number(match[2]), ns: Number(match[3]), bytes: Number(match[4]), allocs: Number(match[5])
    });
  }
  assert.equal(Object.keys(groups).length, expectedGroups);
  const summaries = {};
  for (const [name, rows] of Object.entries(groups)) {
    assert.equal(rows.length, 8, name);
    summaries[name] = {
      repetitions: rows.length,
      median_ns: median(rows.map(x => x.ns)),
      min_ns: Math.min(...rows.map(x => x.ns)),
      max_ns: Math.max(...rows.map(x => x.ns)),
      median_bytes: median(rows.map(x => x.bytes)),
      median_allocs: median(rows.map(x => x.allocs)),
      iterations: rows.map(x => x.iterations)
    };
  }
  return summaries;
}
const selection = parse('selection.txt', 'BenchmarkSelectVariantForHost', 38);
const fixtures = ['amd64_sparse', 'amd64_dense', 'amd64_cap', 'amd64_disable', 'amd64_force',
  'amd64_normalization', 'amd64_unknown', 'amd64_unavailable', 'arm64_sparse_v8_0', 'arm64_sparse_v8_2',
  'arm64_sparse_v9_0_no_v8_9', 'arm64_dense_all16', 'arm64_cap', 'arm64_disable', 'arm64_force',
  'arm64_force_unavailable', 'arm64_force_incompatible', 'arm64_unknown', 'arm64_unavailable'];
assert.deepEqual(Object.keys(selection).sort(), fixtures.flatMap(name => [name + '/current', name + '/exact_mask']).sort());
const failedFixtures = new Set(['amd64_unknown', 'amd64_unavailable', 'arm64_force_unavailable',
  'arm64_force_incompatible', 'arm64_unknown', 'arm64_unavailable']);
const comparisons = Object.fromEntries(fixtures.map(name => {
  const current = selection[name + '/current'];
  const candidate = selection[name + '/exact_mask'];
  return [name, {current, candidate, expected_failure: failedFixtures.has(name),
    median_saving_ns: current.median_ns - candidate.median_ns,
    median_ratio: candidate.median_ns / current.median_ns,
    fewer_allocations: candidate.median_allocs < current.median_allocs,
    nonregression: candidate.median_ns <= 1.05 * current.median_ns && candidate.median_allocs <= current.median_allocs
  }];
}));
const sparseNames = ['arm64_sparse_v8_0', 'arm64_sparse_v8_2', 'arm64_sparse_v9_0_no_v8_9'];
const sparseGate = sparseNames.every(name => {
  const x = comparisons[name];
  return x.median_saving_ns >= 100000 && x.median_ratio <= 0.75 && x.fewer_allocations;
});
const nonregressionGate = Object.values(comparisons).every(x => x.expected_failure || x.nonregression);
const context = parse('process-context.txt', 'BenchmarkSelectionCompleteProcessContext', 4);
assert.deepEqual(Object.keys(context).sort(), ['native', 'memfd', 'cold-cache', 'warm-cache'].sort());
const report = {schema: 1, measured_source: fs.readFileSync(path.join(dir, 'source.txt'), 'utf8').trim(),
  selection_rows: 304, comparisons, process_context: context, sparse_gate: sparseGate,
  representative_nonregression_gate: nonregressionGate,
  decision: sparseGate && nonregressionGate ? 'eligible_for_further_review' : 'retain_current_selector',
  limitations: ['descriptive medians and ranges; no population confidence bounds',
    'ARM feature fixtures on native amd64 are synthetic inputs',
    'current-only process context does not measure mask-attributable launch savings',
    'parent allocations are not child allocations or RSS', 'OS page cache and shared-host interference uncontrolled']};
fs.writeFileSync(path.join(dir, 'summary.json'), JSON.stringify(report, null, 2) + '\n');
process.stdout.write(JSON.stringify({decision: report.decision, sparse_gate: sparseGate,
  representative_nonregression_gate: nonregressionGate, context}, null, 2) + '\n');
