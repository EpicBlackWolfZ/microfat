# Requested local reassessment

One user-requested cohort after gaming stopped, frozen at the commit in source.txt.
See protocol.md and original-protocol.md. All source and benchmark code matches the
prior PR head 22d3d8b9766d1d36220d084f91c1a72b1d204974; only documentation changed.

Replay with `node analyze.cjs`; it reads selection.txt and process-context.txt and
writes summary.json without executing any measurement. The independent audit
separately checks names, repetitions, source objects and calculations.

Check archive contents with `sha256sum -c MANIFEST.sha256`. source-sha256.txt is a
separate list of repository-relative files at the measured commit; its original
successful recheck is source-recheck.txt. Clean before/after statuses are empty
files. Toolchain lines following the version are go env GOOS, GOARCH, GOTOOLCHAIN,
GOMAXPROCS (not a go env key, blank), GOFLAGS (blank) and GOROOT. The explicit
GOMAXPROCS=1 benchmark-parent override is recorded in commands.txt.

Host snapshots are before/between/after the serial commands, not a continuous
resource trace. Snapshots report the capture process's membership inherited from
the same shell, not independently sampled launcher cgroup membership. No idle-host,
resource isolation, page-cache control, native ARM timing or candidate-attributable
launch improvement is established. Parent counters are not child RSS/allocations.

Preflight hash-input names were corrected before timing; this preparation mistake
created no measured attempt. No benchmark attempt was replaced or extended.
