# Independent C2 audit

All 12,144 planned rows match the frozen schedule exactly with no duplicate sequence or phase/cell/round keys: 264 Pack + 11,880 launches (10,560 fat + 1,320 native). All succeed; 88 untimed minimal preparations also succeed. Govulncheck fat memfd: 640/640. Final source is clean at adaea0905e99518216ccf2191077cfc3f097cf51, and all 62 frozen identities pass.

Launch maxima: 243.236 ms wall; 245.934 MiB wait4 maximum RSS.

## Current policies relative to balanced

Each range spans eight real family/build groups. Counts classify cell-wise 95% ratio intervals: equivalence wholly within [0.95,1.05]; improvement wholly below 0.95; regression wholly above 1.05; otherwise inconclusive.

| Policy | Stub | Path | Median paired ratio range | Equivalent | Faster | Slower | Inconclusive |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| latency | full | memfd | 0.9398–1.1127 | 0 | 0 | 2 | 6 |
| latency | full | cold-cache | 1.0638–1.1063 | 0 | 0 | 6 | 2 |
| latency | full | warm-cache | 0.9861–1.0088 | 7 | 0 | 0 | 1 |
| latency | minimal | memfd | 0.8903–1.1065 | 0 | 0 | 2 | 6 |
| latency | minimal | cold-cache | 1.0711–1.1101 | 0 | 0 | 7 | 1 |
| latency | minimal | warm-cache | 0.9832–1.0064 | 8 | 0 | 0 | 0 |
| size | full | memfd | 1.2625–1.5316 | 0 | 0 | 8 | 0 |
| size | full | cold-cache | 1.0679–1.1938 | 0 | 0 | 8 | 0 |
| size | full | warm-cache | 0.9490–1.0060 | 7 | 0 | 0 | 1 |
| size | minimal | memfd | 1.2599–1.5096 | 0 | 0 | 8 | 0 |
| size | minimal | cold-cache | 1.0767–1.1818 | 0 | 0 | 7 | 1 |
| size | minimal | warm-cache | 0.9798–1.0363 | 7 | 0 | 0 | 1 |

All 96 policy cells retain 20 complete pairs each. A separate standalone implementation reproduced all 96 paired-ratio and absolute-saving bootstrap intervals exactly from raw rows. Detailed per-cell intervals are in launch-c2-audit.json.

## Native controls and scope

There are 66 native cells (including 18 synthetic boundary cells), 20 fresh processes per cell. Across cell medians: wall 0.335–44.698 ms; CPU 0.217–50.914 ms; maximum RSS 233.684–243.680 MiB.

Native controls are descriptive process observations, not independent application families or latency certificates. Four real families on one shared native amd64 host; raw pre-launch identity scans warm source pages, and cold/warm refers only to extracted payload caches. These are short-command process-completion clocks, not service p99. Cell-wise bootstrap intervals have no multiplicity adjustment. No timings are pooled with C1. Launch RSS is the whole observed child high-water mark and cannot isolate payload, launcher or decoder memory. C1 retains its failed original cohort separately.

## RSS accounting clarification

Linux wait4 ru_maxrss is retained as observed accounting. Go child creation uses a shared-mm pre-exec path; exec can preserve the pre-exec parent/address-space high-water floor. In C2 the maximum launch RSS 251836 KiB exactly equals the collector final VmHWM. These observations do not isolate encoder, decoder or payload memory, prove a codec-caused memory regression, or establish memory nonregression. Codec-specific memory/resource qualification remains unresolved; no floor is subtracted and no observations are changed. The upstream mechanism is consistent with the observed floor; the distribution kernel was not independently audited.

Collection summary pass flags cover schedule, integrity and the frozen observed budgets; they are not isolated memory qualification. Candidate promotion is independently unsupported by byte/time/launch conditions; see candidate-c2-gates.md.
