package main

import (
	"encoding/json"
	"fmt"
	"io"
	"math"
	"math/rand/v2"
	"os"
	"sort"
)

type row struct {
	Family, Profile, Phase, Setting, Stub, Mode string
	Round                                       int
	WallNS                                      int64
}
type key struct{ Family, Profile, Setting, Stub, Mode string }
type interval struct{ Median, Lower95, Upper95 float64 }
type cmp struct {
	Reference       string
	Ratios          map[string]interval
	AbsoluteSavings map[string]interval
}
type cell struct {
	Family, Profile, Phase, Setting, Stub, Mode string
	Comparisons                                 []cmp
}

func median(v []float64) float64 {
	z := append([]float64(nil), v...)
	sort.Float64s(z)
	m := len(z) / 2
	if len(z)%2 == 1 {
		return z[m]
	}
	return (z[m-1] + z[m]) / 2
}
func main() {
	root := ".work/codec-policy-cohort-adaea09/"
	if len(os.Args) > 1 {
		root = os.Args[1] + "/"
	}
	f, e := os.Open(root + "observations.jsonl")
	if e != nil {
		panic(e)
	}
	defer f.Close()
	d := json.NewDecoder(f)
	rows := map[key]map[int]int64{}
	for {
		var r row
		e = d.Decode(&r)
		if e == io.EOF {
			break
		}
		if e != nil {
			panic(e)
		}
		if r.Phase != "launch" || r.Family == "boundary" || (r.Setting != "balanced" && r.Setting != "latency" && r.Setting != "size") {
			continue
		}
		k := key{r.Family, r.Profile, r.Setting, r.Stub, r.Mode}
		if rows[k] == nil {
			rows[k] = map[int]int64{}
		}
		rows[k][r.Round] = r.WallNS
	}
	data, e := os.ReadFile(root + "summary.json")
	if e != nil {
		panic(e)
	}
	var s struct{ Cells []cell }
	if e = json.Unmarshal(data, &s); e != nil {
		panic(e)
	}
	checked := 0
	for _, c := range s.Cells {
		if c.Phase != "launch" || c.Family == "boundary" || (c.Setting != "latency" && c.Setting != "size") {
			continue
		}
		k := key{c.Family, c.Profile, c.Setting, c.Stub, c.Mode}
		b := k
		b.Setting = "balanced"
		ratios := make([]float64, 20)
		savings := make([]float64, 20)
		for r := range 20 {
			ratios[r] = float64(rows[k][r]) / float64(rows[b][r])
			savings[r] = float64(rows[b][r] - rows[k][r])
		}
		rr := interval{Median: median(ratios)}
		ss := interval{Median: median(savings)}
		rng := rand.New(rand.NewPCG(42, 42))
		rb := make([]float64, 2000)
		sb := make([]float64, 2000)
		for i := range 2000 {
			v := make([]float64, 20)
			w := make([]float64, 20)
			for j := range 20 {
				r := rng.IntN(20)
				v[j] = ratios[r]
				w[j] = savings[r]
			}
			rb[i] = median(v)
			sb[i] = median(w)
		}
		sort.Float64s(rb)
		sort.Float64s(sb)
		lo, hi := int(math.Floor(.025*1999)), int(math.Floor(.975*1999))
		rr.Lower95, rr.Upper95 = rb[lo], rb[hi]
		ss.Lower95, ss.Upper95 = sb[lo], sb[hi]
		for _, x := range c.Comparisons {
			if x.Reference == "balanced" {
				if rr != x.Ratios["wall_ns"] || ss != x.AbsoluteSavings["wall_ns"] {
					panic(fmt.Sprintf("interval differs %v: %v vs %v", k, rr, x.Ratios["wall_ns"]))
				}
				checked++
			}
		}
	}
	fmt.Printf("Exact independent bootstrap matches: %d/96 paired ratio and absolute-saving intervals\n", checked)
}
