# C2 candidate disposition without RSS attribution

All counts apply within C2 only. Each Pack column counts real family/build groups passing the frozen bytes/time conditions out of 8; each launch column counts cells passing the profile-specific wall criteria out of 48 (8 groups x 2 stubs x 3 paths). Memory qualification is unresolved for every candidate.

| Candidate | Latency Pack | Latency launch | Balanced Pack | Balanced launch | Size Pack | Size launch |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| balanced | 0/8 | 32/48 | 0/8 | 48/48 | 0/8 | 47/48 |
| balanced-dict | 0/8 | 17/48 | 1/8 | 16/48 | 0/8 | 46/48 |
| explicit-lz4 | 8/8 | 15/48 | 0/8 | 23/48 | 0/8 | 47/48 |
| explicit-none | 0/8 | 46/48 | 0/8 | 47/48 | 0/8 | 46/48 |
| explicit-zstd-best | 0/8 | 32/48 | 0/8 | 38/48 | 0/8 | 47/48 |
| explicit-zstd-fastest | 8/8 | 18/48 | 4/8 | 18/48 | 0/8 | 47/48 |
| latency | 8/8 | 16/48 | 0/8 | 22/48 | 0/8 | 48/48 |
| size | 0/8 | 14/48 | 0/8 | 15/48 | 0/8 | 48/48 |

No candidate satisfies every non-RSS condition for any replacement policy. In particular, explicit-zstd-fastest passes latency bytes/time conditions in all 8 groups but fails 30/48 launch cells. Its observed RSS ratio is not the sole barrier, and no codec-caused memory regression is established.

C2 final parent VmHWM:	  251836 kB matches the largest launch wait4 RSS value. Retain the observed RSS gate outcomes as accounting observations, not isolated memory qualification.
