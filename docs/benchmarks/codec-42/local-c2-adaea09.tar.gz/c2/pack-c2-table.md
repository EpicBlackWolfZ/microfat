C2 only. Each entry: median wall ms / median CPU ms / maximum RSS MiB. Complete bytes and SHA match C1 for all 88 cells; no timings are pooled.

| Real family/build | Balanced | Latency | Size |
| --- | ---: | ---: | ---: |
| actionlint/stripped | 228.784 / 268.683 / 80.926 | 131.690 / 139.128 / 55.945 | 1209.892 / 1252.531 / 229.492 |
| actionlint/unstripped | 282.804 / 331.694 / 81.266 | 152.197 / 161.245 / 55.945 | 1336.507 / 1363.522 / 240.129 |
| fortio/stripped | 683.109 / 805.837 / 111.348 | 353.125 / 371.737 / 81.523 | 3885.934 / 4026.538 / 215.629 |
| fortio/unstripped | 1021.024 / 1191.757 / 100.359 | 421.835 / 456.001 / 120.574 | 4400.004 / 4568.150 / 140.863 |
| govulncheck/stripped | 387.368 / 461.514 / 84.246 | 206.389 / 215.973 / 55.945 | 2272.081 / 2330.841 / 243.930 |
| govulncheck/unstripped | 435.875 / 519.049 / 64.668 | 251.856 / 258.917 / 74.148 | 2417.474 / 2514.144 / 253.047 |
| task/stripped | 1943.735 / 2229.259 / 213.379 | 828.841 / 869.271 / 167.891 | 8424.608 / 8730.957 / 213.852 |
| task/unstripped | 2000.274 / 2356.112 / 260.145 | 1035.834 / 1113.283 / 259.812 | 9629.846 / 9966.725 / 336.562 |

RSS scope clarification: observed wait4 maxima can include the pre-exec parent/shared-mm high-water floor. They are not isolated encoder memory. Codec-specific memory qualification remains unresolved; observed values are retained without subtraction or attribution. See candidate-c2-gates.md for non-RSS conditions.
