# C2 isolated diagnostic retention

This archive retains the complete fixed schedule, all 12,144 timed observations,
88 untimed preparations, final provenance checks, source snapshot at adaea09,
corpus build metadata and worker inputs. Large ELF inputs and packed artifacts
are excluded; identities and verification outcomes remain. Original evidence
files are copied without rewriting. The separate C1 archive remains failed.

Files named *audit*, *independent*, *table*, telemetry-rootcause.json and
rss-scope.json are explicitly post-collection analyses. They are not additions
to the prospective protocol or changes to recorded outcomes. wait4 RSS can
include the pre-exec parent/shared-mm high-water mark; codec-specific memory
qualification remains unresolved. A green collection summary is not general
performance, memory, fleet or service-p99 qualification.

The current collector's later RSS-scope annotation is outside this frozen source
snapshot. No further timing cohort was run and no C1/C2 timings are pooled.

The independent bootstrap check accepts an evidence directory argument:

    go run bootstrap-c2-audit.go /absolute/path/to/extracted/c2

It recomputes the 96 current latency/size-versus-balanced launch comparisons
from observations.jsonl and checks both intervals against summary.json.
c1-pack-audit-current.json is a post-collection clarification of C1's packing
accounting, retained here without changing C1's original archive.
