# Reproducible server benchmarks

The canonical benchmark pipeline builds identical ISA payloads for native execution and microfat packaging,
runs a counterbalanced schedule, and retains raw Fortio output with resource observations and derived reports.
The existing `microfat benchmark` baseline and v1 evidence remain supported. Baseline runs accept
1 through 10,000 trials; counts outside this evidence budget fail before workload setup.

## Run an experiment

Use the Go patch in `go.mod` and install the pinned external tool explicitly:

```bash
task benchmark-tools
task benchmark BENCHMARK_CONFIG=benchmarks/config/smoke.json
```

The setup command authenticates Fortio with Go's public checksum database and checks its immutable source commit
against `benchmarks/tools.lock.json`. It records both downloaded module checksums and source provenance in
`.work/benchmark-tools/module.json`. The lock is embedded in the benchmark adapter, so its version and source
identity have one source of truth. Fortio is built with the Go patch declared by the root `go.mod`.
Experiments do not install tools. Override `MICROFAT_BENCH_FORTIO` to use another local build of the pinned version;
the experiment records the executable hash and build information.

For full CLI control:

```bash
task build
bin/microfat benchmark run --config benchmarks/config/smoke.json \
  --fortio .work/benchmark-tools/fortio --output-dir results/benchmarks
bin/microfat benchmark verify <bundle-directory>
bin/microfat benchmark report --input <bundle-directory> --format markdown
bin/microfat benchmark compare --input <bundle-directory> --json
```

The run command prints the resulting bundle path on stdout; progress and diagnostics go to stderr.
Failed trials produce evidence and a nonzero exit status. Interrupted journals are included in CI artifacts.
Raw trial JSON is deterministic and compact; the harness bounds retained trial data to 1 GiB and complete
bundles to 1.5 GiB, allowing full cgroup telemetry and separate exec traces for a 200-trial release shard. Per-file limits still apply.
Report, comparison, and verification commands operate offline.
For historical comparisons, `--head-repository <checkout>` builds the shared native payloads and head
packer/stub from that checkout; `--base-repository <checkout>` builds the base packer/stub around the
same payload bytes. `--repository` still identifies the current measurement harness source. Each
checkout's actual commit and cleanliness are recorded independently. Omitting `--head-repository`
uses `--repository` for both harness and head builds. See the
[bounded historical p99 investigation](../hosted-p99-investigation.md) for a complete protocol.
`report` and `verify` also accept original v1 evidence files. For a raw v1 payload without its envelope, verification
explicitly reports structural validation only; it cannot establish an absent checksum.

## Configure the suite

JSON suite files override validated defaults. Unknown fields and out-of-range settings are errors.

| Setting | Meaning |
| --- | --- |
| `workload` | `mixed`, `cpu`, or `memory`; deterministic handlers with bounded work |
| `blocks`, `seed` | Matched trial blocks; seed for workload inputs, bootstrap diagnostics and the default schedule |
| `schedule_seed` | Optional independent schedule seed, including zero; omission reuses `seed` without changing workload inputs |
| `duration_ms`, `warmup_ms` | Measured window and separately retained warmup |
| `payload_bytes`, `iterations`, `concurrency` | Request work and maximum in-flight requests |
| `qps` | Requested total QPS; zero selects maximum-throughput mode |
| `resolution_seconds` | Fortio histogram resolution; recorded with latency results |
| `sample_ms` | Separate observer process sampling interval, 10–1000 ms when enabled and no longer than `duration_ms` |
| `disable_observer` | Disable telemetry only for observer overhead calibration; prevents release eligibility |
| `format`, `profile`, `codec`, `dictionary` | Executable format 1/2, full/minimal, zstd/lz4/none, optional zstd dictionary |
| `specialized_level` | Host-compatible ISA level; defaults to the detected level |
| `cache_states` | `cold` and/or `warm` microfat materialization state |
| `tuning` | `matched` explicit runtime settings, or a separate `on-off` memfd experiment |
| `gomaxprocs`, `gomemlimit`, `gogc` | Identical explicit runtime settings for matched comparisons |
| `exec_diagnostics` | Additional traced execution pass, excluded from primary timing measurements |
| `runner_identity` | Maintainer-declared identity of a qualified dedicated measurement host |
| `target`, `generator` | Separate affinity masks and delegated cgroup settings |

Matched `gomemlimit` accepts microfat's human-readable byte sizes, including fractions and surrounding
whitespace; `G`, `GB`, and `GiB` all denote binary gigabytes. Child environments contain the canonical
whole-byte count. Matched `gogc`
accepts `off` or a nonnegative signed 32-bit integer and is serialized as canonical decimal text.
`gomaxprocs` must be in 1..2147483647. These explicit controls are unused and omitted in `on-off` trials.
With `disable_observer: true`, the 1000 ms observer maximum does not apply.

Example resource settings, requiring actual delegated cgroups and CPU masks allowed by the host:

```json
{
  "target": {
    "affinity": [2, 3],
    "cgroup_root": "/sys/fs/cgroup/delegated-benchmarks",
    "version": "v2",
    "cpu_quota_us": 200000,
    "cpu_period_us": 100000,
    "memory_bytes": 2147483648
  },
  "generator": {
    "affinity": [4, 5],
    "cgroup_root": "/sys/fs/cgroup/delegated-benchmarks",
    "version": "v2",
    "cpu_quota_us": 200000,
    "cpu_period_us": 100000,
    "memory_bytes": 2147483648
  }
}
```

For v1, provide `version: "v1"`, the CPU controller in `cgroup_root`, and the memory controller in `memory_root`.
The tool creates child groups, verifies settings, and attaches each child before executing the target or generator.
It does not enable parent controllers, change host frequency policy, or flush global page caches. Unavailable
controls produce explicit uncontrolled results. Resource-control failures are distinct from workload failures.

CPU masks must be disjoint; inspect recorded sibling topology when selecting physically separate cores.
Dedicated-host eligibility requires performance-governor and valid sibling-topology evidence for every CPU
in both masks, with no target/generator sibling overlap reported by either side.
Process separation alone cannot eliminate shared cache, memory-bandwidth, or kernel interference.

## Validation and revision comparisons

```bash
task benchmark-integration
task benchmark-matrix
go run ./internal/cmd/benchmark-matrix compatibility --list
go run ./internal/cmd/benchmark-matrix nightly --workload cpu
```

The compatibility matrix enumerates 16 format/profile/codec/dictionary combinations. Each case includes native,
memfd, cold materialization, and warm materialization execution. Unsupported host ISAs fail selection conservatively;
cross-compilation does not count as measured native execution.

To compare two revisions, keep this checkout as the target source/harness and provide a separate base checkout:

```bash
BENCHMARK_BASE=/absolute/path/to/base-checkout task benchmark-smoke
```

The same payload bytes are packaged by base and current packers/stubs. Both revisions are interleaved within each
trial block. Native controls use those same payloads. This measures packaging/launcher revision changes; it does
not silently change the workload source when comparing a base that predates this benchmark suite.

PR CI reports coarse startup/size regressions and retains raw evidence without posting comments. Size growth
above 5% is gated. Startup enforcement requires both a 15% increase and an independently calibrated absolute
floor. CI reads `benchmarks/config/calibration.json` from the trusted baseline checkout. Unknown runner classes,
image updates, changed measurement settings, and insufficient or unstable calibration remain explicitly report-only.
The local `--startup-calibrated` / `--startup-floor-ns` flags remain available for an explicitly supplied policy;
workflow execution uses `benchmark gate --calibration <trusted-policy.json>` instead of an unversioned variable.

## Real kernel controls

`task benchmark-kernel` requires `MICROFAT_BENCH_CGROUP_ROOT`, `MICROFAT_BENCH_CGROUP_VERSION`, and for v1,
`MICROFAT_BENCH_MEMORY_ROOT`. It fails if required controls are unavailable. Ordinary unit tests still skip
privileged integration when no root is configured; normal benchmark runs retain explicit uncontrolled fallbacks.

Hosted v2 jobs run natively on amd64 and arm64. `scripts/benchmark-controls.sh <controls.json>` creates a private
empty delegated subtree plus a manager leaf. `scripts/benchmark-enter.sh "$MICROFAT_BENCH_CGROUP_ROOT" <command>`
moves only the new command into that leaf and immediately drops back to the runner user. This keeps child
migrations inside a writable common ancestor without changing the workflow runner's own cgroup or its ownership.
The prebuilt cleanup helper runs outside this delegation before evidence upload. A protected receipt binds
its exact run, attempt, inode and owner. It requests graceful termination through PID file descriptors,
waits for an empty subtree, and uses the validated subtree's `cgroup.kill` if work survives the bounded grace.
It removes only owned empty groups and retains the receipt on failure. Native amd64/arm64 CI also proves
cleanup with orphaned manager and workload processes while an unrelated process and sibling group survive.
The original measurement/cancellation outcome and incomplete evidence remain visible.

`task benchmark-kernel-v1` boots a networkless QEMU TCG guest. The kernel and matching modules package are locked
in `benchmarks/kernel.lock.json`, checked against Ubuntu-signed metadata, and checked again after download.
The guest records kernel configuration, binary/initramfs hashes, controls, counters, and serial test results.
Missing completion, test skips, or timeout fail validation. Emulation proves kernel behavior and is never used
as performance evidence. No KVM or nested virtualization support is required.

## Hosted release evidence

All configured benchmark jobs use standard public GitHub-hosted runners. No paid runner, cloud account, homelab,
or self-hosted registration is required. CPU masks select separate available vCPUs; physical cores, hypervisor
neighbors, host frequency, and filesystem page-cache state remain outside the experiment's control.

Nightly and release runs compare base/head inside the same VM and shard by amd64/arm64, mixed/CPU/memory,
and standard/heavy intensity. Nightly compares the trusted parent. Release runs resolve the previous stable
release ancestor, excluding the current revision; absence of such an ancestor fails rather than substituting.
Release trials use 20 blocks, 10-second warmup and 30-second measurement. The compatibility tier exercises
16 format/profile/codec/dictionary cases with native, memfd, cold-cache and warm-cache configurations.

`microfat benchmark qualify --policy hosted-release --input <bundle>` verifies publication completeness:
clean matching harness/source, 20 paired blocks with at least 10-second warmup and 30-second measurement,
sampling at most every 250 ms, effective target/generator controls, core measurements,
and valid telemetry. Qualification checks the recorded warmup and steady-state load durations against the declared schedule, allowing at most 50 ms for timer/reporting precision. Both loads must have successful requests, and the total trial duration must contain their sum. Missing warmup observations cannot establish the requirement and fail publication qualification.

The effective per-trial sampling interval must match the configuration and be at most 250 ms. Offline readers load the checksummed telemetry samples: counts must match, timestamps must increase within the trial duration, and warmup must precede steady state. Each phase's first-to-last span must cover its observed load duration within two sample intervals plus 50 ms (edge sampling tolerance); adjacent samples may be separated by no more than two intervals plus 50 ms (one missed tick). A positive but short load, sparse or partial telemetry, or contradictory duration fails even when the configuration declares a complete window. These are completeness tolerances, not confidence bounds or claims about physical clock synchronization.

The command prints a JSON verdict and exits nonzero on failure. `release_eligible` retains its strict
controlled-hardware meaning and is always false on hosted runners. A measured regression can still be published
as evidence; the publication verdict does not claim improved performance. Partial exec diagnostics and host noise
remain visible qualifications. Dedicated hardware certification is future work in issue #182.

Dispatch `benchmarks.yml` with `tier=calibration` to collect 20 training and 10 holdout jobs, grouped by actual
runner class. The candidate absolute floor is twice the largest absolute no-change training median difference;
all holdout jobs must pass the coarse gate. The workflow verifies every bundle and produces a candidate policy
for review, without automatically committing it. A class lacking enough independent jobs stays report-only.
A policy records job identities and checksum-manifest digests so its inputs can be audited. The current
[30-job calibration](https://github.com/EpicBlackWolfZ/microfat/actions/runs/34452570611) split across six CPU/image
classes. None met both per-class sample counts, so the committed policy keeps startup enforcement report-only.
Independent offline verification reproduced the workflow's candidate policy byte-for-byte.

Dispatch `tier=release` on a repository branch for a nonpublishing rehearsal; `tier=compatibility` runs the
compatibility checks alone. Completed rehearsal bundles are downloaded into a fresh verification job, checked
again, replayed byte-for-byte, and audited for all 12 sustained shards before an archive is prepared. Only a
trusted tag run attaches the archive and checksum to a release draft, without replacing previous assets.
It requires the same tag/commit Release workflow to have succeeded before publishing the complete immutable release.
GoReleaser stages signed binaries and SBOMs as a draft; failed evidence leaves that draft unpublished. Failed
or interrupted evidence remains diagnostic and cannot pass matrix publication. Artifacts are scoped to the run
attempt; rerun all jobs when retrying a complete matrix so evidence from different attempts cannot be mixed.
Maintainers initiate releases by pushing tags. If finalization fails, inspect both workflow results and
rerun the failed publication job after correcting the cause; never publish a draft with missing evidence.

For a draft-only qualification, set the repository Actions variable `MICROFAT_DRAFT_ONLY_TAG` to
the exact tag before pushing it. The tag still stages and authenticates the signed draft, runs both
native installer/runtime gates and the full hosted benchmark matrix, and retains the independently
verified benchmark archive as an Actions artifact. Its automatic publication job is skipped. Other
tags retain their existing behavior. Keep the hold in place until publication is approved, then use
the explicit `release-finalize.yml` dispatch below with that successful tag run and attempt. A branch
rehearsal cannot replace this tag-bound publication evidence.

If archive delivery fails after successful measurements, dispatch `benchmark-evidence.yml`
with its exact `source_run` and `source_attempt`. A fresh standard hosted runner resolves the original source
from GitHub, requires all 12 measurement jobs and both compatibility jobs to have passed, downloads only that
attempt, and repeats every checksum, report replay, qualification and matrix
check. The manifest records measurement and verification identities separately. This workflow creates an
immutable Actions artifact and never attaches release assets. It cannot recover missing or failed measurements.
Archive uploads include the `.work` path explicitly and fail when files are missing.

Smoke and integration artifacts expire after seven days; sustained, calibration and rehearsal artifacts after
fourteen days. Archives omit temporary build files and guest images. Published claims must reference the durable
release archive, checksum, source/baseline, runner details and limitations. This documentation makes no speedup claim.

See [methodology](methodology.md) for scope, statistical assumptions, and interpretation limits.

### Recover final publication

If the tag workflow completed all measurements and independent archive verification but its
publication step failed, dispatch `release-finalize.yml` from `main` with the exact benchmark run
and attempt. Recovery verifies all 12 sustained jobs, both native compatibility jobs, archive
verification, the unchanged tag source and its successful Release build. It downloads only that
attempt's verified archive and publishes only a complete draft. Missing or failed measurements
cannot be recovered this way. Draft metadata is resolved by release ID because the by-tag API
only returns published releases. Existing evidence assets must have matching digests.
