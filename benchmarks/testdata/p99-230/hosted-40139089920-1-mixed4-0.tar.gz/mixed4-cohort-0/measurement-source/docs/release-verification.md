# Verify a release before first execution

This is the publisher contract for the [verified installer](installation.md) and future distribution
integrations. `microfat verify` checks internal integrity after a program has started; it cannot
bootstrap trust in itself. See the [threat model](../SECURITY.md#8-threat-model-and-enforcement-map).

## Trust bootstrap

Trust begins with the host OS, Bash, HTTPS/CA configuration and checksum utilities, plus the reviewed
bootstrap source. An HTTPS script command trusts that source and transport. To pin it independently,
download/review the script first and compare it with a digest from a separate trusted provisioning
record. Do not accept a checksum beside an unauthenticated script as an independent anchor.

`scripts/install.sh` embeds the reviewed Cosign release and architecture-specific SHA-256 pins.
They match `COSIGN_LINUX_AMD64` and `COSIGN_LINUX_ARM64` in
[the shared tool definitions](../.config/tool-versions.env), which are also embedded in the native helper.
Renovate updates each exact version and asset checksum together; tests require the standalone bootstrap
and native helper to use the same pins. See [dependency updates](dependency-updates.md).

It checks the verifier before execution. It does not trust a PATH Cosign. An override requires both
`--cosign /absolute/regular/executable` and `--cosign-sha256 INDEPENDENT_DIGEST`; partial pins, symlinks,
relative paths, mismatching bytes and nonexecutable tools fail. Ambient `COSIGN_*` and `SIGSTORE_*`
options are removed before verification. Same-UID and privileged malicious writers remain outside
this boundary.

The v0.3.1 bootstrap is fixed to helper release v0.3.1. It authenticates that release's checksum file with
Cosign, verifies `microfat-install_0.3.1_linux_<arch>`, and executes only the authenticated helper.
The immutable v0.3.0 bootstrap retains its original v0.3.0 helper pin. Each bootstrap's helper version
is independent of the requested product release, so the v0.3.1 helper can install historical archives.
A versioned bootstrap is usable only after its pinned helper release is published; an unsigned
snapshot proves packaging, not publisher authentication.
The [v0.3.1 acceptance record](releases/v0.3.1.md#release-acceptance) separates immutable publication,
signed-candidate qualification and public installer/tap evidence.

## Exact product release policy

1. Detect native Linux amd64/arm64. An explicit stable version is supported from v0.2.3 onward.
   Otherwise, bounded GitHub latest-stable discovery selects a version once. Discovery metadata is
   not authentication. Draft/prerelease responses are rejected, and failures never select another tag.
2. Authenticate the exact `checksums.txt` bytes using `checksums.txt.sig`, issuer
   `https://token.actions.githubusercontent.com`, and exact certificate identity
   `https://github.com/EpicBlackWolfZ/microfat/.github/workflows/release.yml@refs/tags/v<VERSION>`.
3. Retain Cosign certificate-chain and transparency verification. No alternate issuer/workflow,
   identity regex, arbitrary public key or insecure transparency bypass is accepted.
4. Strictly parse signed checksums, reject duplicates/unsafe names, require the selected exact
   `microfat_<VERSION>_linux_<arch>.tar.gz` entry, then check the archive digest before extraction.
5. Enforce archive path, type, count, size and duplicate-name bounds. Reject links and special files;
   verify required executable inventory, ELF architecture and fat CLI index without executing products.
6. Publish an owned generation only after authentication and validation. Downgrade of an existing
   managed installation requires both an exact `--version` and `--allow-downgrade`.

The helper bounds request time (two minutes), redirects (five), metadata (1 MiB), archive downloads
(256 MiB), extracted stream bytes (500 MiB), individual files (250 MiB) and archive entries (1024).
Product redirects must stay on the intended GitHub HTTPS hosts. Bootstrap downloads also require
HTTPS throughout, with bounded time, redirects and bytes; downloaded executables still require pins
or authenticated checksums before execution.

The installer does not add an independent source-commit constraint. Operators with a trusted source
pin can additionally use Cosign's `--certificate-github-workflow-sha`. The signed-draft and published
release qualification workflows do so. A tag API response alone is not an independent source anchor.

## Historical and locally staged releases

Published v0.2.3 uses the ordinary `release.yml@refs/tags/v0.2.3` identity. Do not broaden acceptance
to a historical repair workflow. v0.2.3/v0.2.4 retain CycloneDX 1.5/SPDX 2.3; v0.2.5 and later use the
modern schema policy. No immutable historical asset is rewritten. Versions below v0.2.3 have no
established installer signing contract and are refused.

A trusted helper accepts `--release-dir /absolute/assets --version VERSION` for locally downloaded
archive/checksum/bundle files, including an unpublished signed draft. It copies bounded regular files
into private staging and applies the same signature, digest and extraction policy. This avoids product
downloads, but does not promise offline Cosign root availability. Provision trusted Sigstore verification
material and test network-isolated verification separately before relying on it. Missing trust material
or unavailable root refresh remains an error; never bypass chain or transparency checks.

## What verification proves

The accepted signing identity authenticated these checksum bytes, and the chosen artifact matches its
signed digest. This does not independently prove reproducible source-to-binary builds, absence of
vulnerabilities, dependency-license completeness or an assessed SLSA level. Local ownership metadata
and running-payload checks establish consistency, not a new publisher-authentication mechanism.

[Real Cosign tests](../tests/e2e/release_signature_test.go) retain valid and wrong workflow, version,
issuer, source and key cases plus modified/missing evidence. [Acquisition tests](../internal/installrelease/)
cover bounded local/network input and authentication before extraction; [bootstrap tests](../cmd/microfat-install/bootstrap_test.go)
prove mismatched verifier/helper bytes never execute. Mocked control-flow tests are separate from actual
signature and native historical/signed-draft qualification.

## Updater verification scope

`microfat update --check` reports official HTTPS metadata only. The JSON result explicitly says
`metadata_only`; no signature verifier or product archive is downloaded for a check. An actual
update freezes one published stable version, authenticates the same independently pinned Cosign
used by the bootstrap (or an explicit path/digest override), then enforces the existing exact
workflow/tag, issuer, signed checksum and archive rules before installation. No network error or
verification failure selects a different release. Same-version and newer-than-latest no-ops do
not claim fresh artifact authentication.

Native updater qualification distinguishes controlled forward-version fixtures from real signed
historical downloads. The signed-draft gate executes the updater from authenticated candidate bytes,
performs explicit downgrades to v0.2.5 and the immediately prior v0.3.0 release, and restores the
candidate through the authenticated helper after each downgrade. Historical v0.2.x CLIs have no
updater command. This evidence is separate from publishing the candidate.
