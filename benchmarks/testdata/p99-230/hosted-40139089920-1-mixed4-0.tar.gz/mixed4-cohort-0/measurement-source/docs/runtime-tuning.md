# Container Resource Auto-Tuning (`GOMEMLIMIT` & `GOMAXPROCS`)

[**← CLI Reference**](cli-reference.md) | [**Main Index**](../README.md#documentation-guide) | [**Lifecycle Modes →**](lifecycle-modes.md)

---

This guide explains how Microfat automatically discovers container resource constraints from Linux cgroups v1 and v2, configures Go runtime parameters (`GOMEMLIMIT` and `GOMAXPROCS`) before execution, and balances memory footprint against CPU utilization using workload GC profiles.

These are resource estimates and soft runtime settings. Unavailable cgroup evidence does not prove
unlimited resources, and a configured memory limit does not guarantee freedom from OOM kills.
See the [resource bounds and trust assumptions](../SECURITY.md#resource-bounds-and-unavailable-observations).

---

## 1. The Container Performance Challenge

When running standard Go applications inside Docker or Kubernetes containers:

1. **The OOMKill Problem (`GOMEMLIMIT`)**:
   - Go's default garbage collector triggers relative to live heap size (`GOGC=100`) rather than the container's hard memory limit.
   - Under sudden spikes in allocation, the Linux kernel OOM killer terminates the container before Go reaches its GC threshold.
2. **CPU Parallelism and Quotas (`GOMAXPROCS`)**:
   - `runtime.NumCPU()` reports the logical CPUs available at process startup, without converting a cgroup CPU bandwidth quota into a CPU count. With unrestricted affinity, this may be the host count.
   - Go 1.25 introduced a container-aware default `GOMAXPROCS` and periodic updates. Microfat's default `static` policy deliberately applies its existing startup quota calculation instead; `native` preserves the application's Go CPU behavior while retaining memory and GC tuning.
   - CPU throttling depends on workload and quota. Neither policy guarantees lower latency or better throughput. See the [Go 1.25 runtime changes](https://go.dev/doc/go1.25#runtime).

---

## 2. Automatic Cgroup Inspection

Microfat uses `internal/cgroup` to inspect the container environment at startup:

Membership paths retain their whitespace suffixes so limits come from the exact cgroup directory.
On cgroup v1, a direct memory or CPU controller mount can supply its limits even when procfs also
lists membership in another controller that is unavailable under the configured mount.

```mermaid
flowchart TD
    Launcher["Launcher Startup"] --> Probe{"Inspect /sys/fs/cgroup"}
    
    Probe -->|"cgroup v2 (Unified)"| V2["Read memory.max & cpu.max"]
    Probe -->|"cgroup v1 (Legacy)"| V1["Read memory.limit_in_bytes & cpu.cfs_quota_us"]
    
    V2 --> CalcMem["Calculate GOMEMLIMIT (90% limit, 64MB min headroom)"]
    V1 --> CalcMem
    
    V2 --> CPUPolicy{"CPU policy"}
    V1 --> CPUPolicy
    CPUPolicy -->|"static (default)"| CalcCPU["Calculate GOMAXPROCS (floor quota, min 1)"]
    CPUPolicy -->|"native"| NativeCPU["Preserve application Go CPU behavior"]
    
    CalcMem --> CheckEnv{"Are variables already set?"}
    CalcCPU --> CheckEnv
    CheckEnv -->|"Already Set"| Preserve["Keep User Setting (No Override)"]
    CheckEnv -->|"Unset"| Inject["Inject into os.Environ() before execve"]
```

---

## 3. Calculation Formulas

### A. `GOMEMLIMIT` (Memory Limit)

Given an effective cgroup memory ceiling $C$ and page-rounded retained memfd storage $S$, use $M = C - S$. Cache execution uses $S = 0$; cache pages still contribute to memory pressure. If storage exhausts the ceiling, no new runtime budget is injected.

A kernel-valid `memory.max=0` or `memory.high=0` is a finite zero boundary. The hard ceiling and
CPU quota remain independently available; the effective memory ceiling is zero. Cold extraction
fails its budget check, while an existing verified warm cache can execute. Memory autotuning plans
`GOMEMLIMIT=0B`, preserves explicit runtime settings, and keeps periodic GC enabled for the batch
profile. This soft Go limit cannot make a zero kernel boundary sufficient for execution.

$$\text{ratioBudget} = \lfloor M \times \text{ratio} \rfloor$$
$$\text{headroomBudget} = \max(\lfloor M / 2 \rfloor, M - \text{minHeadroom})$$
$$\text{GOMEMLIMIT} = \min(\text{ratioBudget}, \text{headroomBudget})$$

- **Default Ratio**: `0.90` (requested 90% of usable memory ceiling)
- **Minimum Headroom**: `64 MB` (`67,108,864` bytes requested reserve for thread stacks, runtime overhead, and OS file caches)
- **Capped Headroom Policy**: For small containers where $M < 2 \times \text{minHeadroom}$ (e.g. $< 128\text{ MB}$), headroom reservation is capped at $\lceil M / 2 \rceil$ bytes. This prevents headroom from consuming more than half the container ceiling, removes the non-monotonic 64 MiB boundary cliff, and preserves lower operator ratios (e.g. `0.25` still bounds allocation at 25%).

`GOMEMLIMIT` excludes memory outside the Go runtime and may be exceeded to maintain progress.
It does not bound total process or container memory. See the [Go GC guide](https://go.dev/doc/gc-guide#Memory_limit).

Before cold extraction, the launcher estimates payload storage, dictionary bytes, decoder working
memory, a copy buffer and 64 MiB headroom. Zstd currently uses its conservative 512 MiB decoder allowance;
LZ4 uses a 12 MiB buffer allowance. These are planning estimates, not measured process-memory bounds.
An insufficient detected ceiling rejects cold extraction. Auto mode may use an already validated warm
cache entry; explicit memfd fails rather than changing execution mode. Cache extraction and page pressure
are included in the estimate too. Missing/unlimited cgroups cannot establish sufficient headroom.

The launcher derives payload size from the validated manifest. `runtimeinit` independently inspects
its executable descriptor and seals; it never trusts inherited selected-size metadata for budgeting.
Existing `GOMEMLIMIT` wins, including the launcher's injected value. Repeated runtime initialization
recomputes from the raw ceiling and does not deduct storage twice.

### B. `GOMAXPROCS` (CPU Quota)

Given a CFS quota $Q$ and period $P$:

$$\text{CPU Quota} = \frac{Q}{P}$$
$$\text{GOMAXPROCS} = \max(1, \lfloor \text{CPU Quota} \rfloor)$$

The default `static` policy uses this floor calculation, with a minimum of one CPU. The launcher
injects `GOMAXPROCS` before starting the payload; `runtimeinit` uses a positive
`runtime.GOMAXPROCS` setter unless an explicit environment setting already exists. Both disable
Go's automatic CPU updates. Microfat applies this policy at startup or a subsequent explicit
`AutoTune` call; it does not watch changing quotas or affinity. An inherited launcher setting
continues to take precedence during later initialization.

Select `MICROFAT_CPU_POLICY=native` to preserve the application's Go CPU policy while continuing
memory and GC tuning. Native mode neither injects `GOMAXPROCS`, calls its positive setter, nor
calls `runtime.SetDefaultGOMAXPROCS`. It preserves explicit `GOMAXPROCS`, `GODEBUG`, and prior
runtime setters, including settings made by other libraries. Switching from static to native
after a setter has run does not restore automatic adaptation.

For an application built with Go 1.25 or newer, the native default considers logical CPUs,
affinity, and Linux cgroup CPU bandwidth. It rounds fractional quota up and normally uses at
least two CPUs, unless logical CPU count or affinity is below two. Automatic updates follow
quota and affinity changes, up to once per second and less often while idle. A positive
`GOMAXPROCS` environment value or setter disables updates. `GODEBUG=containermaxprocs=0`
disables quota-aware defaults; `updatemaxprocs=0` disables updates. Both default to zero for
applications whose main module language version is Go 1.24 or older; the newer toolchain
alone does not guarantee adaptation. Older payload runtimes retain their own defaults.
See the [runtime CPU policy documentation](https://pkg.go.dev/runtime#GOMAXPROCS).

For example, a `1.5` CPU quota produces `1` under Microfat's static policy and normally `2`
under Go's native default. This is a policy difference, not performance evidence. Any future
default change requires representative workload measurements.

---

## 4. Environment Precedence & Opt-Out Controls

Preview these controls with `microfat doctor --gc-profile adaptive --live-heap-estimate 150MiB`.
The report separates its calculated `tuning` from `effective_environment`, which preserves
explicit `GOMEMLIMIT`, `GOMAXPROCS`, and `GOGC` values, including empty values. It always reports
`applied: false` and changes no runtime settings. The supplied heap estimate is not measured,
and doctor has no selected payload from which to deduct retained executable storage. See the
[doctor reference](cli-reference.md#microfat-doctor) for flag precedence and report fields.

Microfat strictly adheres to the following precedence order:

1. **Explicit User / Kubernetes Environment Variables (Highest Priority)**:
   - If `GOMEMLIMIT` or `GOMAXPROCS` is already present in the environment (e.g. via Kubernetes deployment manifest or CLI), Microfat **never** overrides it.
2. **Independent CPU Policy**:
   - `MICROFAT_CPU_POLICY=static` is the default. `native` preserves Go's CPU policy without disabling memory or GC tuning, for both full and minimal launchers and for `runtimeinit/autoload`.
   - Programmatic callers can use `runtimeinit.WithCPUPolicy(runtimeinit.CPUPolicyNative)`. A valid environment policy overrides this option; an invalid environment policy falls back to the valid option, or the static default. Invalid options also use the static default.
   - Policy values accept surrounding whitespace and case-insensitive `static`/`native`. Native mode does not rewrite operator settings or enable Go behavior that the application has disabled.
3. **Custom Memory Ratio**:
   - Set `MICROFAT_MEM_RATIO=0.85` to allocate 85% of memory instead of 90%.
4. **Dry-Run Simulation**:
   - Set `MICROFAT_DRY_RUN=1` or `MICROFAT_DRY_RUN=true` to simulate auto-tuning and inspect calculated limits without mutating the active Go runtime.
5. **Full Opt-Out**:
   - Set `MICROFAT_AUTOTUNE=0` or `MICROFAT_AUTOTUNE=false` to disable tuning application/injection. `runtimeinit` skips inspection; the launcher may still inspect limits for diagnostics and extraction admission checks.

---

## 5. Garbage Collection Dynamics & `GOGC` Interaction

While `microfat` automatically calculates and configures `GOMEMLIMIT` based on container cgroups, the Go runtime garbage collector balances memory footprint against CPU utilization using **both** `GOMEMLIMIT` and `GOGC`.

```mermaid
flowchart TD
    Alloc["Heap Allocations Grow"] --> CheckLimit{"Heap Approach GOMEMLIMIT?"}
    
    CheckLimit -->|"No (Ample Headroom)"| StandardGC["Standard GOGC Pacing<br>Target = LiveHeap × (1 + GOGC/100)"]
    CheckLimit -->|"Yes (Memory Pressure)"| LimitGC["GOMEMLIMIT Soft Limit Pacing<br>GC Paces Allocation Under Memory Pressure"]
    
    StandardGC --> RunGC["Execute Concurrent Mark & Sweep"]
    LimitGC --> CheckThrash{"Live Heap > Limit / (1 + GOGC/100)?"}
    
    CheckThrash -->|"No"| SmoothLimit["Smooth GC Pacing without Thrashing"]
    CheckThrash -->|"Yes"| Limiter["Pacing Tightens Toward Limit<br>50% CPU Limiter Engages if Allocation Saturates Throughput"]
    
    SmoothLimit --> RunGC
    Limiter --> RunGC
```

### 5.1 Core Mechanics & Interaction with `GOMEMLIMIT`

1. **Standard GC Pacing (`GOGC`)**:
   Under unconstrained memory, Go initiates a garbage collection cycle whenever the live heap grows by `GOGC` percent since the end of the previous cycle:

   $$\text{Target Heap} = \text{Live Heap} \times \left(1 + \frac{\text{GOGC}}{100}\right)$$

   With the default `GOGC=100`, the GC triggers when heap allocations double the live heap size ($2\times$).

2. **Memory Limit Pacing (`GOMEMLIMIT`)**:
   When `GOMEMLIMIT` is configured, the Go runtime dynamically adjusts the next GC trigger point to target a soft budget for Go-managed memory, including live heap, stacks and runtime metadata. If the target heap calculated by `GOGC` exceeds `GOMEMLIMIT`, the runtime overrides `GOGC` and triggers GC earlier.

3. **The 50% CPU GC Limiter**:
   To prevent a process from entering a death spiral where 100% of CPU time is spent garbage collecting, Go caps GC CPU consumption at **50%** of total process CPU capacity (across `GOMAXPROCS` threads). When allocations continue past this point, the runtime allows heap size to temporarily exceed `GOMEMLIMIT` rather than freezing execution.

---

### 5.2 The Proportional Target Crossover & Threshold Sizing Formula

A common operational concern in containerized Go services occurs when steady-state live heap memory approaches the configured memory budget.

#### The Proportional Target Crossover
When live heap $L$ exceeds the ratio $\frac{\text{GOMEMLIMIT}}{1 + \text{GOGC}/100}$, the garbage collector's proportional growth target would exceed the memory limit:

$$\text{Live Heap} > \frac{\text{GOMEMLIMIT}}{1 + \frac{\text{GOGC}}{100}}$$

In this condition, Go paces garbage collection more aggressively to respect `GOMEMLIMIT`. A proportional growth target exceeding `GOMEMLIMIT` does not alone demonstrate sustained GC thrashing or CPU-limiter saturation; whether thrashing occurs depends on allocation rate, object lifetimes, and collector throughput. If sustained allocation pressure forces the collector to consume 50% of CPU capacity, the runtime engages its 50% CPU limiter, temporarily allowing memory to exceed the soft `GOMEMLIMIT` to prevent CPU starvation.

#### Recommended `GOGC` Calculation Formula
Given an effective container memory ceiling $M$ (in bytes) and an expected peak live heap $L$, let $\text{Budget} = \text{CalculateGOMEMLIMIT}(M, \text{ratio}, \text{minHeadroom})$. If $\text{Budget} > L$:

$$\text{Available Headroom} = \text{Budget} - L$$
$$\text{Recommended GOGC} \le \min\left(100, \; \max\left(10, \; \left(\frac{\text{Budget}}{L} - 1\right) \times 100\right)\right)$$

---

### 5.3 Workload Tuning Recipes & Profiles

| Workload Profile | Profile Name (`MICROFAT_GC_PROFILE`) | Default `GOGC` | Default `MEM_RATIO` | Best-Fit Workload Archetype |
| :--- | :--- | :--- | :--- | :--- |
| **Latency-Critical** | `latency_critical` | `75` | `0.90` | Strict SLA APIs, gRPC services, HTTP gateways (< 10ms p99). |
| **Memory-Constrained** | `memory_constrained` | `40` | `0.80` | Micro-containers (< 256MB/512MB RAM), sidecars, microVMs. |
| **Batch / ETL** | `batch_etl` | `off` (`-1`) when a finite ceiling is active | `0.90` | Kafka stream consumers, data pipelines, compression workloads. |
| **Adaptive** | `adaptive` | Dynamic | `0.90` | Dynamic sizing via `MICROFAT_LIVE_HEAP_ESTIMATE` (e.g. `150MB`). |
| **Default** | `default` | `100` | `0.90` | General cloud microservices and daemons. |

`batch_etl` disables heap-triggered GC only when a finite effective `GOMEMLIMIT`
will be applied or is already active. Unlimited or unavailable memory limits,
and budgets exhausted by retained executable storage, preserve the existing GC
setting. A retained-storage inspection failure also prevents a new memory budget.
The launcher reports a skipped batch GC adjustment in
`MICROFAT_CGROUP_GOGC_SKIPPED_REASON`; `runtimeinit.AutoTune` reports it in
`Result.SkippedReason` and its logging telemetry.

An explicit finite user `GOMEMLIMIT` can satisfy this prerequisite. `GOMEMLIMIT=off`
does not. Programmatic tuning queries the actual Go runtime limit when preserving
an existing setting, since the environment can have changed after startup.
Explicit `GOGC` environment values and `WithGOGC` choices retain precedence,
including a deliberate user choice of `off`. Dry runs do not change runtime
settings. `GOMEMLIMIT` remains a soft Go runtime limit, not a hard process-memory
or OOM guarantee.

---

### 5.4 Kubernetes Production Deployment Manifest

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payment-service
  namespace: production
  labels:
    app.kubernetes.io/name: payment-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: payment-service
  template:
    metadata:
      labels:
        app: payment-service
    spec:
      containers:
        - name: service
          image: registry.example.com/payment-service:v1.4.0
          resources:
            requests:
              cpu: "2000m"
              memory: "1024Mi"
            limits:
              cpu: "2000m"
              memory: "1024Mi"
          env:
            # Microfat automatically discovers cgroup limits and sets:
            # GOMEMLIMIT = min(1024MB * 0.85, 1024MB - 64MB) = ~870MB
            # GOMAXPROCS = 2
            - name: MICROFAT_MEM_RATIO
              value: "0.85"
            - name: MICROFAT_GC_PROFILE
              value: "latency_critical"
            - name: MICROFAT_LOG
              value: "json"
          securityContext:
            readOnlyRootFilesystem: true
            allowPrivilegeEscalation: false
            capabilities:
              drop: ["ALL"]
```

---

## 6. Standalone Applications (`runtimeinit` & `runtimeinit/autoload`)

If you want to use the same auto-tuning logic in Go applications compiled without `microfat`, use either the automatic `runtimeinit/autoload` subpackage or the programmatic `runtimeinit` package directly.

### Automatic Initialization via Blank Import (`runtimeinit/autoload`)
Simply add a blank import to your `main.go` or application entry point to auto-tune parameters at startup:

```go
package main

import (
	_ "github.com/EpicBlackWolfZ/microfat/runtimeinit/autoload"
)

func main() {
	// GOMEMLIMIT and GOMAXPROCS are already configured before main() executes!
}
```

### Programmatic Configuration & Diagnostic Inspection
Alternatively, invoke `runtimeinit.AutoTune()` programmatically to customize parameters, select workload profiles, and inspect resolved container limits:

```go
package main

import (
	"log"

	"github.com/EpicBlackWolfZ/microfat/runtimeinit"
)

func main() {
	res := runtimeinit.AutoTune(
		runtimeinit.WithCPUPolicy(runtimeinit.CPUPolicyNative),       // Keep Go's CPU policy; memory and GC still tune
		runtimeinit.WithProfile(runtimeinit.ProfileLatencyCritical), // GOGC=75 for strict SLA microservices
		runtimeinit.WithMemoryRatio(0.85),                          // 85% instead of default 90%
		runtimeinit.WithMinHeadroom(128*1024*1024),                  // 128MB reserved headroom
	)

	log.Printf("cgroup v%d: GOMEMLIMIT=%d applied=%t, GOMAXPROCS=%d applied=%t, GOGC=%d (profile=%s, applied=%t)",
		res.CgroupVersion, res.GOMEMLIMIT, res.MemLimitApplied, res.GOMAXPROCS, res.MaxProcsApplied,
		res.GOGC, res.ProfileApplied, res.GOGCApplied)
}
```

### Adaptive Dynamic Tuning (`ProfileAdaptive`)
For dynamic `GOGC` tuning based on steady-state live heap sizing:

```go
package main

import (
	"github.com/EpicBlackWolfZ/microfat/runtimeinit"
)

func main() {
	runtimeinit.AutoTune(
		runtimeinit.WithProfile(runtimeinit.ProfileAdaptive),
		runtimeinit.WithLiveHeapEstimateString("150MB"), // Dynamic formula sizing
	)
}
```

### Simulating Container Auto-Tuning (`WithDryRun`)

Use `runtimeinit.WithDryRun(true)` (or environment variable `MICROFAT_DRY_RUN=1`) to compute and inspect the full container resource tuning plan without mutating Go runtime settings (`debug.SetMemoryLimit`, `runtime.GOMAXPROCS`, and `debug.SetGCPercent`):

Under native policy, `Result.CPUPolicy` reports `native`, the CPU plan is unset (`GOMAXPROCS=0`),
and `MaxProcsApplied=false`, including dry runs. `runtime.GOMAXPROCS(0)` can inspect current
runtime parallelism without changing it. Memory and GC plan fields remain independent.

```go
package main

import (
	"log"

	"github.com/EpicBlackWolfZ/microfat/runtimeinit"
)

func main() {
	res := runtimeinit.AutoTune(
		runtimeinit.WithDryRun(true),
		runtimeinit.WithProfile(runtimeinit.ProfileLatencyCritical),
	)

	log.Printf("dry_run=%t planned GOMEMLIMIT=%dB, planned GOMAXPROCS=%d, planned GOGC=%d (applied=%t, reason=%s)",
		res.DryRun, res.GOMEMLIMIT, res.GOMAXPROCS, res.GOGC, res.MemLimitApplied, res.SkippedReason)
}
```

### Qualifying Live Quota Changes

Run `task test-cpu-quota` with `MICROFAT_BENCH_CGROUP_ROOT` set to an existing delegated Linux
cgroup v2 subtree with CPU and memory controllers enabled. The qualification requires at least
three CPUs in the runner's allowed affinity and enough inherited CPU quota to observe the
`2` → `3` → `2` native transition. The required target fails if these controls are unavailable;
the ordinary test suite skips this opt-in qualification.

The test reuses the benchmark control harness to create and remove its own child cgroups,
attaches only fixture children, and changes only their quotas and affinity. It checks full and
minimal launchers in memfd and cache modes, standalone option/environment/autoload tuning,
static preservation, explicit CPU settings, disabled Go adaptation, dry runs, and repeated
initialization. Memory and GC tuning are checked separately. It measures behavior, not
performance. CI retains the native amd64 and arm64 qualification logs alongside kernel-control
evidence.

### Locating Original Executable & Sibling Assets (`runtimeinit.Executable`)

On Linux, three paths have different meanings:

| Path/API | Meaning |
| :--- | :--- |
| `/proc/self/exe` | Kernel-held image of the current process: the fat image during launcher startup, then the extracted payload after dispatch. |
| `os.Executable()` | Payload path: an anonymous `memfd:... (deleted)` name in memfd mode, or a content-addressed cache path in cache mode. Native binaries report their own executable path. |
| `runtimeinit.Executable()` / `MICROFAT_ORIGINAL_EXE` | Informational original deployment path supplied by the launcher, with `os.Executable()` as the native fallback. |

For application-owned configuration, prefer an explicit asset directory. This complete example also supports assets beside the deployment when that layout is intentional:

```go
package main

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/EpicBlackWolfZ/microfat/runtimeinit"
)

func main() {
	dir := os.Getenv("APP_ASSET_DIR")
	if dir == "" {
		exe, err := runtimeinit.Executable()
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		dir = filepath.Dir(exe)
	}
	data, err := os.ReadFile(filepath.Join(dir, "config.yaml"))
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Print(string(data))
}
```

With `config.yaml` beside a native or packed `app`, run `./app`; for a packed binary, both `MICROFAT_EXEC_MODE=memfd ./app` and `MICROFAT_EXEC_MODE=cache ./app` find that deployment's assets. `APP_ASSET_DIR=/opt/app/assets ./app` uses the explicit directory in all modes. On Linux, invoking a symlink to `app` uses the physical executable's directory, not the symlink's directory. The [tested example](../runtimeinit/testdata/assets_app/main.go) covers these modes and symlink invocation.

The launcher reads its kernel-held image, so startup continues with the original payload after the deployment is unlinked or atomically replaced. The exported pathname can then be absent or name a newer deployment; adjacent assets can also belong to that newer deployment. Use a stable, explicitly configured versioned asset directory when code and assets must remain paired through updates. Cache mode does not restore the original directory layout or repair every library that derives assets from `os.Executable()`.

`MICROFAT_ORIGINAL_EXE` is inherited environment data and `runtimeinit.Executable()` does not authenticate it. Neither is an identity, authorization token, or authority to overwrite a deployment. See [replacement and deliberate re-exec choices](troubleshooting.md#9-executable-paths-assets-and-deliberate-re-exec) and [transformation guards](lifecycle-modes.md#4-symlinks--atomic-in-place-operations).

For bind mounts, read-only roots and chroots, see the [mount-layout contract and native qualification](mount-layouts.md).
ARM64 user-mode emulation has a separate [QEMU descriptor-execution contract](qemu-qualification.md);
raw-path execution alone does not qualify fat-launcher dispatch.
The payload image, informational pathname and visible sibling assets are checked separately.

---

## 7. Diagnostics, Telemetry & Observability

### Downstream Environment Variables Exported

Whenever the launcher stub executes a payload variant, it exports runtime metadata to child processes in `os.Environ()`:

| Environment Variable | Description | Example |
| :--- | :--- | :--- |
| `MICROFAT_ORIGINAL_EXE` | Absolute path to original fat binary prior to memfd/cache execution (asset hint) | `/usr/local/bin/myapp` |
| `MICROFAT_SELECTED_VARIANT` | Microarchitecture level selected for execution | `v3` |
| `MICROFAT_HOST_ARCH` | Detected host CPU architecture | `amd64` |
| `MICROFAT_HOST_LEVEL` | Highest detected microarchitecture capability of host | `v4` |
| `MICROFAT_EXEC_MODE` | Runtime dispatch mechanism (`memfd` or `cache`) | `memfd` |
| `MICROFAT_DISPATCH_MODE` | Alias for `MICROFAT_EXEC_MODE` | `memfd` |
| `MICROFAT_POLICY_APPLIED` | Dispatch policy applied | `safe_avx512` |
| `MICROFAT_OVERRIDE_REASON` | Explanatory reason or rule triggering the policy | `Intel Skylake-X downclock protection` |
| `MICROFAT_SELECTED_SHA256` | SHA-256 hash of the uncompressed payload | `fda5c10d86f6...` |
| `MICROFAT_SELECTED_SIZE` | Uncompressed byte length of selected payload | `7389447` |
| `MICROFAT_CGROUP_VERSION` | Detected cgroup version (`1` or `2`) | `2` |
| `MICROFAT_CGROUP_LIMIT_BYTES` | Raw container memory limit in bytes | `2147483648` |
| `MICROFAT_CGROUP_CPUS` | Raw container CPU CFS quota | `4.00` |
| `MICROFAT_CGROUP_GOMEMLIMIT` | Computed `GOMEMLIMIT` ceiling | `1932735283B` |
| `MICROFAT_CGROUP_GOMAXPROCS` | Computed `GOMAXPROCS` core count | `4` |
| `MICROFAT_CGROUP_GOGC` | Computed `GOGC` pacing target | `75` |
| `MICROFAT_CGROUP_GC_PROFILE` | Active GC workload profile name | `latency_critical` |

### Structured Telemetry Logging (`MICROFAT_LOG=json`)

Set `MICROFAT_LOG=json` in your container environment to emit structured JSON telemetry to `stderr` upon payload dispatch:

```json
[microfat] {
  "event": "dispatch",
  "timestamp_unix_nano": 1787730797569802157,
  "host_arch": "amd64",
  "host_level": "v4",
  "selected_variant": "v3",
  "selected_sha256": "76dafaf71f0deb2febd21157b698b920b77ce5a023879183b2bec5915cf64dd4",
  "selected_size_bytes": 4100359,
  "exec_mode": "memfd",
  "policy_applied": "avx512_downclock_protection",
  "policy_reason": "Intel Skylake-X/Cascade Lake AVX-512 downclocking protection applied (capped at v3)",
  "cgroup_version": 2,
  "cgroup_mem_limit_bytes": 1073741824,
  "cgroup_cpu_quota": 4,
  "gomemlimit": "966367641B",
  "gomaxprocs": "4",
  "decompression_duration_us": 4955,
  "total_launcher_us": 5681
}
```

### Prometheus / Grafana Alerting Rules

```promql
# Alert: Go service is approaching GC thrashing under container memory limits
sum(rate(go_gc_limiter_last_limit_reached_time_seconds[5m])) by (pod) > 0

# Alert: Container memory utilization exceeds 85% of cgroup limit
container_memory_working_set_bytes{container="service"}
  / container_spec_memory_limit_bytes{container="service"} > 0.85
```

---

[**← CLI Reference**](cli-reference.md) | [**Main Index**](../README.md#documentation-guide) | [**Lifecycle Modes →**](lifecycle-modes.md)
