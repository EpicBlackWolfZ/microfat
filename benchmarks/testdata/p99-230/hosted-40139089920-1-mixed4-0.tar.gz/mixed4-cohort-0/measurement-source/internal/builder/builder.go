package builder

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"

	"github.com/EpicBlackWolfZ/microfat/internal/codec"
	"github.com/EpicBlackWolfZ/microfat/internal/format"
	"github.com/EpicBlackWolfZ/microfat/internal/pack"
)

// Common constants for builder orchestration.
const (
	defaultGoBinary = "go"
	tempDirPattern  = ".microfat-pgo-*"
	pgoOffFlag      = "-pgo=off"
	defaultPGOFile  = "default.pgo"
	defaultFileMode = 0o755
)

// BuildOptions contains configuration parameters for building and packaging PGO variants.
type BuildOptions struct {
	ManifestPath       string
	OutputPath         string
	StubPath           string
	StubProfile        string
	Concurrency        int
	KeepIntermediates  bool
	GoBinary           string
	SkipELFValidation  bool
	AllowMixedABI      bool
	ABIReportCallback  func(report *pack.ArtifactABIReport)
	Profile            string
	Compression        string
	CompressionLevel   string
	VariantCompression map[string]pack.VariantCompressionOptions
	EnableDict         bool
	DictSize           int
	FormatVersion      int
	CreatedUnix        *int64 // Optional creation metadata for Pack; nil retains wall-clock time.
	Stdout             io.Writer
	Stderr             io.Writer
	WarnFunc           pack.WarnFunc
}

// BuildResult contains metadata about the compiled and packaged fat binary.
type BuildResult struct {
	Index             *format.Index
	ABIReport         *pack.ArtifactABIReport
	OutputPath        string
	IntermediatesDir  string
	CompiledVariants  map[string]string // level -> temporary binary path
	VariantPGOApplied map[string]string // level -> pgo flag applied
}

// BuildAndPack orchestrates concurrent Go compilation of all manifest variants with Profile-Guided
// Optimization flags, then packages the resulting ELF binaries into a self-dispatching fat executable.
func BuildAndPack(ctx context.Context, m *Manifest, opts BuildOptions) (*BuildResult, error) {
	if m == nil {
		return nil, ErrInvalidManifest
	}

	mOwned := cloneManifest(m)
	if err := ValidateManifest(mOwned); err != nil {
		return nil, err
	}
	m = mOwned

	finalOutput := opts.OutputPath
	if finalOutput == "" {
		finalOutput = m.Output
	}
	if finalOutput == "" {
		return nil, errors.New("output destination path must be specified via manifest 'output' or CLI '--output'")
	}
	finalOutput = filepath.Clean(finalOutput)
	if !filepath.IsAbs(finalOutput) && m.Dir != "" {
		finalOutput = filepath.Join(m.Dir, finalOutput)
	}

	stubPath, err := ResolveStubWithOptions(ResolveStubOptions{
		CLIStub:         opts.StubPath,
		CLIProfile:      opts.StubProfile,
		ManifestStub:    m.Stub,
		ManifestProfile: m.StubProfile,
		ManifestDir:     m.Dir,
		TargetArch:      m.TargetArch,
		WarnFunc:        opts.WarnFunc,
	})
	if err != nil {
		return nil, err
	}

	goBinary := opts.GoBinary
	if goBinary == "" {
		goBinary = os.Getenv("GO")
	}
	if goBinary == "" {
		goBinary = defaultGoBinary
	}

	outDir := filepath.Dir(finalOutput)
	absOutDir, err := filepath.Abs(outDir)
	if err != nil {
		return nil, fmt.Errorf("resolving absolute output directory %s: %w", outDir, err)
	}
	if err := os.MkdirAll(absOutDir, defaultFileMode); err != nil {
		return nil, fmt.Errorf("creating output directory %s: %w", absOutDir, err)
	}

	tmpDir, err := os.MkdirTemp(absOutDir, tempDirPattern)
	if err != nil {
		return nil, fmt.Errorf("creating temporary build directory: %w", err)
	}
	absTmpDir, err := filepath.Abs(tmpDir)
	if err != nil {
		return nil, fmt.Errorf("resolving absolute temp directory %s: %w", tmpDir, err)
	}
	tmpDir = absTmpDir

	if !opts.KeepIntermediates {
		defer func() {
			_ = os.RemoveAll(tmpDir)
		}()
	}

	appName := m.AppName
	if appName == "" {
		appName = filepath.Base(finalOutput)
	}

	pgoMap, err := resolveAllVariantPGOs(m)
	if err != nil {
		return nil, err
	}

	compiledMap, identities, err := compileVariantsConcurrently(ctx, m, pgoMap, tmpDir, goBinary, opts)
	if err != nil {
		return nil, err
	}

	if err := ctx.Err(); err != nil {
		return nil, err
	}

	if err := verifyStagedIdentities(identities); err != nil {
		return nil, err
	}

	if err := ctx.Err(); err != nil {
		return nil, err
	}

	var artifactABIReport *pack.ArtifactABIReport
	userCB := opts.ABIReportCallback
	opts.ABIReportCallback = func(report *pack.ArtifactABIReport) {
		artifactABIReport = report
		if userCB != nil {
			userCB(report)
		}
	}

	packOpts := assemblePackOptions(m, stubPath, finalOutput, appName, compiledMap, opts)

	idx, err := pack.Pack(packOpts)
	if err != nil {
		return nil, fmt.Errorf("packaging fat binary: %w", err)
	}

	return &BuildResult{
		Index:             idx,
		ABIReport:         artifactABIReport,
		OutputPath:        finalOutput,
		IntermediatesDir:  tmpDir,
		CompiledVariants:  compiledMap,
		VariantPGOApplied: pgoMap,
	}, nil
}

func resolveAllVariantPGOs(m *Manifest) (map[string]string, error) {
	pkgDir := m.Package
	if !filepath.IsAbs(pkgDir) && m.Dir != "" {
		pkgDir = filepath.Join(m.Dir, pkgDir)
	}

	pgoMap := make(map[string]string, len(m.Variants))
	for _, v := range m.Variants {
		pgoFlag, err := resolveVariantPGO(v, m.DefaultPGO, m.Dir, pkgDir)
		if err != nil {
			return nil, err
		}
		pgoMap[v.Level] = pgoFlag
	}
	return pgoMap, nil
}

func resolveVariantPGO(v VariantConfig, defaultPGO, manifestDir, pkgDir string) (string, error) {
	pgoVal := v.PGO
	if strings.EqualFold(pgoVal, "off") {
		return pgoOffFlag, nil
	}

	if pgoVal != "" {
		resolved := pgoVal
		if !filepath.IsAbs(resolved) && manifestDir != "" {
			resolved = filepath.Join(manifestDir, resolved)
		}
		if _, err := os.Stat(resolved); err != nil {
			return "", fmt.Errorf("%w for variant %s: %s", ErrProfileNotFound, v.Level, resolved)
		}
		return "-pgo=" + resolved, nil
	}

	// Fallback to top-level default_pgo
	defVal := defaultPGO
	if strings.EqualFold(defVal, "off") {
		return pgoOffFlag, nil
	}

	if defVal != "" {
		resolved := defVal
		if !filepath.IsAbs(resolved) && manifestDir != "" {
			resolved = filepath.Join(manifestDir, resolved)
		}
		if _, err := os.Stat(resolved); err != nil {
			return "", fmt.Errorf("%w (default_pgo): %s", ErrProfileNotFound, resolved)
		}
		return "-pgo=" + resolved, nil
	}

	// Fallback to default.pgo in package directory
	pkgDefault := filepath.Join(pkgDir, defaultPGOFile)
	if stat, err := os.Stat(pkgDefault); err == nil && !stat.IsDir() {
		return "-pgo=" + pkgDefault, nil
	}

	return pgoOffFlag, nil
}

func compileVariantsConcurrently(
	ctx context.Context,
	m *Manifest,
	pgoMap map[string]string,
	tmpDir string,
	goBinary string,
	opts BuildOptions,
) (map[string]string, map[string]*StagedArtifactIdentity, error) {
	concurrency := opts.Concurrency
	if concurrency <= 0 {
		concurrency = runtime.NumCPU()
	}
	if concurrency > len(m.Variants) {
		concurrency = len(m.Variants)
	}
	if concurrency < 1 {
		concurrency = 1
	}

	type compileTask struct {
		variant VariantConfig
	}

	tasks := make(chan compileTask, len(m.Variants))
	for _, v := range m.Variants {
		tasks <- compileTask{variant: v}
	}
	close(tasks)

	ambient := os.Environ()

	var (
		mu          sync.Mutex
		firstErr    error
		compiledMap = make(map[string]string, len(m.Variants))
		identities  = make(map[string]*StagedArtifactIdentity, len(m.Variants))
		wg          sync.WaitGroup
	)

	ctxCancel, cancel := context.WithCancel(ctx)
	defer cancel()

	for w := 0; w < concurrency; w++ {
		wg.Go(func() {
			for task := range tasks {
				select {
				case <-ctxCancel.Done():
					mu.Lock()
					if firstErr == nil {
						if ctx.Err() != nil {
							firstErr = ctx.Err()
						} else {
							firstErr = ctxCancel.Err()
						}
					}
					mu.Unlock()
					return
				default:
				}

				v := task.variant
				outBinary := filepath.Join(tmpDir, fmt.Sprintf("bin_%s_%s", m.TargetArch, v.Level))
				pgoFlag := pgoMap[v.Level]

				cmd := buildGoCommand(ctxCancel, goBinary, m, v, pgoFlag, outBinary, ambient)
				out, err := cmd.CombinedOutput()
				if err != nil {
					mu.Lock()
					if firstErr == nil {
						if ctx.Err() != nil {
							firstErr = ctx.Err()
						} else {
							firstErr = fmt.Errorf("compiling variant %s: %w\nGo compiler output:\n%s",
								v.Level, err, strings.TrimSpace(string(out)))
						}
						cancel()
					}
					mu.Unlock()
					return
				}

				expected := ExpectedTarget{
					OS:   m.TargetOS,
					Arch: m.TargetArch,
					Tier: v.Level,
				}
				identity, valErr := ValidateArtifactBuildInfo(outBinary, expected)
				if valErr != nil {
					mu.Lock()
					if firstErr == nil {
						if ctx.Err() != nil {
							firstErr = ctx.Err()
						} else {
							firstErr = fmt.Errorf("validating variant %s artifact: %w", v.Level, valErr)
						}
						cancel()
					}
					mu.Unlock()
					return
				}

				mu.Lock()
				compiledMap[v.Level] = outBinary
				identities[v.Level] = identity
				if opts.Stdout != nil {
					_, _ = fmt.Fprintf(opts.Stdout, "  ✔ Compiled %-6s (pgo: %s)\n", v.Level, pgoFlag)
				}
				mu.Unlock()
			}
		})
	}

	wg.Wait()

	if firstErr != nil {
		return nil, nil, firstErr
	}

	if err := ctx.Err(); err != nil {
		return nil, nil, err
	}

	if len(compiledMap) != len(m.Variants) {
		return nil, nil, fmt.Errorf("incomplete build: compiled %d of %d variants", len(compiledMap), len(m.Variants))
	}
	for _, v := range m.Variants {
		if _, ok := compiledMap[v.Level]; !ok {
			return nil, nil, fmt.Errorf("incomplete build: variant %s was not compiled", v.Level)
		}
	}

	return compiledMap, identities, nil
}

func buildGoCommand(
	ctx context.Context,
	goBinary string,
	m *Manifest,
	v VariantConfig,
	pgoFlag string,
	outBinary string,
	ambient []string,
) *exec.Cmd {
	pkgTarget := m.Package
	workDir := m.Dir

	resolvedPkg := m.Package
	if !filepath.IsAbs(resolvedPkg) && m.Dir != "" {
		resolvedPkg = filepath.Join(m.Dir, resolvedPkg)
	}

	if stat, err := os.Stat(resolvedPkg); err == nil && stat.IsDir() {
		workDir = resolvedPkg
		pkgTarget = "."
	}

	args := []string{"build", "-o", outBinary}

	if pgoFlag != "" {
		args = append(args, pgoFlag)
	}

	if len(m.Tags) > 0 {
		args = append(args, "-tags="+strings.Join(m.Tags, ","))
	}

	args = append(args, m.BuildFlags...)
	args = append(args, v.Flags...)
	args = append(args, pkgTarget)

	// #nosec G204,G702 -- goBinary is user configured or PATH discovered
	cmd := exec.CommandContext(ctx, goBinary, args...)
	if workDir != "" {
		cmd.Dir = workDir
	}

	cmd.Env = assembleTargetEnv(ambient, m, v)
	return cmd
}

func assemblePackOptions(
	m *Manifest,
	stubPath, finalOutput, appName string,
	compiledMap map[string]string,
	opts BuildOptions,
) pack.Options {
	packOpts := pack.DefaultOptions()
	packOpts.StubPath = stubPath
	packOpts.OutputPath = finalOutput
	packOpts.AppName = appName
	packOpts.CreatedUnix = opts.CreatedUnix
	if m.TargetOS != "" {
		packOpts.TargetOS = m.TargetOS
	}
	if m.TargetArch != "" {
		packOpts.TargetArch = m.TargetArch
	}
	packOpts.Variants = compiledMap
	packOpts.SkipELFValidation = opts.SkipELFValidation
	packOpts.AllowMixedABI = opts.AllowMixedABI
	packOpts.ABIReportCallback = opts.ABIReportCallback
	if opts.FormatVersion != 0 {
		packOpts.FormatVersion = opts.FormatVersion
	}

	if m.Compression != nil {
		if m.Compression.Profile != "" {
			packOpts.Profile = m.Compression.Profile
		}
		if m.Compression.Algorithm != "" {
			packOpts.Compression = m.Compression.Algorithm
		}
		if m.Compression.Level != "" {
			packOpts.CompressionLevel = m.Compression.Level
		}
		if m.Compression.EnableDict {
			packOpts.EnableDict = true
		}
		if m.Compression.DictSize > 0 {
			packOpts.DictSize = m.Compression.DictSize
		}
	}

	if opts.Profile != "" {
		packOpts.Profile = opts.Profile
	}
	if opts.Compression != "" {
		packOpts.Compression = opts.Compression
		if _, inlineLevel := codec.ParseCompressionSpec(opts.Compression); inlineLevel != "" {
			packOpts.CompressionLevel = inlineLevel
		}
	}
	if opts.CompressionLevel != "" {
		packOpts.CompressionLevel = opts.CompressionLevel
	}
	if opts.EnableDict {
		packOpts.EnableDict = true
	}
	if opts.DictSize > 0 {
		packOpts.DictSize = opts.DictSize
	}

	packOpts.VariantCompression = assembleVariantCompression(m.Variants, opts.VariantCompression)

	if opts.WarnFunc != nil {
		packOpts.WarnFunc = opts.WarnFunc
	} else if opts.Stderr != nil {
		packOpts.WarnFunc = func(format string, args ...any) {
			var msg string
			if len(args) == 0 {
				msg = format
			} else {
				msg = fmt.Sprintf(format, args...)
			}
			_, _ = fmt.Fprintf(opts.Stderr, "[microfat:warn] %s\n", msg)
		}
	}

	packOpts.VariantValidator = func(level, snapshottedPath string) error {
		expected := ExpectedTarget{
			OS:   m.TargetOS,
			Arch: m.TargetArch,
			Tier: level,
		}
		if _, err := ValidateArtifactBuildInfo(snapshottedPath, expected); err != nil {
			return fmt.Errorf("validating snapshotted variant %s build metadata: %w", level, err)
		}
		return nil
	}

	return packOpts
}

func assembleVariantCompression(
	variants []VariantConfig,
	overrides map[string]pack.VariantCompressionOptions,
) map[string]pack.VariantCompressionOptions {
	merged := make(map[string]pack.VariantCompressionOptions, len(variants)+len(overrides))
	for _, variant := range variants {
		if variant.Compression != nil {
			merged[format.NormalizeVariant(variant.Level)] = pack.VariantCompressionOptions{
				Profile:     variant.Compression.Profile,
				Compression: variant.Compression.Algorithm,
				Level:       variant.Compression.Level,
			}
		}
	}
	for level, override := range overrides {
		level = format.NormalizeVariant(level)
		compression := merged[level]
		if override.Profile != "" {
			compression.Profile = override.Profile
		}
		if override.Compression != "" {
			compression.Compression = override.Compression
			if _, inlineLevel := codec.ParseCompressionSpec(override.Compression); inlineLevel != "" {
				compression.Level = inlineLevel
			}
		}
		if override.Level != "" {
			compression.Level = override.Level
		}
		merged[level] = compression
	}
	if len(merged) == 0 {
		return nil
	}
	return merged
}
