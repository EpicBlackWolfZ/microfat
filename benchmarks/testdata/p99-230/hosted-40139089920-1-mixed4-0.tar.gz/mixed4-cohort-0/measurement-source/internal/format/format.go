// Package format defines the microfat binary trailer, index structure, integrity verification,
// and serialization logic.
package format

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"

	"github.com/EpicBlackWolfZ/microfat/internal/microarch"
)

// Constants for binary layout and verification.
const (
	// MagicString identifies a microfat-enabled fat executable.
	MagicString = "\x00\xFA\x7FMICRO"

	// TrailerSize is the fixed size of the trailer at EOF:
	// 8 bytes IndexOffset + 8 bytes IndexSize + 32 bytes IndexSHA256 + 8 bytes Magic.
	TrailerSize = 56

	// OffsetLen is length in bytes of uint64 fields in trailer.
	OffsetLen = 8

	// SizeLen is length in bytes of uint64 size fields in trailer.
	SizeLen = 8

	// HashLen is the byte length of SHA-256 checksums.
	HashLen = 32

	// MagicLen is the length of magic string in bytes.
	MagicLen = 8

	// IndexMagicV2 is the 4-byte magic signature at the start of Format v2 binary indices.
	IndexMagicV2 = "\x00\xFAM2"

	// FormatVersion1 is the legacy JSON manifest format.
	FormatVersion1 = 1

	// FormatVersion2 is the reflection-free compact binary index table format.
	FormatVersion2 = 2

	// FormatVersionCurrent is the default format version used for new fat binaries.
	FormatVersionCurrent = FormatVersion2

	// MaxIndexSize is the maximum allowable index table size (1 MB).
	MaxIndexSize = 1024 * 1024

	// MaxPayloadSize is the maximum allowable single payload uncompressed size (1 GB).
	MaxPayloadSize = 1024 * 1024 * 1024

	// MaxDictionarySize is the maximum allowable shared dictionary size (1 MB).
	MaxDictionarySize = 1024 * 1024

	// Environment variable names for telemetry and control.
	EnvSelectedVariant           = "MICROFAT_SELECTED_VARIANT"
	EnvHostArch                  = "MICROFAT_HOST_ARCH"
	EnvHostLevel                 = "MICROFAT_HOST_LEVEL"
	EnvExecMode                  = "MICROFAT_EXEC_MODE"
	EnvDispatchMode              = "MICROFAT_DISPATCH_MODE"
	EnvSelectedSHA256            = "MICROFAT_SELECTED_SHA256"
	EnvSelectedSize              = "MICROFAT_SELECTED_SIZE"
	EnvCgroupVersion             = "MICROFAT_CGROUP_VERSION"
	EnvCgroupGOMEMLIMIT          = "MICROFAT_CGROUP_GOMEMLIMIT"
	EnvCgroupGOMAXPROCS          = "MICROFAT_CGROUP_GOMAXPROCS"
	EnvCgroupLimitBytes          = "MICROFAT_CGROUP_LIMIT_BYTES"
	EnvCgroupHighBytes           = "MICROFAT_CGROUP_HIGH_BYTES"
	EnvCgroupEffectiveLimitBytes = "MICROFAT_CGROUP_EFFECTIVE_LIMIT_BYTES"
	EnvCgroupCPUs                = "MICROFAT_CGROUP_CPUS"
	EnvCgroupGOGC                = "MICROFAT_CGROUP_GOGC"
	EnvCgroupGOGCSkippedReason   = "MICROFAT_CGROUP_GOGC_SKIPPED_REASON"
	EnvCgroupGCProfile           = "MICROFAT_CGROUP_GC_PROFILE"
	EnvDebug                     = "MICROFAT_DEBUG"
	EnvLog                       = "MICROFAT_LOG"
	EnvAutotune                  = "MICROFAT_AUTOTUNE"
	EnvCPUPolicy                 = "MICROFAT_CPU_POLICY"
	EnvDryRun                    = "MICROFAT_DRY_RUN"
	EnvMemRatio                  = "MICROFAT_MEM_RATIO"
	EnvGCProfile                 = "MICROFAT_GC_PROFILE"
	EnvLiveHeapEstimate          = "MICROFAT_LIVE_HEAP_ESTIMATE"
	EnvForceLevel                = "MICROFAT_FORCE_LEVEL"
	EnvMaxLevel                  = "MICROFAT_MAX_LEVEL"
	EnvDisableVariants           = "MICROFAT_DISABLE_VARIANTS"
	EnvPolicy                    = "MICROFAT_POLICY"
	EnvAVX512DownclockProtection = "MICROFAT_AVX512_DOWNCLOCK_PROTECTION"
	EnvCacheDir                  = "MICROFAT_CACHE_DIR"
	EnvVerifyCache               = "MICROFAT_VERIFY_CACHE"
	EnvPolicyApplied             = "MICROFAT_POLICY_APPLIED"
	EnvOverrideReason            = "MICROFAT_OVERRIDE_REASON"

	// EnvOriginalExe specifies the informational asset-resolution hint indicating the
	// original fat binary path prior to memfd/cache execution.
	//
	// Security boundary: This variable is strictly an informational asset-resolution hint
	// for locating neighboring filesystem resources (configurations, plugins, static assets,
	// sibling CLI binaries). It is propagated via the process environment and must NOT be used
	// by applications or libraries as a cryptographic identity, access-control token, or
	// trusted binary origin.
	EnvOriginalExe = "MICROFAT_ORIGINAL_EXE"

	// Execution modes.
	ExecModeAuto  = "auto"
	ExecModeMemfd = "memfd"
	ExecModeCache = "cache"

	// Telemetry event types.
	EventDispatch = "dispatch"
	EventError    = "dispatch_error"
	EventPrewarm  = "prewarm"

	// File permissions.
	PrivateCacheDirMode = 0o700
	PrivateExecMode     = 0o700
)

var userHomeDirFunc = os.UserHomeDir

// Standard error definitions for binary format parsing and execution.
var (
	ErrBinaryTooSmall      = errors.New("binary size is smaller than trailer size")
	ErrInvalidMagic        = errors.New("invalid microfat magic bytes at EOF")
	ErrUnsupportedVersion  = errors.New("unsupported microfat format version")
	ErrInvalidIndexOffset  = errors.New("invalid index offset in trailer")
	ErrInvalidIndexSize    = errors.New("invalid index size in trailer")
	ErrIndexCorrupted      = errors.New("index SHA-256 checksum mismatch")
	ErrOutOfBounds         = errors.New("variant payload extends beyond binary boundary")
	ErrPayloadTooLarge     = errors.New("variant payload size exceeds safety limit")
	ErrOverlappingVariant  = errors.New("variant payloads overlap or are unsorted")
	ErrTruncatedIndex      = errors.New("truncated index data")
	ErrInvalidJSONSyntax   = errors.New("invalid json syntax in manifest index")
	ErrDictionaryCorrupted = errors.New("shared dictionary SHA-256 checksum mismatch")
	ErrPayloadCorrupted    = errors.New("variant payload SHA-256 checksum mismatch")
	ErrInvalidDictionary   = errors.New("invalid shared dictionary offset or size")
	ErrInvalidChecksum     = errors.New("invalid sha256 checksum format")
	ErrNoVariantsSpecified = errors.New("at least one microarchitecture variant must be specified")
	ErrDuplicateVariant    = errors.New("duplicate or conflicting variant level in index")
	ErrInvalidVariant      = errors.New("invalid or empty variant level")

	// Launcher execution stage sentinels for typed error diagnostics.
	ErrMemfdCreate        = errors.New("memfd_create failed")
	ErrMemfdSealingFailed = errors.New("memfd sealing failed")
	ErrMemfdExtract       = errors.New("memfd payload extraction failed")
	ErrExecve             = errors.New("execve failed")
	ErrCacheInit          = errors.New("cache directory initialization failed")
	ErrInsecureCacheDir   = errors.New("cache directory has insecure permissions or invalid ownership")
	ErrCacheWrite         = errors.New("cache file creation failed")
	ErrCacheExtract       = errors.New("cache decompression failed")
)

// VariantEntry describes an individual compressed microarchitecture variant payload.
type VariantEntry struct {
	Level            string `json:"level"`             // Microarchitecture level (e.g., "v1", "v2", "v3", "v4")
	Offset           int64  `json:"offset"`            // Absolute byte offset in the fat binary
	CompressedSize   int64  `json:"compressed_size"`   // Compressed zstd byte length
	UncompressedSize int64  `json:"uncompressed_size"` // Raw binary byte length
	SHA256           string `json:"sha256,omitempty"`  // Checksum of uncompressed payload
	Compression      string `json:"compression"`       // Compression algorithm (e.g., "zstd")
}

// Index holds the manifest of all embedded variants and target platform metadata.
type Index struct {
	Version          int            `json:"version"`
	AppName          string         `json:"app_name,omitempty"`
	TargetOS         string         `json:"os"`
	TargetArch       string         `json:"arch"`
	CreatedUnix      int64          `json:"created_unix"`
	DictionaryOffset int64          `json:"dictionary_offset,omitempty"`
	DictionarySize   int64          `json:"dictionary_size,omitempty"`
	DictionarySHA256 string         `json:"dictionary_sha256,omitempty"`
	DictionaryID     uint32         `json:"dictionary_id,omitempty"`
	Variants         []VariantEntry `json:"variants"`
}

// DispatchTelemetry records structured runtime execution metadata and performance timings.
type DispatchTelemetry struct {
	Event                   string  `json:"event"`
	TimestampUnixNano       int64   `json:"timestamp_unix_nano"`
	HostArch                string  `json:"host_arch"`
	HostLevel               string  `json:"host_level"`
	SelectedVariant         string  `json:"selected_variant"`
	SelectedSHA256          string  `json:"selected_sha256,omitempty"`
	SelectedSizeBytes       int64   `json:"selected_size_bytes,omitempty"`
	ExecMode                string  `json:"exec_mode"`
	PolicyApplied           string  `json:"policy_applied,omitempty"`
	PolicyReason            string  `json:"policy_reason,omitempty"`
	CgroupVersion           int     `json:"cgroup_version,omitempty"`
	CgroupMemLimitBytes     int64   `json:"cgroup_mem_limit_bytes,omitempty"`
	CgroupCPUQuota          float64 `json:"cgroup_cpu_quota,omitempty"`
	GOMEMLIMIT              string  `json:"gomemlimit,omitempty"`
	GOMAXPROCS              string  `json:"gomaxprocs,omitempty"`
	GOGC                    string  `json:"gogc,omitempty"`
	GCProfile               string  `json:"gc_profile,omitempty"`
	DecompressionDurationUs int64   `json:"decompression_duration_us,omitempty"`
	TotalLauncherUs         int64   `json:"total_launcher_us"`
}

// ExecutionAttempt records the details of an individual dispatch attempt.
type ExecutionAttempt struct {
	Stage         string `json:"stage"`
	RequestedMode string `json:"requested_mode"`
	AttemptedMode string `json:"attempted_mode"`
	Err           error  `json:"-"`
	Error         string `json:"error"`
	Errno         int    `json:"errno,omitempty"`
	ErrnoName     string `json:"errno_name,omitempty"`
}

// DispatchError records the ordered execution attempts that failed during dispatch.
type DispatchError struct {
	PrimarySentinel error
	RequestedMode   string
	Attempts        []ExecutionAttempt
	Summary         string
}

func (e *DispatchError) Error() string {
	if e.Summary != "" {
		return e.Summary
	}
	if len(e.Attempts) == 1 {
		return fmt.Sprintf("%v: %s", e.PrimarySentinel, e.Attempts[0].Error)
	}
	var b strings.Builder
	b.WriteString(fmt.Sprintf("%v: dispatch failed in %s mode (attempts: ", e.PrimarySentinel, e.RequestedMode))
	for i, att := range e.Attempts {
		if i > 0 {
			b.WriteString("; ")
		}
		b.WriteString(fmt.Sprintf("[%s/%s: %s]", att.AttemptedMode, att.Stage, att.Error))
	}
	b.WriteString(")")
	return b.String()
}

func (e *DispatchError) Unwrap() error {
	return e.PrimarySentinel
}

func (e *DispatchError) Is(target error) bool {
	if errors.Is(e.PrimarySentinel, target) {
		return true
	}
	for _, att := range e.Attempts {
		if errors.Is(att.Err, target) {
			return true
		}
	}
	return false
}

func (e *DispatchError) As(target any) bool {
	if errors.As(e.PrimarySentinel, target) {
		return true
	}
	for _, att := range e.Attempts {
		if errors.As(att.Err, target) {
			return true
		}
	}
	return false
}

// ExtractErrno inspects an error for a syscall.Errno and returns its numeric value and symbol name.
func ExtractErrno(err error) (int, string) {
	if err == nil {
		return 0, ""
	}
	var errno syscall.Errno
	if errors.As(err, &errno) {
		name := errnoName(errno)
		return int(errno), name
	}
	return 0, ""
}

func errnoName(errno syscall.Errno) string {
	switch errno {
	case syscall.EPERM:
		return "EPERM"
	case syscall.ENOENT:
		return "ENOENT"
	case syscall.EACCES:
		return "EACCES"
	case syscall.EBADF:
		return "EBADF"
	case syscall.ENOMEM:
		return "ENOMEM"
	case syscall.EEXIST:
		return "EEXIST"
	case syscall.EINVAL:
		return "EINVAL"
	case syscall.ENFILE:
		return "ENFILE"
	case syscall.EMFILE:
		return "EMFILE"
	case syscall.ETXTBSY:
		return "ETXTBSY"
	case syscall.ENOSPC:
		return "ENOSPC"
	case syscall.EROFS:
		return "EROFS"
	case syscall.ENOEXEC:
		return "ENOEXEC"
	case syscall.ENOSYS:
		return "ENOSYS"
	default:
		return fmt.Sprintf("ERRNO_%d", int(errno))
	}
}

// ErrorTelemetry records structured error events during launcher initialization or dispatch.
type ErrorTelemetry struct {
	Event             string             `json:"event"`
	TimestampUnixNano int64              `json:"timestamp_unix_nano"`
	HostArch          string             `json:"host_arch,omitempty"`
	HostLevel         string             `json:"host_level,omitempty"`
	SelectedVariant   string             `json:"selected_variant,omitempty"`
	PolicyApplied     string             `json:"policy_applied,omitempty"`
	PolicyReason      string             `json:"policy_reason,omitempty"`
	Stage             string             `json:"stage"`
	RequestedMode     string             `json:"requested_mode,omitempty"`
	AttemptedMode     string             `json:"attempted_mode,omitempty"`
	Error             string             `json:"error"`
	Errno             int                `json:"errno,omitempty"`
	ErrnoName         string             `json:"errno_name,omitempty"`
	Attempts          []ExecutionAttempt `json:"attempts,omitempty"`
	Details           string             `json:"details,omitempty"`
	Hint              string             `json:"hint,omitempty"`
}

// Prewarm and verify status constants.
const (
	PrewarmStatusExtracted     = "extracted"
	PrewarmStatusAlreadyCached = "already_cached"
	PrewarmStatusValid         = "valid"
	PrewarmStatusMissing       = "missing"
	PrewarmStatusCorrupted     = "corrupted"
)

// PrewarmResult records the cache status for an individual prewarmed or verified variant.
type PrewarmResult struct {
	Level            string `json:"level"`
	SHA256           string `json:"sha256"`
	UncompressedSize int64  `json:"uncompressed_size"`
	CachedPath       string `json:"cached_path"`
	AlreadyCached    bool   `json:"already_cached"`
	DecompressionUs  int64  `json:"decompression_us,omitempty"`
	Valid            bool   `json:"valid"`
	Status           string `json:"status,omitempty"`
	Error            string `json:"error,omitempty"`
}

// PrewarmTelemetry records structured telemetry for a prewarm operation.
type PrewarmTelemetry struct {
	Event             string          `json:"event"`
	TimestampUnixNano int64           `json:"timestamp_unix_nano"`
	AppName           string          `json:"app_name,omitempty"`
	CacheDir          string          `json:"cache_dir"`
	Results           []PrewarmResult `json:"results"`
}

// BinaryInfo represents the structured JSON output for launcher inspection.
type BinaryInfo struct {
	AppName          string         `json:"app_name"`
	TargetOS         string         `json:"target_os"`
	TargetArch       string         `json:"target_arch"`
	FatBinarySize    int64          `json:"fat_binary_size"`
	HostOS           string         `json:"host_os"`
	HostArch         string         `json:"host_arch"`
	HostLevel        string         `json:"host_level"`
	SelectedVariant  string         `json:"selected_variant"`
	SelectedSize     int64          `json:"selected_size"`
	SelectionError   string         `json:"selection_error,omitempty"`
	ExecMode         string         `json:"exec_mode"`
	PolicyApplied    string         `json:"policy_applied,omitempty"`
	PolicyReason     string         `json:"policy_reason,omitempty"`
	DictionaryOffset int64          `json:"dictionary_offset,omitempty"`
	DictionarySize   int64          `json:"dictionary_size,omitempty"`
	DictionarySHA256 string         `json:"dictionary_sha256,omitempty"`
	DictionaryID     uint32         `json:"dictionary_id,omitempty"`
	Cgroup           *CgroupInfo    `json:"cgroup,omitempty"`
	Runtime          *RuntimeInfo   `json:"runtime,omitempty"`
	Variants         []VariantEntry `json:"variants"`
	HostFeatures     []string       `json:"host_features"`
}

// CgroupInfo represents container cgroup telemetry and auto-tuning limits.
type CgroupInfo struct {
	Version                    int     `json:"version"`
	Status                     string  `json:"status,omitempty"`
	Error                      string  `json:"error,omitempty"`
	MemoryLimitBytes           int64   `json:"memory_limit_bytes"`
	MemoryLimitStatus          string  `json:"memory_limit_status,omitempty"`
	MemoryHighBytes            int64   `json:"memory_high_bytes,omitempty"`
	MemoryHighStatus           string  `json:"memory_high_status,omitempty"`
	EffectiveMemoryLimitBytes  int64   `json:"effective_memory_limit_bytes,omitempty"`
	EffectiveMemoryLimitStatus string  `json:"effective_memory_limit_status,omitempty"`
	CPUQuota                   float64 `json:"cpu_quota"`
	CPUQuotaStatus             string  `json:"cpu_quota_status,omitempty"`
	GOMEMLIMIT                 string  `json:"gomemlimit,omitempty"`
	GOMAXPROCS                 int     `json:"gomaxprocs,omitempty,omitzero"`
	GOGC                       string  `json:"gogc,omitempty"`
	GCProfile                  string  `json:"gc_profile,omitempty"`
}

// RuntimeInfo describes prospective execution candidates; inspection does not execute a payload.
type RuntimeInfo struct {
	Autotune   string             `json:"autotune"`
	CPUPolicy  string             `json:"cpu_policy"`
	Candidates []RuntimeCandidate `json:"candidates"`
}

// RuntimeCandidate separates computed tuning from the environment a candidate would receive.
type RuntimeCandidate struct {
	ExecMode                string                             `json:"exec_mode"`
	RetainedExecutableBytes int64                              `json:"retained_executable_bytes"`
	Tuning                  RuntimeTuningInfo                  `json:"tuning"`
	EffectiveEnvironment    map[string]RuntimeEnvironmentValue `json:"effective_environment"`
}

// RuntimeTuningInfo is a computed candidate plan, before opt-outs and inherited runtime overrides.
type RuntimeTuningInfo struct {
	Available         bool    `json:"available"`
	GOMEMLIMIT        string  `json:"gomemlimit,omitempty"`
	GOMEMLIMITBytes   int64   `json:"gomemlimit_bytes,omitempty"`
	GOMAXPROCS        int     `json:"gomaxprocs,omitempty"`
	GOMAXPROCSValue   string  `json:"gomaxprocs_value,omitempty"`
	GOGC              string  `json:"gogc,omitempty"`
	GCProfile         string  `json:"gc_profile,omitempty"`
	AppliedRatio      float64 `json:"applied_ratio,omitempty"`
	ConstrainingLimit string  `json:"constraining_limit,omitempty"`
	GOGCSkippedReason string  `json:"gogc_skipped_reason,omitempty"`
}

// RuntimeEnvironmentValue preserves the distinction between an absent and an empty inherited variable.
type RuntimeEnvironmentValue struct {
	Present bool   `json:"present"`
	Value   string `json:"value"`
	Source  string `json:"source"`
}

// NormalizeVariant cleans up and standardizes variant level strings
// (e.g. "amd64_v3" -> "v3", "V3" -> "v3", "v8.0" -> "v8.0", "arm64-v8.2" -> "v8.2").
func NormalizeVariant(level string) string {
	return microarch.Normalize(level)
}

// VariantLevels returns a slice of all variant level strings present in the index.
func (idx *Index) VariantLevels() []string {
	levels := make([]string, len(idx.Variants))
	for i, v := range idx.Variants {
		levels[i] = v.Level
	}
	return levels
}

// FindVariant returns the VariantEntry corresponding to the specified level string, performing normalized matching.
func (idx *Index) FindVariant(level string) (*VariantEntry, bool) {
	norm := NormalizeVariant(level)
	for i := range idx.Variants {
		if NormalizeVariant(idx.Variants[i].Level) == norm {
			return &idx.Variants[i], true
		}
	}
	return nil, false
}

// ValidateBounds verifies that all variants and offsets in the index are within safe boundaries.
func (idx *Index) ValidateBounds(indexOffset int64) error {
	if idx.Version != FormatVersion1 && idx.Version != FormatVersion2 {
		return fmt.Errorf("%w: got version %d, expected %d or %d", ErrUnsupportedVersion, idx.Version, FormatVersion1, FormatVersion2)
	}

	if indexOffset < 0 {
		return fmt.Errorf("%w: invalid negative index offset %d", ErrOutOfBounds, indexOffset)
	}

	if len(idx.Variants) == 0 {
		return ErrNoVariantsSpecified
	}

	targetArch := strings.ToLower(strings.TrimSpace(idx.TargetArch))
	if targetArch != microarch.ArchAMD64 && targetArch != microarch.ArchARM64 {
		return fmt.Errorf("%w: unrecognized target architecture %q", ErrInvalidVariant, idx.TargetArch)
	}

	lastEnd, err := idx.validateDictionaryBounds(indexOffset)
	if err != nil {
		return err
	}

	return idx.validateVariantBounds(indexOffset, lastEnd)
}

func (idx *Index) validateDictionaryBounds(indexOffset int64) (int64, error) {
	if idx.DictionarySize < 0 || idx.DictionarySize > MaxDictionarySize {
		return 0, fmt.Errorf("%w: invalid dictionary size %d (max allowed %d bytes)",
			ErrInvalidDictionary, idx.DictionarySize, MaxDictionarySize)
	}

	if idx.DictionarySize == 0 {
		return 0, nil
	}

	if idx.DictionaryOffset < 0 {
		return 0, fmt.Errorf("%w: invalid dictionary offset %d", ErrInvalidDictionary, idx.DictionaryOffset)
	}
	if idx.DictionarySHA256 == "" || !ValidateChecksum(idx.DictionarySHA256) {
		return 0, fmt.Errorf("%w: dictionary missing or invalid sha256 checksum", ErrInvalidChecksum)
	}
	if idx.DictionaryOffset > indexOffset || idx.DictionarySize > indexOffset-idx.DictionaryOffset {
		return 0, fmt.Errorf("%w: dictionary payload extends past index offset %d", ErrOutOfBounds, indexOffset)
	}
	return idx.DictionaryOffset + idx.DictionarySize, nil
}

func (idx *Index) validateVariantBounds(indexOffset int64, lastEnd int64) error {
	seenLevels := make(map[string]struct{}, len(idx.Variants))
	for i, v := range idx.Variants {
		if strings.TrimSpace(v.Level) == "" {
			return fmt.Errorf("%w: variant at index %d has empty level", ErrInvalidVariant, i)
		}
		normLevel := NormalizeVariant(v.Level)
		if microarch.Rank(idx.TargetArch, normLevel) <= 0 {
			return fmt.Errorf("%w: variant %q is not a valid tier for target arch %q", ErrInvalidVariant, v.Level, idx.TargetArch)
		}
		if _, exists := seenLevels[normLevel]; exists {
			return fmt.Errorf("%w: duplicate normalized variant level %q", ErrDuplicateVariant, normLevel)
		}
		seenLevels[normLevel] = struct{}{}

		if v.Offset < 0 || v.CompressedSize <= 0 || v.UncompressedSize <= 0 {
			return fmt.Errorf("%w: invalid dimensions for variant %s", ErrOutOfBounds, v.Level)
		}
		if v.UncompressedSize > MaxPayloadSize {
			return fmt.Errorf("%w: variant %s exceeds 1GB limit (%d bytes)", ErrPayloadTooLarge, v.Level, v.UncompressedSize)
		}
		if v.Offset > indexOffset || v.CompressedSize > indexOffset-v.Offset {
			return fmt.Errorf("%w: variant %s payload extends past index offset %d", ErrOutOfBounds, v.Level, indexOffset)
		}
		if (i > 0 || idx.DictionarySize > 0) && v.Offset < lastEnd {
			return fmt.Errorf("%w: variant %s offset %d overlaps with previous data ending at %d",
				ErrOverlappingVariant, v.Level, v.Offset, lastEnd)
		}
		lastEnd = v.Offset + v.CompressedSize

		if v.SHA256 == "" || !ValidateChecksum(v.SHA256) {
			return fmt.Errorf("%w: variant %s missing or invalid sha256 checksum", ErrInvalidChecksum, v.Level)
		}
	}
	return nil
}

const (
	maxSHA256HexLen             = 64
	defaultCompressionAlgorithm = "zstd"
	minBinaryHeaderSize         = 34
	binaryHeaderFixedSize       = 34
	initialVariantCap           = 4
	decimalBase                 = 10
	asciiControlCutoff          = 0x20
	uint16LenPrefixSize         = 2
	uint64FieldSize             = 8
)

// ValidateChecksum verifies that a SHA-256 hex string contains exactly 64 valid hex characters.
// An empty string is treated as valid to support optional dictionary or unchecksummed fields.
func ValidateChecksum(s string) bool {
	if s == "" {
		return true
	}
	if len(s) != maxSHA256HexLen {
		return false
	}
	for i := 0; i < len(s); i++ {
		c := s[i]
		if !((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')) {
			return false
		}
	}
	return true
}

// MarshalBinaryIndex serializes an Index struct into a compact Format v2 binary representation.
func MarshalBinaryIndex(idx *Index) ([]byte, error) {
	if len(idx.TargetOS) > 255 || len(idx.TargetArch) > 255 || len(idx.AppName) > 65535 ||
		len(idx.Variants) > 65535 || len(idx.DictionarySHA256) > 255 {
		return nil, errors.New("index metadata field exceeds binary format limits")
	}

	if idx.DictionarySize > 0 && (idx.DictionarySHA256 == "" || !ValidateChecksum(idx.DictionarySHA256)) {
		return nil, fmt.Errorf("%w: dictionary missing required SHA-256 digest in Format v2", ErrInvalidChecksum)
	}

	totalSize := binaryHeaderFixedSize + 1 + len(idx.DictionarySHA256) +
		1 + len(idx.TargetOS) + 1 + len(idx.TargetArch) + uint16LenPrefixSize + len(idx.AppName) + uint16LenPrefixSize
	for _, v := range idx.Variants {
		comp := v.Compression
		if comp == "" {
			comp = defaultCompressionAlgorithm
		}
		if v.SHA256 == "" || !ValidateChecksum(v.SHA256) {
			return nil, fmt.Errorf("%w: variant %s missing required SHA-256 digest in Format v2", ErrInvalidChecksum, v.Level)
		}
		if len(v.Level) > 255 || len(v.SHA256) > 255 || len(comp) > 255 {
			return nil, fmt.Errorf("variant %s field length exceeds binary format limits", v.Level)
		}
		totalSize += 1 + len(v.Level) + uint64FieldSize + uint64FieldSize + uint64FieldSize + 1 + len(v.SHA256) + 1 + len(comp)
	}

	buf := make([]byte, totalSize)
	copy(buf[0:4], []byte(IndexMagicV2))
	binary.LittleEndian.PutUint16(buf[4:6], uint16(FormatVersion2))
	// #nosec G115 -- timestamps and counts fit in respective integer types
	binary.LittleEndian.PutUint64(buf[6:14], uint64(idx.CreatedUnix))
	// #nosec G115 -- offset fits uint64
	binary.LittleEndian.PutUint64(buf[14:22], uint64(idx.DictionaryOffset))
	// #nosec G115 -- size fits uint64
	binary.LittleEndian.PutUint64(buf[22:30], uint64(idx.DictionarySize))
	binary.LittleEndian.PutUint32(buf[30:34], idx.DictionaryID)

	offset := 34

	// #nosec G115 -- length checked <= 255 above
	buf[offset] = byte(len(idx.DictionarySHA256))
	offset++
	copy(buf[offset:], idx.DictionarySHA256)
	offset += len(idx.DictionarySHA256)

	// #nosec G115 -- length checked <= 255 above
	buf[offset] = byte(len(idx.TargetOS))
	offset++
	copy(buf[offset:], idx.TargetOS)
	offset += len(idx.TargetOS)

	// #nosec G115 -- length checked <= 255 above
	buf[offset] = byte(len(idx.TargetArch))
	offset++
	copy(buf[offset:], idx.TargetArch)
	offset += len(idx.TargetArch)

	// #nosec G115 -- length checked <= 65535 above
	binary.LittleEndian.PutUint16(buf[offset:offset+2], uint16(len(idx.AppName)))
	offset += 2
	copy(buf[offset:], idx.AppName)
	offset += len(idx.AppName)

	// #nosec G115 -- length checked <= 65535 above
	binary.LittleEndian.PutUint16(buf[offset:offset+2], uint16(len(idx.Variants)))
	offset += 2

	for _, v := range idx.Variants {
		// #nosec G115 -- length checked <= 255 above
		buf[offset] = byte(len(v.Level))
		offset++
		copy(buf[offset:], v.Level)
		offset += len(v.Level)

		// #nosec G115 -- offset fits uint64
		binary.LittleEndian.PutUint64(buf[offset:offset+8], uint64(v.Offset))
		offset += 8

		// #nosec G115 -- size fits uint64
		binary.LittleEndian.PutUint64(buf[offset:offset+8], uint64(v.CompressedSize))
		offset += 8

		// #nosec G115 -- size fits uint64
		binary.LittleEndian.PutUint64(buf[offset:offset+8], uint64(v.UncompressedSize))
		offset += 8

		// #nosec G115 -- length checked <= 255 above
		buf[offset] = byte(len(v.SHA256))
		offset++
		copy(buf[offset:], v.SHA256)
		offset += len(v.SHA256)

		comp := v.Compression
		if comp == "" {
			comp = defaultCompressionAlgorithm
		}
		// #nosec G115 -- length checked <= 255 above
		buf[offset] = byte(len(comp))
		offset++
		copy(buf[offset:], comp)
		offset += len(comp)
	}

	return buf, nil
}

// UnmarshalBinaryIndex deserializes a Format v2 compact binary index buffer with lowercase SHA-256 digests.
func UnmarshalBinaryIndex(data []byte) (*Index, error) {
	if len(data) < minBinaryHeaderSize {
		return nil, fmt.Errorf("%w: binary index too short (%d bytes)", ErrTruncatedIndex, len(data))
	}

	if string(data[0:4]) != IndexMagicV2 {
		return nil, fmt.Errorf("%w: expected binary index magic %q, got %q", ErrInvalidMagic, IndexMagicV2, string(data[0:4]))
	}

	version := int(binary.LittleEndian.Uint16(data[4:6]))
	if version != FormatVersion2 {
		return nil, fmt.Errorf("%w: expected binary index version %d, got %d", ErrUnsupportedVersion, FormatVersion2, version)
	}

	// #nosec G115 -- binary format integer decode
	createdUnix := int64(binary.LittleEndian.Uint64(data[6:14]))
	// #nosec G115 -- binary format integer decode
	dictOffset := int64(binary.LittleEndian.Uint64(data[14:22]))
	// #nosec G115 -- binary format integer decode
	dictSize := int64(binary.LittleEndian.Uint64(data[22:30]))
	dictID := binary.LittleEndian.Uint32(data[30:34])

	offset := 34

	if offset >= len(data) {
		return nil, fmt.Errorf("%w: truncated dictionary sha length", ErrTruncatedIndex)
	}
	dictSHALen := int(data[offset])
	offset++
	if offset+dictSHALen > len(data) {
		return nil, fmt.Errorf("%w: truncated dictionary sha string", ErrTruncatedIndex)
	}
	dictSHA := string(data[offset : offset+dictSHALen])
	offset += dictSHALen

	if dictSize > 0 && (dictSHA == "" || !ValidateChecksum(dictSHA)) {
		return nil, fmt.Errorf("%w: dictionary missing or invalid sha256 checksum in Format v2", ErrInvalidChecksum)
	}

	if offset >= len(data) {
		return nil, fmt.Errorf("%w: truncated os length", ErrTruncatedIndex)
	}
	osLen := int(data[offset])
	offset++
	if offset+osLen > len(data) {
		return nil, fmt.Errorf("%w: truncated os string", ErrTruncatedIndex)
	}
	targetOS := string(data[offset : offset+osLen])
	offset += osLen

	if offset >= len(data) {
		return nil, fmt.Errorf("%w: truncated arch length", ErrTruncatedIndex)
	}
	archLen := int(data[offset])
	offset++
	if offset+archLen > len(data) {
		return nil, fmt.Errorf("%w: truncated arch string", ErrTruncatedIndex)
	}
	targetArch := string(data[offset : offset+archLen])
	offset += archLen

	if offset+2 > len(data) {
		return nil, fmt.Errorf("%w: truncated app name length", ErrTruncatedIndex)
	}
	appLen := int(binary.LittleEndian.Uint16(data[offset : offset+2]))
	offset += 2
	if offset+appLen > len(data) {
		return nil, fmt.Errorf("%w: truncated app name string", ErrTruncatedIndex)
	}
	appName := string(data[offset : offset+appLen])
	offset += appLen

	if offset+2 > len(data) {
		return nil, fmt.Errorf("%w: truncated variant count", ErrTruncatedIndex)
	}
	variantCount := int(binary.LittleEndian.Uint16(data[offset : offset+2]))
	offset += 2

	variants := make([]VariantEntry, 0, variantCount)
	for i := range variantCount {
		entry, newOffset, err := decodeBinaryVariant(data, offset, i)
		if err != nil {
			return nil, err
		}
		offset = newOffset
		variants = append(variants, entry)
	}

	return &Index{
		Version:          version,
		AppName:          appName,
		TargetOS:         targetOS,
		TargetArch:       targetArch,
		CreatedUnix:      createdUnix,
		DictionaryOffset: dictOffset,
		DictionarySize:   dictSize,
		DictionarySHA256: strings.ToLower(dictSHA),
		DictionaryID:     dictID,
		Variants:         variants,
	}, nil
}

func decodeBinaryVariant(data []byte, offset int, i int) (VariantEntry, int, error) {
	if offset >= len(data) {
		return VariantEntry{}, offset, fmt.Errorf("%w: truncated variant %d header", ErrTruncatedIndex, i)
	}
	levelLen := int(data[offset])
	offset++
	if offset+levelLen > len(data) {
		return VariantEntry{}, offset, fmt.Errorf("%w: truncated variant %d level string", ErrTruncatedIndex, i)
	}
	level := string(data[offset : offset+levelLen])
	offset += levelLen

	if offset+24 > len(data) {
		return VariantEntry{}, offset, fmt.Errorf("%w: truncated variant %d numeric fields", ErrTruncatedIndex, i)
	}
	// #nosec G115 -- binary format integer decode
	vOffset := int64(binary.LittleEndian.Uint64(data[offset : offset+8]))
	offset += 8
	// #nosec G115 -- binary format integer decode
	compSize := int64(binary.LittleEndian.Uint64(data[offset : offset+8]))
	offset += 8
	// #nosec G115 -- binary format integer decode
	uncompSize := int64(binary.LittleEndian.Uint64(data[offset : offset+8]))
	offset += 8

	if offset >= len(data) {
		return VariantEntry{}, offset, fmt.Errorf("%w: truncated variant %d sha length", ErrTruncatedIndex, i)
	}
	shaLen := int(data[offset])
	offset++
	if offset+shaLen > len(data) {
		return VariantEntry{}, offset, fmt.Errorf("%w: truncated variant %d sha string", ErrTruncatedIndex, i)
	}
	shaStr := string(data[offset : offset+shaLen])
	offset += shaLen
	if shaStr == "" || !ValidateChecksum(shaStr) {
		return VariantEntry{}, offset, fmt.Errorf("%w: variant %d missing or invalid sha256 checksum in Format v2", ErrInvalidChecksum, i)
	}

	if offset >= len(data) {
		return VariantEntry{}, offset, fmt.Errorf("%w: truncated variant %d compression length", ErrTruncatedIndex, i)
	}
	compLen := int(data[offset])
	offset++
	if offset+compLen > len(data) {
		return VariantEntry{}, offset, fmt.Errorf("%w: truncated variant %d compression string", ErrTruncatedIndex, i)
	}
	compStr := string(data[offset : offset+compLen])
	offset += compLen

	if compStr == "" {
		compStr = defaultCompressionAlgorithm
	}

	return VariantEntry{
		Level:            level,
		Offset:           vOffset,
		CompressedSize:   compSize,
		UncompressedSize: uncompSize,
		SHA256:           strings.ToLower(shaStr),
		Compression:      compStr,
	}, offset, nil
}

func skipJSONWhitespace(data []byte, pos int) int {
	for pos < len(data) {
		c := data[pos]
		if c == ' ' || c == '\t' || c == '\r' || c == '\n' {
			pos++
			continue
		}
		break
	}
	return pos
}

func parseJSONString(data []byte, pos int) (string, int, error) {
	pos = skipJSONWhitespace(data, pos)
	if pos >= len(data) || data[pos] != '"' {
		return "", pos, fmt.Errorf("%w: expected string opening quote at byte %d", ErrInvalidJSONSyntax, pos)
	}
	start := pos
	pos++
	for pos < len(data) {
		switch data[pos] {
		case '\\':
			pos += 2 // json.Unmarshal validates the escape, including surrogate pairs.
			continue
		case '"':
			var value string
			if err := json.Unmarshal(data[start:pos+1], &value); err != nil {
				return "", pos, fmt.Errorf("%w: %v", ErrInvalidJSONSyntax, err)
			}
			return value, pos + 1, nil
		}
		pos++
	}
	return "", pos, fmt.Errorf("%w: unterminated string at byte %d", ErrInvalidJSONSyntax, start)
}

func parseJSONInt64(data []byte, pos int) (int64, int, error) {
	pos = skipJSONWhitespace(data, pos)
	if pos >= len(data) {
		return 0, pos, fmt.Errorf("%w: expected number at end of input", ErrInvalidJSONSyntax)
	}
	start := pos
	isNeg := false
	if data[pos] == '-' {
		isNeg = true
		pos++
	}
	if pos >= len(data) || data[pos] < '0' || data[pos] > '9' {
		return 0, pos, fmt.Errorf("%w: expected digit at byte %d", ErrInvalidJSONSyntax, pos)
	}
	var val int64
	if isNeg {
		for pos < len(data) && data[pos] >= '0' && data[pos] <= '9' {
			digit := int64(data[pos] - '0')
			if val < (math.MinInt64+digit)/decimalBase {
				return 0, pos, fmt.Errorf("%w: integer overflow at byte %d", ErrInvalidJSONSyntax, start)
			}
			val = val*decimalBase - digit
			pos++
		}
	} else {
		for pos < len(data) && data[pos] >= '0' && data[pos] <= '9' {
			digit := int64(data[pos] - '0')
			if val > (math.MaxInt64-digit)/decimalBase {
				return 0, pos, fmt.Errorf("%w: integer overflow at byte %d", ErrInvalidJSONSyntax, start)
			}
			val = val*decimalBase + digit
			pos++
		}
	}
	return val, pos, nil
}

// MaxJSONDepth bounds legacy manifest nesting, including unknown fields.
const MaxJSONDepth = 128

// validateJSONSyntax uses the standard grammar and a linear, nonrecursive depth check.
// The schema parser below intentionally restricts known numeric fields to int64.
func validateJSONSyntax(data []byte) error {
	depth := 0
	quoted, escaped := false, false
	for _, c := range data {
		if quoted {
			switch {
			case escaped:
				escaped = false
			case c == '\\':
				escaped = true
			case c == '"':
				quoted = false
			}
			continue
		}
		switch c {
		case '"':
			quoted = true
		case '{', '[':
			depth++
			if depth > MaxJSONDepth {
				return fmt.Errorf("%w: nesting exceeds %d", ErrInvalidJSONSyntax, MaxJSONDepth)
			}
		case '}', ']':
			depth--
		}
	}
	if !json.Valid(data) {
		return fmt.Errorf("%w: malformed JSON value", ErrInvalidJSONSyntax)
	}
	return nil
}

func skipJSONValue(data []byte, pos int) (int, error) {
	pos = skipJSONWhitespace(data, pos)
	if pos >= len(data) {
		return pos, fmt.Errorf("%w: unexpected end of json", ErrInvalidJSONSyntax)
	}
	// The complete manifest has already passed the depth and syntax checks. RawMessage
	// validates the skipped value without interpreting its schema or converting numbers.
	decoder := json.NewDecoder(bytes.NewReader(data[pos:]))
	var value json.RawMessage
	if err := decoder.Decode(&value); err != nil {
		return pos, fmt.Errorf("%w: %v", ErrInvalidJSONSyntax, err)
	}
	if err := validateJSONSyntax(value); err != nil {
		return pos, err
	}
	next := pos + int(decoder.InputOffset())
	if next <= pos {
		return pos, fmt.Errorf("%w: value did not advance", ErrInvalidJSONSyntax)
	}
	return next, nil
}

// unmarshalJSONIndex validates JSON syntax and reads the legacy Format v1 manifest schema with lowercase SHA-256 digests.
func unmarshalJSONIndex(data []byte) (*Index, error) {
	if err := validateJSONSyntax(data); err != nil {
		return nil, err
	}
	pos := skipJSONWhitespace(data, 0)
	if pos >= len(data) || data[pos] != '{' {
		return nil, fmt.Errorf("%w: root must be object", ErrInvalidJSONSyntax)
	}
	pos++

	idx := &Index{
		Version:  FormatVersion1,
		Variants: make([]VariantEntry, 0, initialVariantCap),
	}

	for {
		pos = skipJSONWhitespace(data, pos)
		if pos >= len(data) {
			return nil, fmt.Errorf("%w: unclosed root object", ErrInvalidJSONSyntax)
		}
		if data[pos] == '}' {
			break
		}

		key, nextPos, err := parseJSONString(data, pos)
		if err != nil {
			return nil, err
		}
		pos = skipJSONWhitespace(data, nextPos)
		if pos >= len(data) || data[pos] != ':' {
			return nil, fmt.Errorf("%w: expected ':' after key %s", ErrInvalidJSONSyntax, key)
		}
		pos++
		pos = skipJSONWhitespace(data, pos)

		nPos, fErr := parseJSONIndexField(key, data, pos, idx)
		if fErr != nil {
			return nil, fErr
		}
		pos = nPos

		pos = skipJSONWhitespace(data, pos)
		if pos < len(data) && data[pos] == ',' {
			pos++
		}
	}

	return idx, nil
}

func parseJSONIndexField(key string, data []byte, pos int, idx *Index) (int, error) {
	switch key {
	case "version":
		v, nPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		idx.Version = int(v)
		return nPos, nil
	case "app_name":
		s, nPos, err := parseJSONString(data, pos)
		if err != nil {
			return pos, err
		}
		idx.AppName = s
		return nPos, nil
	case "os":
		s, nPos, err := parseJSONString(data, pos)
		if err != nil {
			return pos, err
		}
		idx.TargetOS = s
		return nPos, nil
	case "arch":
		s, nPos, err := parseJSONString(data, pos)
		if err != nil {
			return pos, err
		}
		idx.TargetArch = s
		return nPos, nil
	case "created_unix":
		v, nPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		idx.CreatedUnix = v
		return nPos, nil
	case "dictionary_offset":
		v, nPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		idx.DictionaryOffset = v
		return nPos, nil
	case "dictionary_size":
		v, nPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		idx.DictionarySize = v
		return nPos, nil
	case "dictionary_sha256":
		s, nPos, err := parseJSONString(data, pos)
		if err != nil {
			return pos, err
		}
		idx.DictionarySHA256 = strings.ToLower(s)
		return nPos, nil
	case "dictionary_id":
		v, nPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		// #nosec G115 -- integer conversion for dictionary_id
		idx.DictionaryID = uint32(v)
		return nPos, nil
	case "variants":
		variants, nPos, err := parseJSONVariantArray(data, pos)
		if err != nil {
			return pos, err
		}
		idx.Variants = variants
		return nPos, nil
	default:
		return skipJSONValue(data, pos)
	}
}

func parseJSONVariantArray(data []byte, pos int) ([]VariantEntry, int, error) {
	if pos >= len(data) || data[pos] != '[' {
		return nil, pos, fmt.Errorf("%w: expected '[' for variants array", ErrInvalidJSONSyntax)
	}
	pos++
	variants := make([]VariantEntry, 0, initialVariantCap)
	for {
		pos = skipJSONWhitespace(data, pos)
		if pos >= len(data) {
			return nil, pos, fmt.Errorf("%w: unclosed variants array", ErrInvalidJSONSyntax)
		}
		if data[pos] == ']' {
			return variants, pos + 1, nil
		}
		if data[pos] != '{' {
			return nil, pos, fmt.Errorf("%w: expected variant object '{'", ErrInvalidJSONSyntax)
		}
		entry, nPos, err := parseJSONVariantObject(data, pos)
		if err != nil {
			return nil, pos, err
		}
		variants = append(variants, entry)
		pos = skipJSONWhitespace(data, nPos)
		if pos < len(data) && data[pos] == ',' {
			pos++
		}
	}
}

func parseJSONVariantObject(data []byte, pos int) (VariantEntry, int, error) {
	pos++
	var entry VariantEntry
	for {
		pos = skipJSONWhitespace(data, pos)
		if pos >= len(data) {
			return entry, pos, fmt.Errorf("%w: unclosed variant object", ErrInvalidJSONSyntax)
		}
		if data[pos] == '}' {
			if entry.Compression == "" {
				entry.Compression = defaultCompressionAlgorithm
			}
			return entry, pos + 1, nil
		}
		vKey, vnPos, err := parseJSONString(data, pos)
		if err != nil {
			return entry, pos, err
		}
		pos = skipJSONWhitespace(data, vnPos)
		if pos >= len(data) || data[pos] != ':' {
			return entry, pos, fmt.Errorf("%w: expected ':' after variant key %s", ErrInvalidJSONSyntax, vKey)
		}
		pos++
		pos = skipJSONWhitespace(data, pos)

		nPos, fErr := parseJSONVariantField(vKey, data, pos, &entry)
		if fErr != nil {
			return entry, pos, fErr
		}
		pos = nPos

		pos = skipJSONWhitespace(data, pos)
		if pos < len(data) && data[pos] == ',' {
			pos++
		}
	}
}

func parseJSONVariantField(vKey string, data []byte, pos int, entry *VariantEntry) (int, error) {
	switch vKey {
	case "level":
		s, snPos, err := parseJSONString(data, pos)
		if err != nil {
			return pos, err
		}
		entry.Level = s
		return snPos, nil
	case "offset":
		v, vnPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		entry.Offset = v
		return vnPos, nil
	case "compressed_size":
		v, vnPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		entry.CompressedSize = v
		return vnPos, nil
	case "uncompressed_size":
		v, vnPos, err := parseJSONInt64(data, pos)
		if err != nil {
			return pos, err
		}
		entry.UncompressedSize = v
		return vnPos, nil
	case "sha256":
		s, snPos, err := parseJSONString(data, pos)
		if err != nil {
			return pos, err
		}
		entry.SHA256 = strings.ToLower(s)
		return snPos, nil
	case "compression":
		s, snPos, err := parseJSONString(data, pos)
		if err != nil {
			return pos, err
		}
		entry.Compression = s
		return snPos, nil
	default:
		return skipJSONValue(data, pos)
	}
}

// ReadTrailerAndIndex reads the trailing 56 bytes of the binary, verifies magic and index SHA-256 hash,
// deserializes the index table (binary Format v2 or JSON Format v1), and enforces bounds checks.
func ReadTrailerAndIndex(r io.ReaderAt, totalSize int64) (*Index, error) {
	if totalSize < TrailerSize {
		return nil, fmt.Errorf("%w: file size %d bytes is smaller than trailer size %d bytes",
			ErrBinaryTooSmall, totalSize, TrailerSize)
	}

	trailerBuf := make([]byte, TrailerSize)
	if _, err := r.ReadAt(trailerBuf, totalSize-TrailerSize); err != nil {
		return nil, fmt.Errorf("reading trailer from file: %w", err)
	}

	offset := OffsetLen + SizeLen
	hashOffset := offset + HashLen
	if string(trailerBuf[hashOffset:hashOffset+MagicLen]) != MagicString {
		return nil, ErrInvalidMagic
	}

	// #nosec G115 -- trailer format offset and size
	indexOffset := int64(binary.LittleEndian.Uint64(trailerBuf[0:OffsetLen]))
	// #nosec G115 -- trailer format offset and size
	indexSize := int64(binary.LittleEndian.Uint64(trailerBuf[OffsetLen:offset]))

	trailerOffset := totalSize - TrailerSize
	if indexOffset < 0 || indexOffset >= trailerOffset {
		return nil, fmt.Errorf("%w: offset %d beyond trailer %d",
			ErrInvalidIndexOffset, indexOffset, trailerOffset)
	}
	if indexSize <= 0 || indexSize > MaxIndexSize || indexSize != trailerOffset-indexOffset {
		return nil, fmt.Errorf("%w: index size %d with offset %d does not match trailer boundary %d",
			ErrInvalidIndexSize, indexSize, indexOffset, trailerOffset)
	}

	expectedHash := trailerBuf[offset : offset+HashLen]
	idxBytes := make([]byte, indexSize)
	if _, err := r.ReadAt(idxBytes, indexOffset); err != nil {
		return nil, fmt.Errorf("reading index payload at offset %d: %w", indexOffset, err)
	}

	actualHash := sha256.Sum256(idxBytes)
	if !bytes.Equal(actualHash[:], expectedHash) {
		return nil, fmt.Errorf("%w: expected %x, got %x", ErrIndexCorrupted, expectedHash, actualHash)
	}

	var idx *Index
	var err error
	if len(idxBytes) >= 4 && string(idxBytes[0:4]) == IndexMagicV2 {
		idx, err = UnmarshalBinaryIndex(idxBytes)
	} else {
		idx, err = unmarshalJSONIndex(idxBytes)
	}
	if err != nil {
		return nil, fmt.Errorf("deserializing index: %w", err)
	}

	for i := range idx.Variants {
		if idx.Variants[i].Compression == "" {
			idx.Variants[i].Compression = defaultCompressionAlgorithm
		}
	}

	if err := idx.ValidateBounds(indexOffset); err != nil {
		return nil, fmt.Errorf("validating variant boundaries: %w", err)
	}

	return idx, nil
}

// WriteIndexAndTrailer serializes the index in Format v2 (binary) and writes it followed by the 56-byte trailer.
func WriteIndexAndTrailer(w io.Writer, idx *Index, currentOffset int64) (int64, error) {
	version := idx.Version
	if version == 0 {
		version = FormatVersionCurrent
	}
	return WriteIndexAndTrailerWithVersion(w, idx, currentOffset, version)
}

// marshalJSONIndex serializes an Index struct to JSON without using Go reflection.
func marshalJSONIndex(idx *Index) ([]byte, error) {
	var sb strings.Builder
	sb.WriteString(`{"version":`)
	sb.WriteString(strconv.Itoa(idx.Version))
	if idx.AppName != "" {
		sb.WriteString(`,"app_name":"`)
		sb.WriteString(EscapeJSONString(idx.AppName))
		sb.WriteString(`"`)
	}
	sb.WriteString(`,"os":"`)
	sb.WriteString(EscapeJSONString(idx.TargetOS))
	sb.WriteString(`","arch":"`)
	sb.WriteString(EscapeJSONString(idx.TargetArch))
	sb.WriteString(`","created_unix":`)
	sb.WriteString(strconv.FormatInt(idx.CreatedUnix, 10))
	if idx.DictionarySize > 0 {
		sb.WriteString(`,"dictionary_offset":`)
		sb.WriteString(strconv.FormatInt(idx.DictionaryOffset, 10))
		sb.WriteString(`,"dictionary_size":`)
		sb.WriteString(strconv.FormatInt(idx.DictionarySize, 10))
		if idx.DictionarySHA256 != "" {
			sb.WriteString(`,"dictionary_sha256":"`)
			sb.WriteString(EscapeJSONString(idx.DictionarySHA256))
			sb.WriteString(`"`)
		}
		if idx.DictionaryID > 0 {
			sb.WriteString(`,"dictionary_id":`)
			sb.WriteString(strconv.FormatInt(int64(idx.DictionaryID), 10))
		}
	}
	sb.WriteString(`,"variants":[`)
	for i, v := range idx.Variants {
		if i > 0 {
			sb.WriteString(`,`)
		}
		sb.WriteString(`{"level":"`)
		sb.WriteString(EscapeJSONString(v.Level))
		sb.WriteString(`","offset":`)
		sb.WriteString(strconv.FormatInt(v.Offset, 10))
		sb.WriteString(`,"compressed_size":`)
		sb.WriteString(strconv.FormatInt(v.CompressedSize, 10))
		sb.WriteString(`,"uncompressed_size":`)
		sb.WriteString(strconv.FormatInt(v.UncompressedSize, 10))
		if v.SHA256 != "" {
			sb.WriteString(`,"sha256":"`)
			sb.WriteString(EscapeJSONString(v.SHA256))
			sb.WriteString(`"`)
		}
		comp := v.Compression
		if comp == "" {
			comp = defaultCompressionAlgorithm
		}
		sb.WriteString(`,"compression":"`)
		sb.WriteString(EscapeJSONString(comp))
		sb.WriteString(`"}`)
	}
	sb.WriteString(`]}`)
	return []byte(sb.String()), nil
}

// EscapeJSONString escapes JSON string content without adding quotes or using reflection.
// The format writer and launcher telemetry share this byte-preserving encoder.
func EscapeJSONString(s string) string {
	var sb strings.Builder
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch c {
		case '"':
			sb.WriteString(`\"`)
		case '\\':
			sb.WriteString(`\\`)
		case '\b':
			sb.WriteString(`\b`)
		case '\f':
			sb.WriteString(`\f`)
		case '\n':
			sb.WriteString(`\n`)
		case '\r':
			sb.WriteString(`\r`)
		case '\t':
			sb.WriteString(`\t`)
		default:
			if c < asciiControlCutoff {
				fmt.Fprintf(&sb, `\u%04x`, c)
			} else {
				sb.WriteByte(c)
			}
		}
	}
	return sb.String()
}

// WriteIndexAndTrailerWithVersion writes the serialized index in the specified format version followed by the 56-byte trailer.
func WriteIndexAndTrailerWithVersion(w io.Writer, idx *Index, currentOffset int64, version int) (int64, error) {
	if currentOffset < 0 {
		return 0, fmt.Errorf("invalid negative offset %d", currentOffset)
	}

	var idxBytes []byte
	var err error

	idx.Version = version
	switch version {
	case FormatVersion1:
		idxBytes, err = marshalJSONIndex(idx)
		if err != nil {
			return 0, fmt.Errorf("marshaling index json: %w", err)
		}
	case FormatVersion2:
		idxBytes, err = MarshalBinaryIndex(idx)
		if err != nil {
			return 0, fmt.Errorf("marshaling binary index: %w", err)
		}
	default:
		return 0, fmt.Errorf("%w: %d", ErrUnsupportedVersion, version)
	}

	indexSize := int64(len(idxBytes))
	if indexSize > MaxIndexSize {
		return 0, fmt.Errorf("index size %d exceeds maximum %d", indexSize, MaxIndexSize)
	}

	n, err := w.Write(idxBytes)
	if err != nil {
		return 0, fmt.Errorf("writing index: %w", err)
	}

	indexHash := sha256.Sum256(idxBytes)

	trailer := make([]byte, TrailerSize)
	binary.LittleEndian.PutUint64(trailer[0:OffsetLen], uint64(currentOffset))
	binary.LittleEndian.PutUint64(trailer[OffsetLen:OffsetLen*2], uint64(indexSize))
	copy(trailer[OffsetLen*2:OffsetLen*2+HashLen], indexHash[:])
	copy(trailer[OffsetLen*2+HashLen:], []byte(MagicString))

	tn, err := w.Write(trailer)
	if err != nil {
		return 0, fmt.Errorf("writing trailer: %w", err)
	}

	return int64(n + tn), nil
}

// IsFatBinary returns true if the reader contains valid microfat magic bytes at EOF.
func IsFatBinary(r io.ReaderAt, totalSize int64) bool {
	if totalSize < TrailerSize {
		return false
	}
	buf := make([]byte, MagicLen)
	if _, err := r.ReadAt(buf, totalSize-MagicLen); err != nil {
		return false
	}
	return bytes.Equal(buf, []byte(MagicString))
}

// ResolveCacheDirFD resolves, creates, and securely validates the microfat cache directory,
// returning an open file descriptor pinned to the directory alongside its absolute path.
//
// On Unix systems, the returned directory descriptor allows callers to anchor subsequent operations
// using *at syscalls (openat, unlinkat, renameat) relative to dirFD, eliminating pathname TOCTOU
// vulnerabilities between directory validation and payload extraction or execution.
// On non-Unix platforms, dirFD is -1.
// If dirFD >= 0, the caller is responsible for closing dirFD when finished.
//
// Cache ownership follows the effective UID of an ordinary, non-elevated process.
// The launcher rejects setuid/setgid and secure execution before cache access.
//
// Precedence:
//  1. customDir argument (if non-empty)
//  2. MICROFAT_CACHE_DIR environment variable (if set)
//  3. $XDG_CACHE_HOME/microfat (or ~/.cache/microfat)
//  4. Fallback: /tmp/.microfat-<euid>
//
// Security Invariants:
//   - Explicit paths (customDir or MICROFAT_CACHE_DIR) must be regular directories (not symlinks),
//     owned by the current process effective UID, and without group or other write permissions (mode & 0o022 == 0).
//     Insecure configurations fail fast with an error wrapping ErrInsecureCacheDir without attempting remediation.
//   - For the automatic discovery cascade (XDG_CACHE_HOME, ~/.cache, /tmp/.microfat-<euid>), candidate directories
//     owned by the current process effective UID with permissive write bits are tightened directly on the open descriptor
//     via fchmod to 0700. Foreign-owned directories, symlinks, or candidates where chmod fails are rejected,
//     falling through to the next candidate in the cascade.
func ResolveCacheDirFD(customDir string) (int, string, error) {
	return resolveCacheDirFD(customDir, true)
}

// ResolveExistingCacheDirFD discovers and opens a secure existing cache directory.
// It never creates directories or repairs permissions. Explicit paths fail directly;
// automatic discovery tries the same candidates as ResolveCacheDirFD, without changes.
// The caller owns the returned descriptor and must close it when it is nonnegative.
func ResolveExistingCacheDirFD(customDir string) (int, string, error) {
	return resolveCacheDirFD(customDir, false)
}

func resolveCacheDirFD(customDir string, materialize bool) (int, string, error) {
	if customDir != "" {
		cleanDir := filepath.Clean(customDir)
		if err := prepareCacheDir(cleanDir, materialize); err != nil {
			return -1, "", fmt.Errorf("creating custom cache directory %s: %w", cleanDir, err)
		}
		fd, err := OpenAndValidateCacheDirFD(cleanDir, false)
		if err != nil {
			return -1, "", fmt.Errorf("custom cache directory %s is insecure: %w", cleanDir, err)
		}
		return fd, cleanDir, nil
	}

	if envDir := os.Getenv(EnvCacheDir); envDir != "" {
		cleanDir := filepath.Clean(envDir)
		if err := prepareCacheDir(cleanDir, materialize); err != nil {
			return -1, "", fmt.Errorf("creating cache directory from %s (%s): %w", EnvCacheDir, cleanDir, err)
		}
		fd, err := OpenAndValidateCacheDirFD(cleanDir, false)
		if err != nil {
			return -1, "", fmt.Errorf("cache directory from %s (%s) is insecure: %w", EnvCacheDir, cleanDir, err)
		}
		return fd, cleanDir, nil
	}

	var candidates []string
	if xdg := os.Getenv("XDG_CACHE_HOME"); xdg != "" {
		candidates = append(candidates, filepath.Join(xdg, "microfat"))
	} else if userHomeDirFunc != nil {
		if home, err := userHomeDirFunc(); err == nil && home != "" {
			candidates = append(candidates, filepath.Join(home, ".cache", "microfat"))
		}
	}
	candidates = append(candidates, filepath.Join(os.TempDir(), fmt.Sprintf(".microfat-%d", geteuidFunc())))

	var attempted []string
	seen := make(map[string]bool, len(candidates))

	for _, cand := range candidates {
		cleanDir := filepath.Clean(cand)
		if seen[cleanDir] {
			continue
		}
		seen[cleanDir] = true
		attempted = append(attempted, cleanDir)

		if err := prepareCacheDir(cleanDir, materialize); err != nil {
			continue
		}

		fd, err := OpenAndValidateCacheDirFD(cleanDir, materialize)
		if err == nil {
			return fd, cleanDir, nil
		}
	}

	return -1, "", fmt.Errorf("%w: unable to resolve secure microfat cache directories (tried %s)",
		ErrCacheInit, strings.Join(attempted, ", "))
}

func prepareCacheDir(dir string, materialize bool) error {
	if !materialize {
		return nil
	}
	// Cache paths intentionally come from the caller or environment of the non-elevated process.
	// On Unix, callers validate the no-follow directory descriptor, ownership and permissions before cache use.
	// #nosec G703 -- caller-selected cache location; private creation followed by descriptor validation.
	return os.MkdirAll(dir, PrivateCacheDirMode)
}

// ResolveExistingCacheDir is the read-only counterpart of ResolveCacheDir.
func ResolveExistingCacheDir(customDir string) (string, error) {
	return resolveCacheDir(customDir, false)
}

// ResolveCacheDir resolves and creates the microfat cache directory with 0700 permissions.
// On Unix systems, it validates security invariants using descriptor-based pinning to prevent TOCTOU races.
func ResolveCacheDir(customDir string) (string, error) {
	return resolveCacheDir(customDir, true)
}

func resolveCacheDir(customDir string, materialize bool) (string, error) {
	fd, dir, err := resolveCacheDirFD(customDir, materialize)
	if err != nil {
		return "", err
	}
	if fd >= 0 {
		_ = closeDirFunc(fd)
	}
	return dir, nil
}
