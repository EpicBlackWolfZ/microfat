// Package format defines the microfat binary trailer, index structure, integrity verification,
// diagnostics classification, and serialization logic.
package format

import (
	"errors"
	"syscall"

	"github.com/EpicBlackWolfZ/microfat/internal/codec"
)

// Standard launcher execution stage names.
const (
	StageMemfdCreate     = "memfd_create"
	StageMemfdSeal       = "memfd_seal"
	StageMemfdExtract    = "extract_memfd"
	StageMemfdExec       = "execve_memfd"
	StageCacheDirInit    = "cache_dir_init"
	StageCacheCreateTemp = "cache_create_temp"
	StageCacheExtract    = "cache_extract"
	StageCacheExec       = "execve_cache"
	StageCodecLookup     = "codec_lookup"
	StageDecompress      = "decompress"
	StageLauncherMain    = "launcher_main"
)

// Standard diagnostic remediation hints for operator troubleshooting.
const (
	HintMemfdEPERM = "memfd_create failed with EPERM. " +
		"Possible causes include host security policy, seccomp filters, or container profile restrictions. " +
		"If disk cache execution is permitted, run with MICROFAT_EXEC_MODE=cache."
	HintMemfdEACCES = "memfd_create failed with EACCES. " +
		"Possible causes include permission restrictions or kernel memfd policy limits. " +
		"If disk cache execution is permitted, run with MICROFAT_EXEC_MODE=cache."
	HintMemfdSeal = "memfd sealing (F_ADD_SEALS) failed or was restricted by kernel security policy. " +
		"If disk cache execution is permitted, run with MICROFAT_EXEC_MODE=cache, or adjust kernel sealing permissions."
	HintMemfdKernelUnsupported = "memfd_create is unsupported on this Linux kernel or disabled (ENOSYS). " +
		"If disk cache execution is permitted, run with MICROFAT_EXEC_MODE=cache."
	HintFileDescriptorLimit = "File descriptor limit reached. " +
		"Increase nofile limits (ulimit -n) or free open file descriptors."
	HintReadOnlyFS = "Read-only filesystem detected. " +
		"Set $MICROFAT_CACHE_DIR or $TMPDIR to a writable tmpfs/volume."
	HintCacheUnwritable = "Unable to write cached binary. " +
		"Ensure $XDG_CACHE_HOME or $TMPDIR is writable, or mount a writable tmpfs."
	HintPermissionDenied = "Permission denied. Check the permissions and security policy for the path named in the error."
	HintDiskFull         = "No space left on device. " +
		"Free disk space in cache directory or set $MICROFAT_CACHE_DIR to a volume with available space."
	HintExecEACCES = "execve failed with EACCES. " +
		"Possible causes include missing execute permissions, a 'noexec' filesystem mount, or security policy restrictions."
	HintExecEPERM = "execve failed with EPERM. " +
		"Possible causes include security policy (seccomp, LSM/AppArmor/SELinux), or container execution restrictions."
	HintTextBusy = "Binary is currently open for writing by another process (ETXTBSY). " +
		"Retrying or prewarming with --microfat:prewarm avoids concurrency contention."
	HintExecFormat       = "Binary format is invalid or incompatible with host kernel/architecture."
	HintUnsupportedCodec = "Binary variant uses an unsupported compression algorithm. " +
		"Update microfat launcher stub or re-package with a supported codec (e.g. zstd, lz4, none)."
	HintDecompressFailed = "Payload decompression failed or corrupted. " +
		"Re-package the binary with 'microfat pack' or verify integrity with 'microfat verify'."
	HintInsecureCacheDir = "Cache directory has insecure permissions, is a symlink, or is owned by another user. " +
		"Use a private directory owned by your UID with mode 0700 or set MICROFAT_CACHE_DIR."

	// Deprecated compatibility aliases:
	HintMemfdSeccomp = HintMemfdEPERM
	HintExecNoExec   = HintExecEACCES
)

// DiagnoseError inspects an execution failure and stage context, returning an actionable
// human-readable remediation hint if a recognized restriction or error is detected.
func DiagnoseError(stage string, err error) string {
	if err == nil {
		return ""
	}

	switch stage {
	case StageMemfdCreate:
		return diagnoseMemfdCreate(err)
	case StageMemfdSeal:
		return diagnoseMemfdSeal(err)
	case StageMemfdExec:
		return diagnoseExec(err)
	case StageCacheDirInit, StageCacheCreateTemp, StageCacheExtract:
		return diagnoseCacheWrite(err)
	case StageCacheExec:
		return diagnoseExec(err)
	case StageCodecLookup:
		return diagnoseCodec(err)
	case StageMemfdExtract, StageDecompress:
		return diagnoseDecompress(err)
	case StageLauncherMain:
		return diagnoseGeneric(err)
	default:
		return diagnoseGeneric(err)
	}
}

func diagnoseCodec(err error) string {
	if errors.Is(err, codec.ErrUnsupportedCodec) {
		return HintUnsupportedCodec
	}
	return diagnoseGeneric(err)
}

func diagnoseDecompress(err error) string {
	if errors.Is(err, codec.ErrDecompressionFailed) ||
		errors.Is(err, codec.ErrSizeMismatch) ||
		errors.Is(err, ErrDictionaryCorrupted) ||
		errors.Is(err, ErrPayloadCorrupted) ||
		errors.Is(err, ErrPayloadTooLarge) ||
		errors.Is(err, ErrMemfdExtract) ||
		errors.Is(err, ErrCacheExtract) {
		return HintDecompressFailed
	}
	return diagnoseGeneric(err)
}

func diagnoseMemfdCreate(err error) string {
	switch {
	case errors.Is(err, syscall.EPERM):
		return HintMemfdEPERM
	case errors.Is(err, syscall.EACCES):
		return HintMemfdEACCES
	case errors.Is(err, syscall.ENOSYS):
		return HintMemfdKernelUnsupported
	case errors.Is(err, syscall.EMFILE), errors.Is(err, syscall.ENFILE):
		return HintFileDescriptorLimit
	default:
		return ""
	}
}

func diagnoseMemfdSeal(err error) string {
	switch {
	case errors.Is(err, syscall.ENOSYS):
		return HintMemfdKernelUnsupported
	case errors.Is(err, syscall.EPERM), errors.Is(err, syscall.EACCES):
		return HintMemfdSeal
	case errors.Is(err, syscall.EINVAL), errors.Is(err, syscall.EBADF):
		return HintMemfdSeal
	default:
		return HintMemfdSeal
	}
}

func diagnoseCacheWrite(err error) string {
	switch {
	case errors.Is(err, ErrInsecureCacheDir):
		return HintInsecureCacheDir
	case errors.Is(err, syscall.EROFS):
		return HintReadOnlyFS
	case errors.Is(err, syscall.EACCES), errors.Is(err, syscall.EPERM):
		return HintCacheUnwritable
	case errors.Is(err, syscall.ENOSPC):
		return HintDiskFull
	case errors.Is(err, syscall.EMFILE), errors.Is(err, syscall.ENFILE):
		return HintFileDescriptorLimit
	default:
		return ""
	}
}

func diagnoseExec(err error) string {
	switch {
	case errors.Is(err, syscall.EACCES):
		return HintExecEACCES
	case errors.Is(err, syscall.EPERM):
		return HintExecEPERM
	case errors.Is(err, syscall.ETXTBSY):
		return HintTextBusy
	case errors.Is(err, syscall.ENOEXEC):
		return HintExecFormat
	default:
		return ""
	}
}

func diagnoseGeneric(err error) string {
	if hint := diagnoseCodecAndIntegrity(err); hint != "" {
		return hint
	}
	if hint := diagnoseExecutionSentinels(err); hint != "" {
		return hint
	}
	return diagnoseFallbackSyscall(err)
}

func diagnoseCodecAndIntegrity(err error) string {
	if errors.Is(err, codec.ErrUnsupportedCodec) {
		return HintUnsupportedCodec
	}
	if errors.Is(err, codec.ErrDecompressionFailed) ||
		errors.Is(err, codec.ErrSizeMismatch) ||
		errors.Is(err, ErrDictionaryCorrupted) ||
		errors.Is(err, ErrPayloadCorrupted) {
		return HintDecompressFailed
	}
	return ""
}

func diagnoseExecutionSentinels(err error) string {
	if errors.Is(err, ErrExecve) {
		return diagnoseExec(err)
	}
	if errors.Is(err, ErrMemfdCreate) {
		return diagnoseMemfdCreate(err)
	}
	if errors.Is(err, ErrMemfdSealingFailed) {
		return diagnoseMemfdSeal(err)
	}
	if errors.Is(err, ErrCacheInit) || errors.Is(err, ErrCacheWrite) || errors.Is(err, ErrCacheExtract) {
		return diagnoseCacheWrite(err)
	}
	return ""
}

func diagnoseFallbackSyscall(err error) string {
	switch {
	case errors.Is(err, syscall.EROFS):
		return HintReadOnlyFS
	case errors.Is(err, syscall.ENOSPC):
		return HintDiskFull
	case errors.Is(err, syscall.ENOSYS):
		return HintMemfdKernelUnsupported
	case errors.Is(err, syscall.ETXTBSY):
		return HintTextBusy
	case errors.Is(err, syscall.ENOEXEC):
		return HintExecFormat
	case errors.Is(err, syscall.EMFILE), errors.Is(err, syscall.ENFILE):
		return HintFileDescriptorLimit
	case errors.Is(err, syscall.EACCES), errors.Is(err, syscall.EPERM):
		return HintPermissionDenied
	default:
		return ""
	}
}
