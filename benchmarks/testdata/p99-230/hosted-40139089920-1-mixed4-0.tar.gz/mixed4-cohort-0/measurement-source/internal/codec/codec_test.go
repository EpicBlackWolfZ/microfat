package codec_test

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"math/rand/v2"
	"testing"

	"github.com/EpicBlackWolfZ/microfat/internal/codec"
	"github.com/EpicBlackWolfZ/microfat/internal/testutil"

	"github.com/stretchr/testify/require"
)

const (
	testPayloadSizeSmall = 128 * 1024  // 128 KB
	testPayloadSizeLarge = 1024 * 1024 // 1 MB
	testPayloadSizeTiny  = 64 * 1024   // 64 KB
	testCodecZstd        = "zstd"
	testLevelFastest     = "fastest"
	testLevelBest        = "best"
)

func generateTestData(size int) []byte {
	buf := make([]byte, size)
	// Fill with semi-compressible pattern
	for i := range buf {
		buf[i] = byte((i % 256) ^ (i / 1024))
	}
	return buf
}

func TestRegistry(t *testing.T) {
	t.Parallel()

	list := codec.List()
	if len(list) < 3 {
		t.Fatalf("expected at least 3 codecs, got %d: %v", len(list), list)
	}

	for _, name := range []string{testCodecZstd, codec.AlgorithmLZ4, codec.AlgorithmNone, "ZSTD", "Lz4", "NoNe", ""} {
		c, err := codec.Get(name)
		if err != nil {
			t.Fatalf("unexpected error getting codec %q: %v", name, err)
		}
		if c == nil {
			t.Fatalf("expected non-nil codec for %q", name)
		}
	}

	_, err := codec.Get("invalid_codec_name")
	if !errors.Is(err, codec.ErrUnsupportedCodec) {
		t.Fatalf("expected ErrUnsupportedCodec, got: %v", err)
	}

	// Register nil is safe
	codec.Register(nil)
}

func TestParseCompressionSpec(t *testing.T) {
	t.Parallel()

	cases := []struct {
		input     string
		wantAlgo  string
		wantLevel string
	}{
		{"", "", ""},
		{testCodecZstd, testCodecZstd, ""},
		{"zstd:best", testCodecZstd, "best"},
		{"lz4:fastest", "lz4", testLevelFastest},
		{"ZSTD:11", testCodecZstd, "11"},
		{"none", "none", ""},
	}

	for _, tc := range cases {
		t.Run(tc.input, func(t *testing.T) {
			t.Parallel()
			algo, level := codec.ParseCompressionSpec(tc.input)
			if algo != tc.wantAlgo || level != tc.wantLevel {
				t.Fatalf("ParseCompressionSpec(%q) = (%q, %q), want (%q, %q)",
					tc.input, algo, level, tc.wantAlgo, tc.wantLevel)
			}
		})
	}
}

func TestResolveCompression(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name, profile, algorithm, level string
		size                            int64
		wantCodec, wantLevel            string
		checkLevel                      bool
		wantErr                         error
	}{
		{"Default balanced", "", "", "", 1024, codec.AlgorithmZstd, "better", true, nil},
		{"Profile size", codec.ProfileSize, "", "", 1024, codec.AlgorithmZstd, "best", true, nil},
		{"Profile latency tiny payload auto-promotes to none", codec.ProfileLatency, "", "",
			testPayloadSizeTiny, codec.AlgorithmNone, "", false, nil},
		{"Profile latency threshold - 1 selects none", codec.ProfileLatency, "", "",
			codec.DefaultLatencyUncompressedThreshold - 1, codec.AlgorithmNone, "", false, nil},
		{"Profile latency threshold selects lz4", codec.ProfileLatency, "", "",
			codec.DefaultLatencyUncompressedThreshold, codec.AlgorithmLZ4, "", false, nil},
		{"Profile latency threshold + 1 selects lz4", codec.ProfileLatency, "", "",
			codec.DefaultLatencyUncompressedThreshold + 1, codec.AlgorithmLZ4, "", false, nil},
		{"Profile latency zero size selects lz4", codec.ProfileLatency, "", "",
			0, codec.AlgorithmLZ4, "", false, nil},
		{"Profile latency negative size selects lz4", codec.ProfileLatency, "", "",
			-1, codec.AlgorithmLZ4, "", false, nil},
		{"Profile latency large payload defaults to lz4", codec.ProfileLatency, "", "",
			testPayloadSizeLarge, codec.AlgorithmLZ4, "", false, nil},
		{"Profile latency with explicit lz4 does not auto-promote", codec.ProfileLatency, codec.AlgorithmLZ4, "",
			testPayloadSizeTiny, codec.AlgorithmLZ4, "", false, nil},
		{"Profile latency with explicit zstd retained", codec.ProfileLatency, codec.AlgorithmZstd, "",
			1024, codec.AlgorithmZstd, "", false, nil},
		{"Profile size with explicit lz4 retained", codec.ProfileSize, codec.AlgorithmLZ4, "",
			1024, codec.AlgorithmLZ4, "", false, nil},
		{"Profile size with explicit none retained", codec.ProfileSize, codec.AlgorithmNone, "",
			1024, codec.AlgorithmNone, "", false, nil},
		{"Explicit algorithm and spec level override", codec.ProfileLatency, "zstd:9", "", 1024,
			codec.AlgorithmZstd, "9", true, nil},
		{"Explicit algo spec level overridden by explicit level", codec.ProfileLatency, "zstd:9", "3", 1024,
			codec.AlgorithmZstd, "3", true, nil},
		{"Explicit algo spec level beats profile default level", codec.ProfileSize, "zstd:1", "", 1024,
			codec.AlgorithmZstd, "1", true, nil},
		{"Profile size with custom algo and level", codec.ProfileSize, testCodecZstd, "19", 1024,
			codec.AlgorithmZstd, "19", true, nil},
		{"Profile balanced with explicit level", codec.ProfileBalanced, testCodecZstd, testLevelFastest, 1024,
			codec.AlgorithmZstd, testLevelFastest, true, nil},
		{"Default with explicit level", "", testCodecZstd, testLevelFastest, 1024, codec.AlgorithmZstd, testLevelFastest, true, nil},
		{"Invalid profile error", "unknown_profile", "", "", 1024, "", "", false, codec.ErrUnsupportedProfile},
		{"Invalid algorithm error", "", "unknown_algo", "", 1024, "", "", false, codec.ErrUnsupportedCodec},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			c, level, err := codec.ResolveCompression(tt.profile, tt.algorithm, tt.level, tt.size)
			if tt.wantErr != nil {
				require.ErrorIs(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.NotNil(t, c)
			require.Equal(t, tt.wantCodec, c.Name())
			if tt.checkLevel {
				require.Equal(t, tt.wantLevel, level)
			}
		})
	}
}

func TestCodecsRoundtrip(t *testing.T) {
	t.Parallel()

	testData := generateTestData(testPayloadSizeSmall)

	tests := []struct {
		name   string
		codec  string
		levels []string
	}{
		{
			name:   "Zstd",
			codec:  codec.AlgorithmZstd,
			levels: []string{"", "fastest", "default", "better", "best", "1", "2", "3", "5", "10", "11", "19", "0", "-1"},
		},
		{
			name:   "LZ4",
			codec:  codec.AlgorithmLZ4,
			levels: []string{"", "default", "fast", "fastest", "better", "best", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-1"},
		},
		{
			name:   "None",
			codec:  codec.AlgorithmNone,
			levels: []string{""},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			c, err := codec.Get(tc.codec)
			if err != nil {
				t.Fatalf("failed to get codec %s: %v", tc.codec, err)
			}

			for _, lvl := range tc.levels {
				t.Run("level="+lvl, func(t *testing.T) {
					var compressed bytes.Buffer
					if err := c.Compress(&compressed, testData, lvl); err != nil {
						t.Fatalf("Compress failed with level %q: %v", lvl, err)
					}

					var decompressed bytes.Buffer
					if err := c.Decompress(&decompressed, &compressed, int64(len(testData))); err != nil {
						t.Fatalf("Decompress failed: %v", err)
					}

					if !bytes.Equal(decompressed.Bytes(), testData) {
						t.Fatalf("decompressed data mismatch")
					}
				})
			}
		})
	}
}

func TestCodecErrors(t *testing.T) {
	t.Parallel()

	data := generateTestData(1024)

	for _, name := range []string{codec.AlgorithmZstd, codec.AlgorithmLZ4, codec.AlgorithmNone} {
		t.Run(name+" corrupted data", func(t *testing.T) {
			t.Parallel()
			c, err := codec.Get(name)
			if err != nil {
				t.Fatalf("Get(%q): %v", name, err)
			}

			corrupted := []byte("definitely not valid compressed stream data payload header")
			var out bytes.Buffer
			err = c.Decompress(&out, bytes.NewReader(corrupted), int64(len(data)))
			if name == codec.AlgorithmNone {
				// none will read the corrupted bytes and fail on size mismatch
				if !errors.Is(err, codec.ErrSizeMismatch) {
					t.Fatalf("expected ErrSizeMismatch, got %v", err)
				}
			} else {
				if err == nil {
					t.Fatalf("expected error decompressing corrupted stream")
				}
			}
		})

		t.Run(name+" size mismatch", func(t *testing.T) {
			t.Parallel()
			c, _ := codec.Get(name)
			var compressed bytes.Buffer
			_ = c.Compress(&compressed, data, "")

			var out bytes.Buffer
			// Expect wrong size
			err := c.Decompress(&out, &compressed, int64(len(data)+100))
			if !errors.Is(err, codec.ErrSizeMismatch) {
				t.Fatalf("expected ErrSizeMismatch, got %v", err)
			}
		})
	}

	t.Run("Invalid level parsing", func(t *testing.T) {
		t.Parallel()
		zstdC, _ := codec.Get(codec.AlgorithmZstd)
		var buf bytes.Buffer
		err := zstdC.Compress(&buf, data, "invalid_num_abc")
		if !errors.Is(err, codec.ErrInvalidCompressionLevel) {
			t.Fatalf("expected ErrInvalidCompressionLevel, got %v", err)
		}

		lz4C, _ := codec.Get(codec.AlgorithmLZ4)
		err = lz4C.Compress(&buf, data, "invalid_num_abc")
		if !errors.Is(err, codec.ErrInvalidCompressionLevel) {
			t.Fatalf("expected ErrInvalidCompressionLevel, got %v", err)
		}
	})

	t.Run("Writer and reader errors", func(t *testing.T) {
		t.Parallel()
		ew := &errWriter{}
		er := &errReader{}

		for _, name := range []string{codec.AlgorithmZstd, codec.AlgorithmLZ4, codec.AlgorithmNone} {
			c, _ := codec.Get(name)
			if err := c.Compress(ew, data, ""); err == nil {
				t.Fatalf("expected error compressing to errWriter for %s", name)
			}
			var buf bytes.Buffer
			if err := c.Decompress(&buf, er, int64(len(data))); err == nil {
				t.Fatalf("expected error decompressing from errReader for %s", name)
			}
		}
	})

	t.Run("ParseLevelInt empty and default", func(t *testing.T) {
		t.Parallel()
		val, err := codec.ParseLevelInt("", 42)
		if err != nil || val != 42 {
			t.Fatalf("expected 42, got %d, err %v", val, err)
		}
	})
}

type errWriter struct{}

func (e *errWriter) Write(p []byte) (n int, err error) {
	return 0, errors.New("simulated write error")
}

type errReader struct{}

func (e *errReader) Read(p []byte) (n int, err error) {
	return 0, errors.New("simulated read error")
}

func generateDictionarySamples() [][]byte {
	samples := make([][]byte, 40)
	for i := range samples {
		var b bytes.Buffer
		for j := range 50 {
			b.WriteString(fmt.Sprintf("GO_MICROFAT_RUNTIME_SYMBOL_TABLE_ENTRY_PKG_INDEX_%d_%d_OFFSET_%d_LENGTH_%d\n", i, j, i*100+j, (i+j)*8))
			b.WriteString("common_static_data_string_for_testing_zstandard_compression_dictionary_builder\n")
		}
		samples[i] = b.Bytes()
	}
	return samples
}

func TestZstdDictionaryCompression(t *testing.T) {
	t.Parallel()

	samples := generateDictionarySamples()

	dict, err := codec.TrainDictionary(samples, 32*1024, "better")
	require.NoError(t, err, "TrainDictionary failed")
	if len(dict) == 0 {
		t.Fatalf("expected non-empty dictionary")
	}

	zCodecRaw, err := codec.Get(codec.AlgorithmZstd)
	require.NoError(t, err, "Get zstd")
	zCodec, ok := zCodecRaw.(codec.DictCodec)
	if !ok {
		t.Fatalf("expected zstd codec to implement DictCodec")
	}

	testData := samples[0]

	t.Run("Compress and Decompress with Dict", func(t *testing.T) {
		t.Parallel()
		var compressed bytes.Buffer
		require.NoError(t, zCodec.CompressWithDict(&compressed, testData, "fastest", dict), "CompressWithDict failed")

		var decompressed bytes.Buffer
		require.NoError(t, zCodec.DecompressWithDict(&decompressed, &compressed, int64(len(testData)), dict), "DecompressWithDict failed")

		if !bytes.Equal(decompressed.Bytes(), testData) {
			t.Fatalf("decompressed payload with dict mismatch")
		}
	})

	t.Run("DecompressWithOptionalDict helper", func(t *testing.T) {
		t.Parallel()
		var compressed bytes.Buffer
		require.NoError(t, zCodec.CompressWithDict(&compressed, testData, "fastest", dict), "CompressWithDict failed")

		var decompressed bytes.Buffer
		require.NoError(t, codec.DecompressWithOptionalDict(zCodec, &decompressed, &compressed, int64(len(testData)), dict),
			"DecompressWithOptionalDict failed")

		if !bytes.Equal(decompressed.Bytes(), testData) {
			t.Fatalf("DecompressWithOptionalDict payload mismatch")
		}

		// Also test DecompressWithOptionalDict on non-dict codec (None)
		noneCodec, _ := codec.Get(codec.AlgorithmNone)
		var noneOut bytes.Buffer
		err := codec.DecompressWithOptionalDict(noneCodec, &noneOut, bytes.NewReader(testData), int64(len(testData)), dict)
		require.NoError(t, err, "DecompressWithOptionalDict with noneCodec")
	})

	t.Run("Decompress without matching dict fails or errs on corrupted data", func(t *testing.T) {
		t.Parallel()
		var compressed bytes.Buffer
		require.NoError(t, zCodec.CompressWithDict(&compressed, testData, "fastest", dict), "CompressWithDict failed")

		wrongDict := []byte("invalid_or_wrong_dictionary_content_bytes_sequence_1234567890")
		var decompressed bytes.Buffer
		// Decompressing with empty dict or wrong dict should fail
		err := zCodec.DecompressWithDict(&decompressed, &compressed, int64(len(testData)), nil)
		if err == nil && !bytes.Equal(decompressed.Bytes(), testData) {
			t.Fatalf("expected error or mismatch when decompressing without dict")
		}

		var decompressedWrong bytes.Buffer
		_ = zCodec.DecompressWithDict(&decompressedWrong, bytes.NewReader(compressed.Bytes()), int64(len(testData)), wrongDict)
	})

	t.Run("Compress with invalid level", func(t *testing.T) {
		t.Parallel()
		var compressed bytes.Buffer
		err := zCodec.CompressWithDict(&compressed, testData, "invalid_num_abc", dict)
		if !errors.Is(err, codec.ErrInvalidCompressionLevel) {
			t.Fatalf("expected ErrInvalidCompressionLevel, got %v", err)
		}
	})

	t.Run("Writer error during CompressWithDict", func(t *testing.T) {
		t.Parallel()
		ew := &errWriter{}
		err := zCodec.CompressWithDict(ew, testData, "fastest", dict)
		require.Error(t, err, "expected error writing with errWriter")
	})
}

func TestTrainDictionaryValidation(t *testing.T) {
	t.Parallel()

	t.Run("Empty samples list", func(t *testing.T) {
		t.Parallel()
		_, err := codec.TrainDictionary(nil, 0, "")
		if err == nil {
			t.Fatalf("expected error on nil samples")
		}
	})

	t.Run("Zero total sample bytes", func(t *testing.T) {
		t.Parallel()
		_, err := codec.TrainDictionary([][]byte{{}, {}}, 0, "")
		if err == nil {
			t.Fatalf("expected error on empty slices")
		}
	})

	t.Run("Target dict size clamping", func(t *testing.T) {
		t.Parallel()
		samples := generateDictionarySamples()
		// Negative size -> default
		dict1, err := codec.TrainDictionary(samples, -100, "")
		if err != nil || len(dict1) == 0 {
			t.Fatalf("unexpected error: %v", err)
		}

		// Extremely large size -> capped at MaxDictSize
		dict2, err := codec.TrainDictionary(samples, 50*1024*1024, "best")
		if err != nil || len(dict2) == 0 {
			t.Fatalf("unexpected error: %v", err)
		}
	})
}

func TestDecompressionBombRejection(t *testing.T) {
	t.Parallel()

	const (
		bombPayloadSize   = 2 * 1024 * 1024 // 2 MB expanded payload
		declaredLimitSize = 512             // 512 bytes declared limit
	)

	// Create a highly repetitive payload that compresses to very few bytes
	largeData := bytes.Repeat([]byte("MICROFAT_HIGH_COMPRESSION_RATIO_REPETITIVE_PATTERN_0123456789\n"), bombPayloadSize/64)

	t.Run("Zstd decompression bomb rejected early", func(t *testing.T) {
		t.Parallel()
		zCodec, err := codec.Get(codec.AlgorithmZstd)
		require.NoError(t, err, "Get zstd")

		var compressed bytes.Buffer
		require.NoError(t, zCodec.Compress(&compressed, largeData, "best"), "Compress failed")

		var dest bytes.Buffer
		err = zCodec.Decompress(&dest, bytes.NewReader(compressed.Bytes()), declaredLimitSize)
		if err == nil {
			t.Fatal("expected error decompressing payload exceeding declared limit, got nil")
		}
		if !errors.Is(err, codec.ErrSizeMismatch) {
			t.Fatalf("expected ErrSizeMismatch, got %v", err)
		}
		if int64(dest.Len()) > declaredLimitSize {
			t.Fatalf("decompressed buffer exceeded limit: got %d bytes, limit was %d", dest.Len(), declaredLimitSize)
		}
	})

	t.Run("LZ4 decompression bomb rejected early", func(t *testing.T) {
		t.Parallel()
		lzCodec, err := codec.Get(codec.AlgorithmLZ4)
		require.NoError(t, err, "Get lz4")

		var compressed bytes.Buffer
		require.NoError(t, lzCodec.Compress(&compressed, largeData, "best"), "Compress failed")

		var dest bytes.Buffer
		err = lzCodec.Decompress(&dest, bytes.NewReader(compressed.Bytes()), declaredLimitSize)
		if err == nil {
			t.Fatal("expected error decompressing payload exceeding declared limit, got nil")
		}
		if !errors.Is(err, codec.ErrSizeMismatch) {
			t.Fatalf("expected ErrSizeMismatch, got %v", err)
		}
		if int64(dest.Len()) > declaredLimitSize {
			t.Fatalf("decompressed buffer exceeded limit: got %d bytes, limit was %d", dest.Len(), declaredLimitSize)
		}
	})

	t.Run("None decompression bomb rejected early", func(t *testing.T) {
		t.Parallel()
		nCodec, err := codec.Get(codec.AlgorithmNone)
		require.NoError(t, err, "Get none")

		var dest bytes.Buffer
		err = nCodec.Decompress(&dest, bytes.NewReader(largeData), declaredLimitSize)
		if err == nil {
			t.Fatal("expected error decompressing payload exceeding declared limit, got nil")
		}
		if !errors.Is(err, codec.ErrSizeMismatch) {
			t.Fatalf("expected ErrSizeMismatch, got %v", err)
		}
		if int64(dest.Len()) > declaredLimitSize {
			t.Fatalf("decompressed buffer exceeded limit: got %d bytes, limit was %d", dest.Len(), declaredLimitSize)
		}
	})

	t.Run("Zstd dictionary decompression bomb rejected early", func(t *testing.T) {
		t.Parallel()
		samples := generateDictionarySamples()
		dict, err := codec.TrainDictionary(samples, 32*1024, "default")
		require.NoError(t, err, "TrainDictionary failed")

		zCodecRaw, err := codec.Get(codec.AlgorithmZstd)
		require.NoError(t, err, "Get zstd")
		zCodec, ok := zCodecRaw.(codec.DictCodec)
		if !ok {
			t.Fatalf("expected DictCodec")
		}

		var compressed bytes.Buffer
		require.NoError(t, zCodec.CompressWithDict(&compressed, largeData, "fastest", dict), "CompressWithDict failed")

		var dest bytes.Buffer
		err = zCodec.DecompressWithDict(&dest, bytes.NewReader(compressed.Bytes()), declaredLimitSize, dict)
		if err == nil {
			t.Fatal("expected error decompressing payload with dict exceeding declared limit, got nil")
		}
		if !errors.Is(err, codec.ErrSizeMismatch) {
			t.Fatalf("expected ErrSizeMismatch, got %v", err)
		}
		if int64(dest.Len()) > declaredLimitSize {
			t.Fatalf("decompressed buffer exceeded limit: got %d bytes, limit was %d", dest.Len(), declaredLimitSize)
		}
	})
}

const (
	propPayloadMin    = 64
	propPayloadMax    = 16 * 1024
	propPropertyIters = 25
	propMutationCount = 2
	propSafetyLimit   = 8 * 1024
)

func TestCodec_PropertyInvariants(t *testing.T) {
	t.Parallel()

	codecs := codec.List()
	for _, codecName := range codecs {
		c, err := codec.Get(codecName)
		if err != nil {
			t.Fatalf("resolving registered codec %q: %v", codecName, err)
		}

		t.Run("Invariants_"+codecName, func(t *testing.T) {
			t.Parallel()

			testutil.RunPropertyTest(t, "roundtrip_and_bounds", propPropertyIters, 0, func(subT *testing.T, iter int, rng *rand.Rand) {
				length := rng.IntN(propPayloadMax-propPayloadMin) + propPayloadMin
				payload := testutil.RandomPayload(rng, length)

				var compressed bytes.Buffer
				if err := c.Compress(&compressed, payload, ""); err != nil {
					subT.Fatalf("codec %s failed to compress payload of size %d: %v", codecName, len(payload), err)
				}

				// Invariant 1: Exact uncompressed size roundtrip
				var roundtrip bytes.Buffer
				if err := c.Decompress(&roundtrip, bytes.NewReader(compressed.Bytes()), int64(len(payload))); err != nil {
					subT.Fatalf("codec %s roundtrip failed for size %d: %v", codecName, len(payload), err)
				}
				if !bytes.Equal(roundtrip.Bytes(), payload) {
					subT.Fatalf("codec %s roundtrip payload mismatch for size %d", codecName, len(payload))
				}

				// Invariant 2: Bounded decompression enforcement on truncated input
				if compressed.Len() > 4 {
					truncated := testutil.TruncateBytes(rng, compressed.Bytes())
					testutil.AssertDecompressionBounds(subT, c, bytes.NewReader(truncated), int64(len(payload)))
				}

				// Invariant 3: Bounded decompression enforcement on mutated stream
				mutated := testutil.MutateBytes(rng, compressed.Bytes(), propMutationCount)
				testutil.AssertDecompressionBounds(subT, c, bytes.NewReader(mutated), int64(len(payload)))

				// Invariant 4: Declared uncompressed limit ceiling enforcement
				if len(payload) > propSafetyLimit {
					var cappedOut bytes.Buffer
					err := c.Decompress(&cappedOut, bytes.NewReader(compressed.Bytes()), propSafetyLimit)
					if err == nil && int64(len(payload)) > propSafetyLimit {
						subT.Fatalf("expected error for payload size %d exceeding limit %d", len(payload), propSafetyLimit)
					}
					if int64(cappedOut.Len()) > propSafetyLimit {
						subT.Fatalf("codec %s wrote %d bytes exceeding safety limit %d", codecName, cappedOut.Len(), propSafetyLimit)
					}
				}
			})
		})
	}
}

func BenchmarkCodecs(b *testing.B) {
	data := generateTestData(1024 * 1024) // 1 MB payload

	for _, name := range []string{codec.AlgorithmNone, codec.AlgorithmLZ4, codec.AlgorithmZstd} {
		c, _ := codec.Get(name)

		var compressed bytes.Buffer
		_ = c.Compress(&compressed, data, "")
		compBytes := compressed.Bytes()

		b.Run("Decompress/"+name, func(b *testing.B) {
			b.SetBytes(int64(len(data)))
			b.ReportAllocs()
			for i := 0; i < b.N; i++ {
				r := bytes.NewReader(compBytes)
				err := c.Decompress(io.Discard, r, int64(len(data)))
				if err != nil {
					b.Fatalf("decompress: %v", err)
				}
			}
		})
	}
}

func TestDecompress_NegativeAndOversizedBounds(t *testing.T) {
	t.Parallel()

	data := generateTestData(1024)
	for _, name := range []string{codec.AlgorithmNone, codec.AlgorithmLZ4, codec.AlgorithmZstd} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()
			c, err := codec.Get(name)
			if err != nil {
				t.Fatalf("codec.Get(%q) failed: %v", name, err)
			}

			var comp bytes.Buffer
			if err := c.Compress(&comp, data, ""); err != nil {
				t.Fatalf("compress failed: %v", err)
			}
			compBytes := comp.Bytes()

			// 1. Negative uncompressedSize
			var out bytes.Buffer
			err = c.Decompress(&out, bytes.NewReader(compBytes), -1)
			if err == nil || !errors.Is(err, codec.ErrSizeMismatch) {
				t.Fatalf("expected ErrSizeMismatch for negative uncompressedSize, got %v", err)
			}

			// 2. uncompressedSize = 0 with non-empty payload
			out.Reset()
			err = c.Decompress(&out, bytes.NewReader(compBytes), 0)
			if err == nil || !errors.Is(err, codec.ErrSizeMismatch) {
				t.Fatalf("expected ErrSizeMismatch for 0 uncompressedSize with data, got %v", err)
			}

			// 3. uncompressedSize > DefaultMaxPayloadSize
			out.Reset()
			err = c.Decompress(&out, bytes.NewReader(compBytes), codec.DefaultMaxPayloadSize+1)
			if err == nil || !errors.Is(err, codec.ErrSizeMismatch) {
				t.Fatalf("expected ErrSizeMismatch for exceeding DefaultMaxPayloadSize, got %v", err)
			}
		})
	}
}

func TestTrainDictionaryLargeSamples(t *testing.T) {
	t.Parallel()
	const sampleRepetitions = 256
	payload := bytes.Repeat(generateDictionarySamples()[0], sampleRepetitions)
	require.Greater(t, len(payload), testPayloadSizeLarge)
	for _, level := range []string{testLevelFastest, "default", "better", testLevelBest} {
		t.Run(level, func(t *testing.T) {
			dict, err := codec.TrainDictionary([][]byte{payload, payload}, codec.DefaultDictSize, level)
			require.NoError(t, err)
			require.NotEmpty(t, dict)
			c := codec.NewZstdCodec()
			var compressed, output bytes.Buffer
			require.NoError(t, c.CompressWithDict(&compressed, payload, level, dict))
			require.NoError(t, c.DecompressWithDict(&output, &compressed, int64(len(payload)), dict))
			require.Equal(t, payload, output.Bytes())
		})
	}
}
