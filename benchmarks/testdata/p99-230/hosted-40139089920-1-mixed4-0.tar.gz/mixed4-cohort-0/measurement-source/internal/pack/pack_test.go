package pack

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"

	"github.com/EpicBlackWolfZ/microfat/internal/codec"
	"github.com/EpicBlackWolfZ/microfat/internal/format"
	"github.com/EpicBlackWolfZ/microfat/internal/microarch"
	"github.com/klauspost/compress/zstd"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const (
	testOSLinux            = "linux"
	testArchAMD64          = "amd64"
	testLevelV80           = "v8.0"
	testCompressionZstd    = "zstd"
	testCompressionFastest = "fastest"
	testValidSHA256        = "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
	testAliasAMD64v3       = "amd64_v3"
)

func TestValidatePayloadABIs_SkipELFValidationWithCallback(t *testing.T) {
	t.Parallel()
	var cbReport *ArtifactABIReport
	opts := &Options{
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": "/path/to/v1", "v3": "/path/to/v3"},
		ABIReportCallback: func(rep *ArtifactABIReport) {
			cbReport = rep
		},
	}
	err := validatePayloadABIs(opts, []string{"v1", "v3"})
	require.NoError(t, err)
	require.NotNil(t, cbReport)
	assert.Equal(t, ComparisonSkipped, cbReport.Status)
	assert.Equal(t, 2, len(cbReport.Variants))
	assert.Equal(t, MetadataSkipped, cbReport.Variants[0].Completeness)
}

func TestPack_VariantValidatorError(t *testing.T) {
	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "microfat-stub")
	require.NoError(t, os.WriteFile(stubPath, []byte("stub"), 0o755))
	v1Path := filepath.Join(tempDir, "bin-v1")
	require.NoError(t, os.WriteFile(v1Path, []byte("v1"), 0o755))

	opts := Options{
		StubPath:          stubPath,
		OutputPath:        filepath.Join(tempDir, "fat-app"),
		AppName:           "validator-app",
		Variants:          map[string]string{"v1": v1Path},
		SkipELFValidation: true,
		VariantValidator: func(string, string) error {
			return errors.New("simulated validator rejection")
		},
	}
	_, err := Pack(opts)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "simulated validator rejection")
}

func TestPackAndVerify(t *testing.T) {
	tempDir := t.TempDir()

	// 1. Create fake stub binary
	stubPath := filepath.Join(tempDir, "microfat-stub")
	stubContent := []byte("#!/bin/sh\necho Stub Launcher\n")
	require.NoError(t, os.WriteFile(stubPath, stubContent, 0o755), "failed to write stub")

	// 2. Create fake variant binaries
	v1Path := filepath.Join(tempDir, "bin-v1")
	v1Content := []byte("#!/bin/sh\necho Executing Variant v1 (Baseline SSE2)\n")
	require.NoError(t, os.WriteFile(v1Path, v1Content, 0o755), "failed to write v1")

	v3Path := filepath.Join(tempDir, "bin-v3")
	v3Content := []byte("#!/bin/sh\necho Executing Variant v3 (AVX2/FMA/BMI2)\n")
	require.NoError(t, os.WriteFile(v3Path, v3Content, 0o755), "failed to write v3")

	v4Path := filepath.Join(tempDir, "bin-v4")
	v4Content := []byte("#!/bin/sh\necho Executing Variant v4 (AVX-512)\n")
	require.NoError(t, os.WriteFile(v4Path, v4Content, 0o755), "failed to write v4")

	// 3. Pack into fat binary
	fatBinaryPath := filepath.Join(tempDir, "output-fat-app")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatBinaryPath,
		AppName:           "test-fat-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		CompressionLevel:  testCompressionFastest,
		Variants: map[string]string{
			"v1": v1Path,
			"v3": v3Path,
			"v4": v4Path,
		},
	}

	idx, err := Pack(opts)
	require.NoError(t, err, "Pack failed")

	if len(idx.Variants) != 3 {
		t.Fatalf("expected 3 variants in index, got %d", len(idx.Variants))
	}
	if idx.Variants[0].Level != "v1" || idx.Variants[1].Level != "v3" || idx.Variants[2].Level != "v4" {
		t.Errorf("variants not ordered ascending: %+v", idx.Variants)
	}

	// 4. Verify the generated binary
	file, err := os.Open(fatBinaryPath)
	require.NoError(t, err, "failed to open packed binary")
	defer func() { _ = file.Close() }()

	stat, err := file.Stat()
	require.NoError(t, err, "failed to stat file")

	if !format.IsFatBinary(file, stat.Size()) {
		t.Errorf("expected IsFatBinary to be true")
	}

	verifiedIdx, results, err := VerifyBinary(file, stat.Size())
	require.NoError(t, err, "VerifyBinary failed")

	if verifiedIdx.AppName != "test-fat-app" {
		t.Errorf("expected AppName test-fat-app, got %s", verifiedIdx.AppName)
	}

	if len(results) != 3 {
		t.Fatalf("expected 3 verification results, got %d", len(results))
	}

	for _, res := range results {
		if !res.Valid || res.Error != nil {
			t.Errorf("variant %s failed verification: %v", res.Level, res.Error)
		}
	}
}

func TestTrimBinary(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-header-code"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	v3Path := filepath.Join(tempDir, "v3")
	_ = os.WriteFile(v1Path, []byte("v1-binary-payload"), 0o755)
	_ = os.WriteFile(v3Path, []byte("v3-binary-payload-larger-data"), 0o755)

	fatPath := filepath.Join(tempDir, "fat")
	_, err := Pack(Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		SkipELFValidation: true,
		Variants: map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		},
	})
	if err != nil {
		t.Fatalf("Pack failed: %v", err)
	}

	fatFile, err := os.Open(fatPath)
	if err != nil {
		t.Fatalf("open fat: %v", err)
	}
	defer func() { _ = fatFile.Close() }()

	stat, _ := fatFile.Stat()

	// 1. Trim to v3
	var trimmedBuf bytes.Buffer
	newIdx, err := TrimBinary(fatFile, stat.Size(), "v3", &trimmedBuf)
	if err != nil {
		t.Fatalf("TrimBinary failed: %v", err)
	}

	if len(newIdx.Variants) != 1 || newIdx.Variants[0].Level != "v3" {
		t.Fatalf("expected 1 variant 'v3', got %+v", newIdx.Variants)
	}

	// 2. Verify the trimmed buffer
	trimmedReader := bytes.NewReader(trimmedBuf.Bytes())
	verifiedIdx, results, err := VerifyBinary(trimmedReader, int64(trimmedBuf.Len()))
	if err != nil {
		t.Fatalf("VerifyBinary on trimmed binary failed: %v", err)
	}
	if len(verifiedIdx.Variants) != 1 || !results[0].Valid {
		t.Errorf("trimmed binary verification failed: %+v", results)
	}

	// 3. Error case: trim to non-existent variant
	var dummy bytes.Buffer
	_, err = TrimBinary(fatFile, stat.Size(), "v99", &dummy)
	if err == nil {
		t.Errorf("expected error trimming non-existent variant")
	}
}

func TestPackValidationErrors(t *testing.T) {
	tempDir := t.TempDir()

	// No variants
	_, err := Pack(Options{StubPath: "stub", OutputPath: "out", SkipELFValidation: true})
	if !errors.Is(err, ErrNoVariantsSpecified) {
		t.Errorf("expected ErrNoVariantsSpecified, got %v", err)
	}

	// Empty output path
	_, err = Pack(Options{
		StubPath:          "stub",
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": "dummy"},
	})
	if err == nil {
		t.Errorf("expected error for empty output path")
	}

	// Missing stub
	_, err = Pack(Options{
		StubPath:          filepath.Join(tempDir, "nonexistent-stub"),
		OutputPath:        filepath.Join(tempDir, "out"),
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": filepath.Join(tempDir, "nonexistent-v1")},
	})
	if !errors.Is(err, ErrStubMissing) {
		t.Errorf("expected ErrStubMissing, got %v", err)
	}

	// Valid stub, missing variant
	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub"), 0o755)
	_, err = Pack(Options{
		StubPath:          stubPath,
		OutputPath:        filepath.Join(tempDir, "out"),
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": filepath.Join(tempDir, "nonexistent-v1")},
	})
	if !errors.Is(err, ErrVariantNotFound) {
		t.Errorf("expected ErrVariantNotFound, got %v", err)
	}

	// Pack with default OS/Arch/Permissions and invalid destination directory
	v1Real := filepath.Join(tempDir, "v1_real")
	_ = os.WriteFile(v1Real, []byte("v1"), 0o755)
	_, err = Pack(Options{
		StubPath:          stubPath,
		OutputPath:        filepath.Join(tempDir, "nonexistent_dir", "out"),
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Real},
	})
	if err == nil {
		t.Errorf("expected error packing into nonexistent directory")
	}

	// Empty stub path
	_, err = Pack(Options{
		StubPath:          "",
		OutputPath:        filepath.Join(tempDir, "out"),
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Real},
	})
	if !errors.Is(err, ErrStubMissing) {
		t.Errorf("expected ErrStubMissing for empty stub path, got %v", err)
	}

	// Invalid ELF stub with ELF validation enabled
	_, err = Pack(Options{
		StubPath:          stubPath,
		OutputPath:        filepath.Join(tempDir, "out"),
		SkipELFValidation: false,
		Variants:          map[string]string{"v1": v1Real},
	})
	if err == nil || !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF validating non-ELF stub, got %v", err)
	}

	// Valid ELF stub, invalid ELF variant with ELF validation enabled
	amd64StubValid := createDummyELF(t, tempDir, "amd64_stub_val", 62, 2)
	_, err = Pack(Options{
		StubPath:          amd64StubValid,
		OutputPath:        filepath.Join(tempDir, "out"),
		SkipELFValidation: false,
		Variants:          map[string]string{"v1": v1Real},
	})
	if err == nil || !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF validating non-ELF variant, got %v", err)
	}

	// Read-only directory for OutputPath
	roDir := filepath.Join(tempDir, "ro_pack_dir")
	_ = os.MkdirAll(roDir, 0o755)
	_ = os.Chmod(roDir, 0o555)
	defer func() { _ = os.Chmod(roDir, 0o755) }()
	_, err = Pack(Options{
		StubPath:          stubPath,
		OutputPath:        filepath.Join(roDir, "out"),
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Real},
	})
	if err == nil {
		t.Errorf("expected error packing into read-only directory")
	}

	// Missing variant file when SkipELFValidation is true
	_, err = Pack(Options{
		StubPath:          stubPath,
		OutputPath:        filepath.Join(tempDir, "out_missing_var"),
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": filepath.Join(tempDir, "missing_v1")},
	})
	if err == nil || !errors.Is(err, ErrVariantNotFound) {
		t.Errorf("expected ErrVariantNotFound packing with missing variant file, got %v", err)
	}
}

func TestVerifyCorruptedVariant(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-data-12345"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	_ = os.WriteFile(v1Path, []byte("v1-binary-payload-data"), 0o755)

	fatPath := filepath.Join(tempDir, "fat")
	_, err := Pack(Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Path},
	})
	if err != nil {
		t.Fatalf("Pack failed: %v", err)
	}

	data, err := os.ReadFile(fatPath)
	if err != nil {
		t.Fatalf("failed to read fat file: %v", err)
	}

	// Corrupt payload data inside the file (byte at index 20)
	corruptData := make([]byte, len(data))
	copy(corruptData, data)
	corruptData[len("stub-data-12345")+2] ^= 0xFF

	reader := bytes.NewReader(corruptData)
	_, results, err := VerifyBinary(reader, int64(len(corruptData)))
	if err != nil {
		t.Fatalf("VerifyBinary failed unexpectedly at index stage: %v", err)
	}
	if len(results) != 1 {
		t.Fatalf("expected 1 result, got %d", len(results))
	}
	if results[0].Valid {
		t.Errorf("expected corrupted variant to be invalid")
	}

	// Test size and checksum mismatches in verification with valid zstd payloads
	var zstdPayload bytes.Buffer
	enc, _ := zstd.NewWriter(&zstdPayload)
	_, _ = enc.Write([]byte("valid-uncompressed-content"))
	_ = enc.Close()

	payloadBytes := zstdPayload.Bytes()
	idxSizeMismatch := &format.Index{
		Version:     format.FormatVersionCurrent,
		TargetArch:  testArchAMD64,
		CreatedUnix: 1000,
		Variants: []format.VariantEntry{
			{
				Level:            "v1",
				Offset:           0,
				CompressedSize:   int64(len(payloadBytes)),
				UncompressedSize: int64(len("valid-uncompressed-content")) + 50, // wrong uncompressed size
				SHA256:           testValidSHA256,
			},
		},
	}
	var bufSize bytes.Buffer
	_, _ = bufSize.Write(payloadBytes)
	_, _ = format.WriteIndexAndTrailer(&bufSize, idxSizeMismatch, int64(len(payloadBytes)))
	_, resSize, _ := VerifyBinary(bytes.NewReader(bufSize.Bytes()), int64(bufSize.Len()))
	if len(resSize) != 1 || resSize[0].Valid || !errors.Is(resSize[0].Error, ErrSizeMismatch) {
		t.Errorf("expected ErrSizeMismatch, got %+v", resSize)
	}

	idxHashMismatch := &format.Index{
		Version:     format.FormatVersionCurrent,
		TargetArch:  testArchAMD64,
		CreatedUnix: 1000,
		Variants: []format.VariantEntry{
			{
				Level:            "v1",
				Offset:           0,
				CompressedSize:   int64(len(payloadBytes)),
				UncompressedSize: int64(len("valid-uncompressed-content")),
				SHA256:           "0000000000000000000000000000000000000000000000000000000000000000", // wrong hash
			},
		},
	}
	var bufHash bytes.Buffer
	_, _ = bufHash.Write(payloadBytes)
	_, _ = format.WriteIndexAndTrailer(&bufHash, idxHashMismatch, int64(len(payloadBytes)))
	_, resHash, _ := VerifyBinary(bytes.NewReader(bufHash.Bytes()), int64(bufHash.Len()))
	if len(resHash) != 1 || resHash[0].Valid || !errors.Is(resHash[0].Error, ErrChecksumMismatch) {
		t.Errorf("expected ErrChecksumMismatch, got %+v", resHash)
	}

	// VerifyBinary error reading index
	_, _, err = VerifyBinary(bytes.NewReader([]byte("not-a-fat-binary")), int64(len("not-a-fat-binary")))
	if err == nil {
		t.Errorf("expected VerifyBinary to fail on non-fat binary")
	}
}

func TestTrimBinaryEdgeCases(t *testing.T) {
	// Index with no variants
	idxNoVariants := &format.Index{
		Version:     format.FormatVersionCurrent,
		CreatedUnix: 1000,
		Variants:    []format.VariantEntry{},
	}
	var bufEmpty bytes.Buffer
	_, _ = format.WriteIndexAndTrailer(&bufEmpty, idxNoVariants, 0)
	var out bytes.Buffer
	_, err := TrimBinary(bytes.NewReader(bufEmpty.Bytes()), int64(bufEmpty.Len()), "v1", &out)
	if err == nil {
		t.Errorf("expected error trimming empty variants index")
	}

	// Index with invalid stub offset (stubSize <= 0)
	idxInvalidStub := &format.Index{
		Version:     format.FormatVersionCurrent,
		TargetArch:  testArchAMD64,
		CreatedUnix: 1000,
		Variants: []format.VariantEntry{
			{Level: "v1", Offset: 0, CompressedSize: 10, UncompressedSize: 10, SHA256: testValidSHA256},
		},
	}
	var bufInvalidStub bytes.Buffer
	_, _ = bufInvalidStub.Write([]byte("0123456789"))
	_, _ = format.WriteIndexAndTrailer(&bufInvalidStub, idxInvalidStub, 10)
	var outDummy bytes.Buffer
	_, err = TrimBinary(bytes.NewReader(bufInvalidStub.Bytes()), int64(bufInvalidStub.Len()), "v1", &outDummy)
	if err == nil {
		t.Errorf("expected error for invalid stub size <= 0")
	}

	// Error copying stub / variant / trailer when writer fails
	idxValid := &format.Index{
		Version:     format.FormatVersionCurrent,
		TargetArch:  testArchAMD64,
		CreatedUnix: 1000,
		Variants: []format.VariantEntry{
			{Level: "v1", Offset: 5, CompressedSize: 5, UncompressedSize: 5, SHA256: testValidSHA256},
		},
	}
	var bufValid bytes.Buffer
	_, _ = bufValid.Write([]byte("0123456789"))
	_, _ = format.WriteIndexAndTrailer(&bufValid, idxValid, 10)
	validReader := bytes.NewReader(bufValid.Bytes())
	validSize := int64(bufValid.Len())

	for i := 1; i <= 3; i++ {
		_, err = TrimBinary(validReader, validSize, "v1", &errWriter{failOnWrite: i})
		if err == nil {
			t.Errorf("expected TrimBinary to fail when writer fails on write %d", i)
		}
	}
}

type errWriter struct {
	failOnWrite int
	writes      int
}

func (w *errWriter) Write(p []byte) (n int, err error) {
	w.writes++
	if w.writes >= w.failOnWrite {
		return 0, errors.New("write failed")
	}
	return len(p), nil
}

func TestELFValidation(t *testing.T) {
	tempDir := t.TempDir()

	// Non-existent file
	if err := ValidateELFBinary(filepath.Join(tempDir, "nonexistent"), testOSLinux, testArchAMD64); err == nil {
		t.Errorf("expected ValidateELFBinary to fail on nonexistent file")
	}

	// 1. Create a valid 64-bit AMD64 ELF dummy
	amd64Stub := createDummyELF(t, tempDir, "amd64_stub", 62, 2) // EM_X86_64, ELFCLASS64
	amd64V1 := createDummyELF(t, tempDir, "amd64_v1", 62, 2)
	arm64Stub := createDummyELF(t, tempDir, "arm64_stub", 183, 2) // EM_AARCH64, ELFCLASS64
	arm64V1 := createDummyELF(t, tempDir, "arm64_v1", 183, 2)     // EM_AARCH64, ELFCLASS64
	elf32Bit := createDummyELF(t, tempDir, "elf32", 62, 1)        // ELFCLASS32
	nonELF := filepath.Join(tempDir, "script.sh")
	_ = os.WriteFile(nonELF, []byte("#!/bin/sh\necho hi\n"), 0o755)

	// Valid AMD64 pack
	outPath := filepath.Join(tempDir, "fat_amd64")
	_, err := Pack(Options{
		StubPath:   amd64Stub,
		OutputPath: outPath,
		TargetOS:   testOSLinux,
		TargetArch: testArchAMD64,
		Variants:   map[string]string{"v1": amd64V1},
	})
	if err != nil {
		t.Fatalf("expected valid AMD64 pack to succeed, got: %v", err)
	}

	// Valid ARM64 pack
	outARM64Path := filepath.Join(tempDir, "fat_arm64")
	_, err = Pack(Options{
		StubPath:   arm64Stub,
		OutputPath: outARM64Path,
		TargetOS:   testOSLinux,
		TargetArch: "arm64",
		Variants:   map[string]string{testLevelV80: arm64V1},
	})
	if err != nil {
		t.Fatalf("expected valid ARM64 pack to succeed, got: %v", err)
	}

	// Reject 32-bit ELF
	if err := ValidateELFBinary(elf32Bit, testOSLinux, testArchAMD64); !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF for 32-bit ELF, got %v", err)
	}

	// Reject non-ELF file
	outNonELF := filepath.Join(tempDir, "fat_nonelf")
	_, err = Pack(Options{
		StubPath:   nonELF,
		OutputPath: outNonELF,
		TargetOS:   testOSLinux,
		TargetArch: testArchAMD64,
		Variants:   map[string]string{"v1": amd64V1},
	})
	if !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF for non-ELF stub, got %v", err)
	}

	// Reject mismatched architecture (ARM64 binary for AMD64 target)
	outMismatch := filepath.Join(tempDir, "fat_mismatch")
	_, err = Pack(Options{
		StubPath:   amd64Stub,
		OutputPath: outMismatch,
		TargetOS:   testOSLinux,
		TargetArch: testArchAMD64,
		Variants:   map[string]string{"v1": arm64V1},
	})
	if !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF for mismatched architecture variant, got %v", err)
	}

	// Test aliases x86_64 and aarch64
	if err := ValidateELFBinary(amd64V1, testOSLinux, "x86_64"); err != nil {
		t.Errorf("expected x86_64 alias to succeed: %v", err)
	}
	if err := ValidateELFBinary(arm64V1, testOSLinux, "aarch64"); err != nil {
		t.Errorf("expected aarch64 alias to succeed: %v", err)
	}
}

func TestFinalizeOutputFile(t *testing.T) {
	tempDir := t.TempDir()

	// Success case
	tmp1, _ := os.CreateTemp(tempDir, "tmp1")
	tmpPath1 := tmp1.Name()
	dest1 := filepath.Join(tempDir, "dest1")
	if err := finalizeOutputFile(tmp1, tmpPath1, dest1, 0o755); err != nil {
		t.Fatalf("finalizeOutputFile success case failed: %v", err)
	}

	// Error case: destination is an existing non-empty directory
	tmp2, _ := os.CreateTemp(tempDir, "tmp2")
	tmpPath2 := tmp2.Name()
	if err := finalizeOutputFile(tmp2, tmpPath2, tempDir, 0o755); err == nil {
		t.Errorf("expected error renaming into existing directory")
	}

	// Error case: file is already closed (sync/chmod fails)
	tmp3, _ := os.CreateTemp(tempDir, "tmp3")
	tmpPath3 := tmp3.Name()
	_ = tmp3.Close()
	if err := finalizeOutputFile(tmp3, tmpPath3, filepath.Join(tempDir, "dest3"), 0o755); err == nil {
		t.Errorf("expected error finalizing closed file")
	}

	// Error case: tmpPath is removed before rename
	tmp5, _ := os.CreateTemp(tempDir, "tmp5")
	tmpPath5 := tmp5.Name()
	_ = os.Remove(tmpPath5)
	if err := finalizeOutputFile(tmp5, tmpPath5, filepath.Join(tempDir, "dest5"), 0o755); err == nil {
		t.Errorf("expected error when tmpPath does not exist on rename")
	}

	// Error case: writeVariantPayload with closed file
	validPayload := filepath.Join(tempDir, "valid_payload")
	_ = os.WriteFile(validPayload, []byte("payload"), 0o644)
	packOpts := &Options{}
	if _, _, err := writeVariantPayload(tmp3, "v1", validPayload, packOpts, 0, nil); err == nil {
		t.Errorf("expected error writing payload to closed file")
	}

	// Error case: writeVariantPayload with nonexistent file
	tmp4, _ := os.CreateTemp(tempDir, "tmp4")
	defer func() {
		_ = tmp4.Close()
		_ = os.Remove(tmp4.Name())
	}()
	if _, _, err := writeVariantPayload(tmp4, "v1", filepath.Join(tempDir, "nonexistent"), packOpts, 0, nil); err == nil {
		t.Errorf("expected error writing nonexistent payload")
	}
}

func TestPackEdgeCasesAndValidation(t *testing.T) {
	tempDir := t.TempDir()

	// 1. ValidateELFBinary with unsupported/mismatched machine types
	amd64ELF := createDummyELF(t, tempDir, "amd64_mismatch", 62, 2)  // EM_X86_64
	arm64ELF := createDummyELF(t, tempDir, "arm64_mismatch", 183, 2) // EM_AARCH64
	i386ELF := createDummyELF(t, tempDir, "i386_elf", 3, 2)          // EM_386 with 64-bit class

	// Test AMD64 target with ARM64 ELF
	if err := ValidateELFBinary(arm64ELF, testOSLinux, "amd64"); !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF validating ARM64 binary against amd64 target, got %v", err)
	}

	// Test ARM64 target with AMD64 ELF
	if err := ValidateELFBinary(amd64ELF, testOSLinux, "arm64"); !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF validating AMD64 binary against arm64 target, got %v", err)
	}

	// Test AMD64 target with i386 ELF
	if err := ValidateELFBinary(i386ELF, testOSLinux, "amd64"); !errors.Is(err, ErrInvalidELF) {
		t.Errorf("expected ErrInvalidELF validating i386 binary against amd64 target, got %v", err)
	}

	// 2. VerifyBinary with corrupted zstd stream in variant payload
	corruptPayload := []byte("INVALID_ZSTD_STREAM_CONTENT_1234567890")
	idxCorrupt := &format.Index{
		Version:     format.FormatVersionCurrent,
		TargetArch:  testArchAMD64,
		CreatedUnix: 1000,
		Variants: []format.VariantEntry{
			{
				Level:            "v1",
				Offset:           0,
				CompressedSize:   int64(len(corruptPayload)),
				UncompressedSize: 100,
				SHA256:           testValidSHA256,
			},
		},
	}
	var bufCorrupt bytes.Buffer
	_, _ = bufCorrupt.Write(corruptPayload)
	_, _ = format.WriteIndexAndTrailer(&bufCorrupt, idxCorrupt, int64(len(corruptPayload)))

	_, resCorrupt, err := VerifyBinary(bytes.NewReader(bufCorrupt.Bytes()), int64(bufCorrupt.Len()))
	if err != nil {
		t.Fatalf("unexpected error reading index in VerifyBinary: %v", err)
	}
	if len(resCorrupt) != 1 || resCorrupt[0].Valid || resCorrupt[0].Error == nil {
		t.Errorf("expected VerifyBinary to report error on corrupted zstd stream, got %+v", resCorrupt)
	}
}

func TestPackVerifyTrimARM64MultiVariant(t *testing.T) {
	t.Parallel()
	tempDir := t.TempDir()

	arm64Stub := createDummyELF(t, tempDir, "arm64_stub_multi", 183, 2)
	arm64V80 := createDummyELF(t, tempDir, "arm64_v80", 183, 2)
	arm64V82 := createDummyELF(t, tempDir, "arm64_v82", 183, 2)
	arm64V90 := createDummyELF(t, tempDir, "arm64_v90", 183, 2)

	outPath := filepath.Join(tempDir, "fat_arm64_multi")
	idx, err := Pack(Options{
		StubPath:   arm64Stub,
		OutputPath: outPath,
		AppName:    "arm64-test-app",
		TargetOS:   testOSLinux,
		TargetArch: "arm64",
		Variants: map[string]string{
			"v8.0": arm64V80,
			"v8.2": arm64V82,
			"v9.0": arm64V90,
		},
	})
	if err != nil {
		t.Fatalf("Pack failed for multi-variant ARM64: %v", err)
	}

	if len(idx.Variants) != 3 {
		t.Fatalf("expected 3 variants, got %d", len(idx.Variants))
	}
	// Verify sorted order (v8.0 < v8.2 < v9.0)
	if idx.Variants[0].Level != "v8.0" || idx.Variants[1].Level != "v8.2" || idx.Variants[2].Level != "v9.0" {
		t.Errorf("unexpected variant order: %+v", idx.Variants)
	}

	// Verify binary
	f, err := os.Open(outPath)
	if err != nil {
		t.Fatalf("open fat binary: %v", err)
	}
	defer f.Close()

	stat, _ := f.Stat()
	vIdx, results, err := VerifyBinary(f, stat.Size())
	if err != nil {
		t.Fatalf("VerifyBinary failed: %v", err)
	}
	if vIdx.AppName != "arm64-test-app" {
		t.Errorf("expected AppName arm64-test-app, got %s", vIdx.AppName)
	}
	for _, r := range results {
		if !r.Valid {
			t.Errorf("expected variant %s to be valid, got error %v", r.Level, r.Error)
		}
	}

	// Trim binary to v8.2
	var trimBuf bytes.Buffer
	trimmedIdx, err := TrimBinary(f, stat.Size(), "v8.2", &trimBuf)
	if err != nil {
		t.Fatalf("TrimBinary failed for v8.2: %v", err)
	}
	if len(trimmedIdx.Variants) != 1 || trimmedIdx.Variants[0].Level != "v8.2" {
		t.Errorf("unexpected trimmed index: %+v", trimmedIdx)
	}
}

func createDummyELF(t *testing.T, dir, name string, machine uint16, class byte) string {
	t.Helper()
	path := filepath.Join(dir, name)
	hdr := make([]byte, 128)
	copy(hdr[0:4], []byte{0x7f, 'E', 'L', 'F'})
	hdr[4] = class // EI_CLASS (2 = 64-bit, 1 = 32-bit)
	hdr[5] = 1     // EI_DATA (1 = little endian)
	hdr[6] = 1     // EI_VERSION (1 = current)
	hdr[7] = 0     // EI_OSABI
	// e_type = 2 (ET_EXEC)
	hdr[16] = 2
	// e_machine
	hdr[18] = byte(machine)
	hdr[19] = byte(machine >> 8)
	// e_version = 1
	hdr[20] = 1
	// e_ehsize = 64
	hdr[52] = 64
	// One file-backed executable PT_LOAD containing the entry point.
	const baseAddress = 0x400000
	const entryAddress = baseAddress + 120
	binary.LittleEndian.PutUint64(hdr[24:32], entryAddress)
	binary.LittleEndian.PutUint64(hdr[32:40], 64)
	binary.LittleEndian.PutUint16(hdr[54:56], 56)
	binary.LittleEndian.PutUint16(hdr[56:58], 1)
	binary.LittleEndian.PutUint32(hdr[64:68], 1)
	binary.LittleEndian.PutUint32(hdr[68:72], 5)
	binary.LittleEndian.PutUint64(hdr[80:88], baseAddress)
	binary.LittleEndian.PutUint64(hdr[96:104], uint64(len(hdr)))
	binary.LittleEndian.PutUint64(hdr[104:112], uint64(len(hdr)))
	binary.LittleEndian.PutUint64(hdr[112:120], 1)

	if err := os.WriteFile(path, hdr, 0o755); err != nil {
		t.Fatalf("writing dummy elf: %v", err)
	}
	return path
}

func TestPrewarmVariantAndBinary(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-payload"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	v1Content := []byte("v1-binary-content-12345")
	_ = os.WriteFile(v1Path, v1Content, 0o755)

	v3Path := filepath.Join(tempDir, "v3")
	v3Content := []byte("v3-binary-content-67890-avx2")
	_ = os.WriteFile(v3Path, v3Content, 0o755)

	fatPath := filepath.Join(tempDir, "fat.bin")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "prewarm-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Variants: map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		},
	}

	_, err := Pack(opts)
	require.NoError(t, err, "Pack failed")

	f, err := os.Open(fatPath)
	require.NoError(t, err, "Open failed")
	defer func() { _ = f.Close() }()

	stat, err := f.Stat()
	require.NoError(t, err, "Stat failed")

	cacheDir := filepath.Join(tempDir, "prewarm_cache")

	// 1. Prewarm specific level "v3"
	idx, results, err := PrewarmBinary(f, stat.Size(), []string{"v3"}, cacheDir)
	require.NoError(t, err, "PrewarmBinary(v3) failed")
	if len(results) != 1 || results[0].Level != "v3" {
		t.Fatalf("unexpected results for v3: %+v", results)
	}
	if results[0].AlreadyCached {
		t.Errorf("expected alreadyCached=false on first prewarm")
	}

	// Verify cached file content
	cachedData, err := os.ReadFile(results[0].CachedPath)
	require.NoError(t, err, "failed reading cached file")
	if !bytes.Equal(cachedData, v3Content) {
		t.Errorf("cached content mismatch: expected %q, got %q", v3Content, cachedData)
	}

	// 2. Prewarm again (should be cache hit)
	_, results2, err := PrewarmBinary(f, stat.Size(), []string{"v3"}, cacheDir)
	require.NoError(t, err, "PrewarmBinary second time failed")
	if len(results2) != 1 || !results2[0].AlreadyCached {
		t.Errorf("expected alreadyCached=true on second prewarm, got %+v", results2)
	}

	// 3. Prewarm all variants (v3 is hit, v1 is extracted)
	_, resultsAll, err := PrewarmBinary(f, stat.Size(), nil, cacheDir)
	require.NoError(t, err, "PrewarmBinary(all) failed")
	if len(resultsAll) != 2 {
		t.Fatalf("expected 2 results, got %d", len(resultsAll))
	}
	var v1Res, v3Res format.PrewarmResult
	for _, r := range resultsAll {
		switch r.Level {
		case "v1":
			v1Res = r
		case "v3":
			v3Res = r
		}
	}
	if v1Res.AlreadyCached {
		t.Errorf("expected v1 alreadyCached=false")
	}
	if !v3Res.AlreadyCached {
		t.Errorf("expected v3 alreadyCached=true")
	}

	// 4. Prewarm with non-existent level
	_, _, err = PrewarmBinary(f, stat.Size(), []string{"v4"}, cacheDir)
	assert.Error(t, err, "expected error when prewarming non-existent level v4")

	// 5. Prewarm with auto-resolved cacheDir (empty string)
	t.Setenv(format.EnvCacheDir, filepath.Join(tempDir, "auto_cache"))
	_, _, err = PrewarmBinary(f, stat.Size(), []string{"v1"}, "")
	require.NoError(t, err, "PrewarmBinary with empty cacheDir failed")
	t.Setenv(format.EnvCacheDir, "")

	// 6. PrewarmVariant missing SHA256 error
	badEntry := &format.VariantEntry{Level: "v1", SHA256: ""}
	_, _, _, err = PrewarmVariant(f, badEntry, cacheDir)
	assert.Error(t, err, "expected error for missing SHA256")

	// 7. PrewarmVariant bad cache directory error
	blocker := filepath.Join(tempDir, "blocker")
	_ = os.WriteFile(blocker, []byte("x"), 0o600)
	_, _, _, err = PrewarmVariant(f, &idx.Variants[0], filepath.Join(blocker, "sub"))
	assert.Error(t, err, "expected error for unwritable cache directory")

	// 8. PrewarmVariant with bad compression payload
	corruptEntry := &format.VariantEntry{
		Level:            "v1",
		Offset:           0,
		CompressedSize:   10,
		UncompressedSize: 100,
		SHA256:           "0123456789abcdef",
	}
	_, _, _, err = PrewarmVariant(f, corruptEntry, cacheDir)
	assert.Error(t, err, "expected error decompressing corrupt entry")

	// 9. PrewarmVariant size mismatch
	sizeMismatchEntry := &format.VariantEntry{
		Level:            "v1",
		Offset:           idx.Variants[0].Offset,
		CompressedSize:   idx.Variants[0].CompressedSize,
		UncompressedSize: idx.Variants[0].UncompressedSize + 10,
		SHA256:           idx.Variants[0].SHA256,
	}
	_, _, _, err = PrewarmVariant(f, sizeMismatchEntry, cacheDir)
	assert.Error(t, err, "expected error for size mismatch")

	// 10. PrewarmVariant hash mismatch
	hashMismatchEntry := &format.VariantEntry{
		Level:            "v1",
		Offset:           idx.Variants[0].Offset,
		CompressedSize:   idx.Variants[0].CompressedSize,
		UncompressedSize: idx.Variants[0].UncompressedSize,
		SHA256:           "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
	}
	_, _, _, err = PrewarmVariant(f, hashMismatchEntry, cacheDir)
	assert.Error(t, err, "expected error for hash mismatch")
}

//revive:disable-next-line:cyclomatic Keep successive missing, mixed, valid and corrupted cache states visible in one lifecycle.
func TestVerifyCacheVariantAndBinary(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-payload"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	v1Content := []byte("v1-binary-content-for-cache-verify")
	_ = os.WriteFile(v1Path, v1Content, 0o755)

	v3Path := filepath.Join(tempDir, "v3")
	v3Content := []byte("v3-binary-content-for-cache-verify-avx2")
	_ = os.WriteFile(v3Path, v3Content, 0o755)

	fatPath := filepath.Join(tempDir, "fat_verify.bin")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "verify-cache-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Variants: map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		},
	}

	idx, err := Pack(opts)
	require.NoError(t, err, "Pack failed")

	f, err := os.Open(fatPath)
	require.NoError(t, err, "Open failed")
	defer func() { _ = f.Close() }()

	stat, err := f.Stat()
	require.NoError(t, err, "Stat failed")

	cacheDir := filepath.Join(tempDir, "cache_verify_dir")

	// 1. Clean cache: VerifyCacheBinary should report missing for all variants
	_, missingResults, err := VerifyCacheBinary(f, stat.Size(), nil, cacheDir)
	require.NoError(t, err, "VerifyCacheBinary failed on clean cache")
	if len(missingResults) != 2 {
		t.Fatalf("expected 2 results, got %d", len(missingResults))
	}
	for _, r := range missingResults {
		if r.Valid || r.Status != format.PrewarmStatusMissing {
			t.Errorf("expected status 'missing' and valid=false for clean cache, got %+v", r)
		}
	}

	// 2. Prewarm v1 and verify: v1 should be valid, v3 should be missing
	_, _, err = PrewarmBinary(f, stat.Size(), []string{"v1"}, cacheDir)
	require.NoError(t, err, "prewarming v1 failed")

	_, mixedResults, err := VerifyCacheBinary(f, stat.Size(), nil, cacheDir)
	require.NoError(t, err, "VerifyCacheBinary failed on mixed cache")
	for _, r := range mixedResults {
		switch r.Level {
		case "v1":
			if !r.Valid || r.Status != format.PrewarmStatusValid {
				t.Errorf("expected v1 to be valid, got %+v", r)
			}
		case "v3":
			if r.Valid || r.Status != format.PrewarmStatusMissing {
				t.Errorf("expected v3 to be missing, got %+v", r)
			}
		}
	}

	// 3. Prewarm all variants: both v1 and v3 should be valid
	_, _, err = PrewarmBinary(f, stat.Size(), nil, cacheDir)
	require.NoError(t, err, "prewarming all failed")

	_, allValidResults, err := VerifyCacheBinary(f, stat.Size(), nil, cacheDir)
	require.NoError(t, err, "VerifyCacheBinary failed on fully populated cache")
	for _, r := range allValidResults {
		if !r.Valid || r.Status != format.PrewarmStatusValid {
			t.Errorf("expected variant %s to be valid, got %+v", r.Level, r)
		}
	}

	// 4. Corrupt size of v1 (truncate to 5 bytes)
	v1Entry, _ := idx.FindVariant("v1")
	v1CachedFile := filepath.Join(cacheDir, v1Entry.SHA256)
	_ = os.WriteFile(v1CachedFile, []byte("short"), 0o755)

	resTrunc := VerifyCacheVariant(v1Entry, cacheDir)
	if resTrunc.Valid || resTrunc.Status != format.PrewarmStatusCorrupted {
		t.Errorf("expected status 'corrupted' for truncated cache entry, got %+v", resTrunc)
	}

	// 5. Corrupt content of v3 (same size, wrong SHA-256 hash)
	v3Entry, _ := idx.FindVariant("v3")
	v3CachedFile := filepath.Join(cacheDir, v3Entry.SHA256)
	corruptBytes := make([]byte, v3Entry.UncompressedSize)
	for i := range corruptBytes {
		corruptBytes[i] = 'X'
	}
	_ = os.WriteFile(v3CachedFile, corruptBytes, 0o755)

	resCorruptHash := VerifyCacheVariant(v3Entry, cacheDir)
	if resCorruptHash.Valid || resCorruptHash.Status != format.PrewarmStatusCorrupted {
		t.Errorf("expected status 'corrupted' for hash mismatch cache entry, got %+v", resCorruptHash)
	}

	// 6. VerifyCacheBinary with specific nonexistent variant level
	_, _, err = VerifyCacheBinary(f, stat.Size(), []string{"v99"}, cacheDir)
	assert.Error(t, err, "expected error for nonexistent variant level v99")

	// 7. VerifyCacheBinary with empty cacheDir (uses resolved default)
	t.Setenv(format.EnvCacheDir, cacheDir)
	_, _, err = VerifyCacheBinary(f, stat.Size(), []string{"v1"}, "")
	assert.NoError(t, err, "expected success with auto-resolved cacheDir")
	t.Setenv(format.EnvCacheDir, "")

	// 8. VerifyCacheVariant with invalid cacheDir
	resBadDir := VerifyCacheVariant(v1Entry, filepath.Join(tempDir, "nonexistent_parent", "sub"))
	if resBadDir.Valid || resBadDir.Status != format.PrewarmStatusMissing {
		t.Errorf("expected missing status for nonexistent cache directory: %+v", resBadDir)
	}

	// 9. VerifyCacheVariant unreadable file (open error)
	_ = os.Chmod(v1CachedFile, 0o000)
	defer func() { _ = os.Chmod(v1CachedFile, 0o755) }()
	resUnreadable := VerifyCacheVariant(v1Entry, cacheDir)
	if os.Getuid() != 0 { // Skip permission check if running as root in container
		if resUnreadable.Valid || resUnreadable.Status != format.PrewarmStatusCorrupted {
			t.Errorf("expected corrupted status for unreadable file: %+v", resUnreadable)
		}
	}

	// 10. VerifyCacheVariant and VerifyCacheBinary when cache resolution fails
	t.Setenv("XDG_CACHE_HOME", "/dev/null/forbidden_primary")
	t.Setenv("TMPDIR", "/dev/null/forbidden_secondary")
	resResolveErr := VerifyCacheVariant(v1Entry, "")
	if resResolveErr.Valid || resResolveErr.Status != format.PrewarmStatusMissing {
		t.Errorf("expected missing status when cache resolution fails: %+v", resResolveErr)
	}

	_, _, err = VerifyCacheBinary(f, stat.Size(), []string{"v1"}, "")
	assert.Error(t, err, "expected error from VerifyCacheBinary when cache resolution fails")
	t.Setenv("XDG_CACHE_HOME", "")
	t.Setenv("TMPDIR", "")
}

func TestMultiCodecPackagingAndVerification(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "microfat-stub")
	stubContent := []byte("#!/bin/sh\necho Stub Launcher\n")
	require.NoError(t, os.WriteFile(stubPath, stubContent, 0o755), "failed to write stub")

	// v1: tiny payload (100KB) -> under ProfileLatency should auto-promote to none
	v1Path := filepath.Join(tempDir, "bin-v1")
	v1Content := make([]byte, 100*1024)
	for i := range v1Content {
		v1Content[i] = byte(i % 256)
	}
	_ = os.WriteFile(v1Path, v1Content, 0o755)

	// v3: large payload (600KB) -> under ProfileLatency defaults to lz4
	v3Path := filepath.Join(tempDir, "bin-v3")
	v3Content := make([]byte, 600*1024)
	for i := range v3Content {
		v3Content[i] = byte((i % 256) ^ (i / 1024))
	}
	_ = os.WriteFile(v3Path, v3Content, 0o755)

	// v4: 200KB payload with explicit per-variant zstd:best
	v4Path := filepath.Join(tempDir, "bin-v4")
	v4Content := make([]byte, 200*1024)
	for i := range v4Content {
		v4Content[i] = byte((i * 7) % 256)
	}
	_ = os.WriteFile(v4Path, v4Content, 0o755)

	fatBinaryPath := filepath.Join(tempDir, "multi-codec-fat")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatBinaryPath,
		AppName:           "multi-codec-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Profile:           "latency",
		VariantCompression: map[string]VariantCompressionOptions{
			"v4": {
				Compression: codec.AlgorithmZstd,
				Level:       "best",
			},
		},
		Variants: map[string]string{
			"v1": v1Path,
			"v3": v3Path,
			"v4": v4Path,
		},
	}

	idx, err := Pack(opts)
	require.NoError(t, err, "Pack failed")

	v1Entry, _ := idx.FindVariant("v1")
	if v1Entry.Compression != codec.AlgorithmNone {
		t.Errorf("expected v1 to auto-promote to 'none', got %q", v1Entry.Compression)
	}

	v3Entry, _ := idx.FindVariant("v3")
	if v3Entry.Compression != "lz4" {
		t.Errorf("expected v3 to default to 'lz4', got %q", v3Entry.Compression)
	}

	v4Entry, _ := idx.FindVariant("v4")
	if v4Entry.Compression != codec.AlgorithmZstd {
		t.Errorf("expected v4 to override to 'zstd', got %q", v4Entry.Compression)
	}

	// Verify the binary
	f, err := os.Open(fatBinaryPath)
	require.NoError(t, err, "failed to open fat binary")
	defer func() { _ = f.Close() }()

	stat, _ := f.Stat()
	_, results, err := VerifyBinary(f, stat.Size())
	require.NoError(t, err, "VerifyBinary failed")
	for _, r := range results {
		if !r.Valid {
			t.Errorf("variant %s verification failed: %v", r.Level, r.Error)
		}
	}

	// Prewarm all variants
	cacheDir := filepath.Join(tempDir, "cache")
	_, prewarmResults, err := PrewarmBinary(f, stat.Size(), nil, cacheDir)
	require.NoError(t, err, "PrewarmBinary failed")
	if len(prewarmResults) != 3 {
		t.Fatalf("expected 3 prewarm results, got %d", len(prewarmResults))
	}
	for _, pr := range prewarmResults {
		if !pr.Valid {
			t.Errorf("prewarm invalid for %s: %s", pr.Level, pr.Error)
		}
	}

	// Trim binary to v3 (lz4)
	trimmedPath := filepath.Join(tempDir, "trimmed-v3")
	trimmedFile, _ := os.Create(trimmedPath)
	trimmedIdx, err := TrimBinary(f, stat.Size(), "v3", trimmedFile)
	_ = trimmedFile.Close()
	require.NoError(t, err, "TrimBinary failed")
	if len(trimmedIdx.Variants) != 1 || trimmedIdx.Variants[0].Compression != "lz4" {
		t.Errorf("trimmed variant compression mismatch: %+v", trimmedIdx.Variants)
	}

	// Test Pack with invalid profile
	badProfileOpts := opts
	badProfileOpts.Profile = "invalid_profile"
	badProfileOpts.OutputPath = filepath.Join(tempDir, "bad-profile-out")
	if _, err := Pack(badProfileOpts); err == nil {
		t.Errorf("expected error packing with invalid profile")
	}

	// Test VerifyBinary with unknown compression algorithm
	idxUnknownCodec := &format.Index{
		Version:     format.FormatVersionCurrent,
		TargetArch:  testArchAMD64,
		CreatedUnix: 1000,
		Variants: []format.VariantEntry{
			{
				Level:            "v1",
				Offset:           0,
				CompressedSize:   10,
				UncompressedSize: 10,
				SHA256:           testValidSHA256,
				Compression:      "nonexistent_codec",
			},
		},
	}
	var bufUnknown bytes.Buffer
	_, _ = bufUnknown.Write(make([]byte, 10))
	_, _ = format.WriteIndexAndTrailer(&bufUnknown, idxUnknownCodec, 10)
	_, resUnknown, _ := VerifyBinary(bytes.NewReader(bufUnknown.Bytes()), int64(bufUnknown.Len()))
	if len(resUnknown) != 1 || resUnknown[0].Valid || resUnknown[0].Error == nil {
		t.Errorf("expected error on unknown codec in VerifyBinary: %+v", resUnknown)
	}

	// Test PrewarmVariant with unknown compression algorithm
	entryUnknown := &format.VariantEntry{
		Level:            "v1",
		Offset:           0,
		CompressedSize:   10,
		UncompressedSize: 10,
		SHA256:           testValidSHA256,
		Compression:      "nonexistent_codec",
	}
	if _, _, _, err := PrewarmVariant(bytes.NewReader(make([]byte, 10)), entryUnknown, cacheDir); err == nil {
		t.Errorf("expected error in PrewarmVariant with unknown codec")
	}

	// Test PrewarmVariant with decompression error
	entryCorrupted := &format.VariantEntry{
		Level:            "v1",
		Offset:           0,
		CompressedSize:   10,
		UncompressedSize: 10,
		SHA256:           "1111111111111111111111111111111111111111111111111111111111111111",
		Compression:      "lz4",
	}
	if _, _, _, err := PrewarmVariant(bytes.NewReader([]byte("not-valid-lz4-bytes")), entryCorrupted, cacheDir); err == nil {
		t.Errorf("expected error in PrewarmVariant with corrupted lz4 payload")
	}

	// Test PrewarmVariant with size mismatch (none codec with wrong size)
	entrySizeMismatch := &format.VariantEntry{
		Level:            "v1",
		Offset:           0,
		CompressedSize:   5,
		UncompressedSize: 10,
		SHA256:           "1111111111111111111111111111111111111111111111111111111111111111",
		Compression:      "none",
	}
	if _, _, _, err := PrewarmVariant(bytes.NewReader([]byte("12345")), entrySizeMismatch, cacheDir); err == nil {
		t.Errorf("expected error in PrewarmVariant with size mismatch")
	}

	// Test PrewarmVariant with hash mismatch (none codec with wrong hash)
	entryHashMismatch := &format.VariantEntry{
		Level:            "v1",
		Offset:           0,
		CompressedSize:   5,
		UncompressedSize: 5,
		SHA256:           "0000000000000000000000000000000000000000000000000000000000000000",
		Compression:      "none",
	}
	if _, _, _, err := PrewarmVariant(bytes.NewReader([]byte("12345")), entryHashMismatch, cacheDir); err == nil {
		t.Errorf("expected error in PrewarmVariant with hash mismatch")
	}
}

func TestPackProfileOnlyArtifactCompression(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "stub")
	require.NoError(t, os.WriteFile(stubPath, []byte("#!/bin/sh\necho Stub Launcher\n"), 0o755))

	const (
		subThresholdSize    = 100 * 1024
		superThresholdSize  = 600 * 1024
		overridePayloadSize = 200 * 1024
	)

	// v1: tiny payload (100KB < 512KB) -> auto-promotes to "none" under ProfileLatency
	v1Path := filepath.Join(tempDir, "bin-v1")
	v1Content := make([]byte, subThresholdSize)
	for i := range v1Content {
		v1Content[i] = byte(i % 256)
	}
	require.NoError(t, os.WriteFile(v1Path, v1Content, 0o755))

	// v3: large payload (600KB >= 512KB) -> defaults to "lz4" under ProfileLatency
	v3Path := filepath.Join(tempDir, "bin-v3")
	v3Content := make([]byte, superThresholdSize)
	for i := range v3Content {
		v3Content[i] = byte((i % 256) ^ (i / 1024))
	}
	require.NoError(t, os.WriteFile(v3Path, v3Content, 0o755))

	// v4: payload with explicit variant compression override (zstd:best)
	v4Path := filepath.Join(tempDir, "bin-v4")
	v4Content := make([]byte, overridePayloadSize)
	for i := range v4Content {
		v4Content[i] = byte((i * 7) % 256)
	}
	require.NoError(t, os.WriteFile(v4Path, v4Content, 0o755))

	t.Run("ProfileLatencyWithOmittedAlgorithm", func(t *testing.T) {
		t.Parallel()
		outFat := filepath.Join(t.TempDir(), "fat-latency.bin")
		opts := DefaultOptions()
		opts.StubPath = stubPath
		opts.OutputPath = outFat
		opts.AppName = "latency-app"
		opts.SkipELFValidation = true
		opts.Profile = codec.ProfileLatency
		opts.Variants = map[string]string{
			"v1": v1Path,
			"v3": v3Path,
			"v4": v4Path,
		}
		opts.VariantCompression = map[string]VariantCompressionOptions{
			"v4": {
				Compression: codec.AlgorithmZstd,
				Level:       "best",
			},
		}

		idx, err := Pack(opts)
		require.NoError(t, err)

		v1Entry, _ := idx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmNone, v1Entry.Compression, "sub-512KiB under latency profile must resolve to none")
		v3Entry, _ := idx.FindVariant("v3")
		require.Equal(t, "lz4", v3Entry.Compression, ">=512KiB under latency profile must resolve to lz4")
		v4Entry, _ := idx.FindVariant("v4")
		require.Equal(t, codec.AlgorithmZstd, v4Entry.Compression, "explicit variant override must retain zstd")

		f, err := os.Open(outFat)
		require.NoError(t, err)
		defer func() { _ = f.Close() }()

		stat, err := f.Stat()
		require.NoError(t, err)

		storedIdx, err := format.ReadTrailerAndIndex(f, stat.Size())
		require.NoError(t, err)

		diskV1, _ := storedIdx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmNone, diskV1.Compression)
		require.Equal(t, int64(subThresholdSize), diskV1.UncompressedSize)
		require.Equal(t, int64(subThresholdSize), diskV1.CompressedSize)

		diskV3, _ := storedIdx.FindVariant("v3")
		require.Equal(t, "lz4", diskV3.Compression)

		diskV4, _ := storedIdx.FindVariant("v4")
		require.Equal(t, codec.AlgorithmZstd, diskV4.Compression)

		_, results, err := VerifyBinary(f, stat.Size())
		require.NoError(t, err)
		for _, r := range results {
			require.True(t, r.Valid, "variant %s must be valid: %v", r.Level, r.Error)
		}
	})

	t.Run("ProfileSizeWithOmittedAlgorithm", func(t *testing.T) {
		t.Parallel()
		outFat := filepath.Join(t.TempDir(), "fat-size.bin")
		opts := DefaultOptions()
		opts.StubPath = stubPath
		opts.OutputPath = outFat
		opts.AppName = "size-app"
		opts.SkipELFValidation = true
		opts.Profile = codec.ProfileSize
		opts.Variants = map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		}

		idx, err := Pack(opts)
		require.NoError(t, err)

		v1Entry, _ := idx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmZstd, v1Entry.Compression)
		v3Entry, _ := idx.FindVariant("v3")
		require.Equal(t, codec.AlgorithmZstd, v3Entry.Compression)

		f, err := os.Open(outFat)
		require.NoError(t, err)
		defer func() { _ = f.Close() }()

		stat, err := f.Stat()
		require.NoError(t, err)

		storedIdx, err := format.ReadTrailerAndIndex(f, stat.Size())
		require.NoError(t, err)
		diskV1, _ := storedIdx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmZstd, diskV1.Compression)
		diskV3, _ := storedIdx.FindVariant("v3")
		require.Equal(t, codec.AlgorithmZstd, diskV3.Compression)

		_, results, err := VerifyBinary(f, stat.Size())
		require.NoError(t, err)
		for _, r := range results {
			require.True(t, r.Valid)
		}
	})

	t.Run("ProfileBalancedWithOmittedAlgorithm", func(t *testing.T) {
		t.Parallel()
		outFat := filepath.Join(t.TempDir(), "fat-balanced.bin")
		opts := DefaultOptions()
		opts.StubPath = stubPath
		opts.OutputPath = outFat
		opts.AppName = "balanced-app"
		opts.SkipELFValidation = true
		opts.Profile = codec.ProfileBalanced
		opts.Variants = map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		}

		idx, err := Pack(opts)
		require.NoError(t, err)

		v1Entry, _ := idx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmZstd, v1Entry.Compression)
		v3Entry, _ := idx.FindVariant("v3")
		require.Equal(t, codec.AlgorithmZstd, v3Entry.Compression)

		f, err := os.Open(outFat)
		require.NoError(t, err)
		defer func() { _ = f.Close() }()

		stat, err := f.Stat()
		require.NoError(t, err)

		storedIdx, err := format.ReadTrailerAndIndex(f, stat.Size())
		require.NoError(t, err)
		diskV1, _ := storedIdx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmZstd, diskV1.Compression)

		_, results, err := VerifyBinary(f, stat.Size())
		require.NoError(t, err)
		for _, r := range results {
			require.True(t, r.Valid)
		}
	})

	t.Run("ExplicitZstdOverridesLatencyProfile", func(t *testing.T) {
		t.Parallel()
		outFat := filepath.Join(t.TempDir(), "fat-explicit-zstd.bin")
		opts := DefaultOptions()
		opts.StubPath = stubPath
		opts.OutputPath = outFat
		opts.AppName = "explicit-zstd-app"
		opts.SkipELFValidation = true
		opts.Profile = codec.ProfileLatency
		opts.Compression = codec.AlgorithmZstd
		opts.Variants = map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		}

		idx, err := Pack(opts)
		require.NoError(t, err)

		v1Entry, _ := idx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmZstd, v1Entry.Compression, "explicit root zstd must not be erased by latency profile")
		v3Entry, _ := idx.FindVariant("v3")
		require.Equal(t, codec.AlgorithmZstd, v3Entry.Compression)

		f, err := os.Open(outFat)
		require.NoError(t, err)
		defer func() { _ = f.Close() }()

		stat, err := f.Stat()
		require.NoError(t, err)

		storedIdx, err := format.ReadTrailerAndIndex(f, stat.Size())
		require.NoError(t, err)
		diskV1, _ := storedIdx.FindVariant("v1")
		require.Equal(t, codec.AlgorithmZstd, diskV1.Compression)
		diskV3, _ := storedIdx.FindVariant("v3")
		require.Equal(t, codec.AlgorithmZstd, diskV3.Compression)

		_, results, err := VerifyBinary(f, stat.Size())
		require.NoError(t, err)
		for _, r := range results {
			require.True(t, r.Valid)
		}
	})
}

func createBenchmarkFixture(b *testing.B, variantCount int) (stubPath string, variants map[string]string, tempDir string) {
	b.Helper()
	tempDir = b.TempDir()
	stubPath = filepath.Join(tempDir, "stub")
	if err := os.WriteFile(stubPath, []byte("#!/bin/sh\necho Stub\n"), 0o755); err != nil {
		b.Fatalf("failed to create stub: %v", err)
	}

	variants = make(map[string]string, variantCount)
	for i := 1; i <= variantCount; i++ {
		lvl := "v" + strconv.Itoa(i)
		p := filepath.Join(tempDir, "bin-"+lvl)
		payload := bytes.Repeat([]byte("benchmark-payload-data-line-"+lvl+"\n"), 256)
		if err := os.WriteFile(p, payload, 0o755); err != nil {
			b.Fatalf("failed to create variant %s: %v", lvl, err)
		}
		variants[lvl] = p
	}
	return stubPath, variants, tempDir
}

func BenchmarkPack(b *testing.B) {
	for _, count := range []int{1, 4} {
		b.Run(strconv.Itoa(count)+"Variants", func(b *testing.B) {
			stubPath, variants, tempDir := createBenchmarkFixture(b, count)
			b.ReportAllocs()
			var i int
			for b.Loop() {
				outPath := filepath.Join(tempDir, "out-"+strconv.Itoa(i))
				opts := Options{
					StubPath:          stubPath,
					OutputPath:        outPath,
					AppName:           "bench-app",
					TargetOS:          testOSLinux,
					TargetArch:        testArchAMD64,
					SkipELFValidation: true,
					CompressionLevel:  testCompressionFastest,
					Variants:          variants,
				}
				if _, err := Pack(opts); err != nil {
					b.Fatalf("Pack failed: %v", err)
				}
				_ = os.Remove(outPath)
				i++
			}
		})
	}
}

func BenchmarkVerifyBinary(b *testing.B) {
	stubPath, variants, tempDir := createBenchmarkFixture(b, 4)
	fatPath := filepath.Join(tempDir, "fat-verify")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "bench-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		CompressionLevel:  testCompressionFastest,
		Variants:          variants,
	}
	if _, err := Pack(opts); err != nil {
		b.Fatalf("Pack fixture failed: %v", err)
	}

	data, err := os.ReadFile(fatPath)
	if err != nil {
		b.Fatalf("reading fat fixture: %v", err)
	}
	reader := bytes.NewReader(data)
	totalSize := int64(len(data))

	b.ReportAllocs()
	for b.Loop() {
		_, results, err := VerifyBinary(reader, totalSize)
		if err != nil || len(results) != 4 {
			b.Fatalf("VerifyBinary failed: %v", err)
		}
	}
}

func BenchmarkTrimBinary(b *testing.B) {
	stubPath, variants, tempDir := createBenchmarkFixture(b, 4)
	fatPath := filepath.Join(tempDir, "fat-trim")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "bench-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		CompressionLevel:  testCompressionFastest,
		Variants:          variants,
	}
	if _, err := Pack(opts); err != nil {
		b.Fatalf("Pack fixture failed: %v", err)
	}

	data, err := os.ReadFile(fatPath)
	if err != nil {
		b.Fatalf("reading fat fixture: %v", err)
	}
	reader := bytes.NewReader(data)
	totalSize := int64(len(data))

	b.ReportAllocs()
	for b.Loop() {
		_, err := TrimBinary(reader, totalSize, "v3", io.Discard)
		if err != nil {
			b.Fatalf("TrimBinary failed: %v", err)
		}
	}
}

func BenchmarkPrewarmBinary(b *testing.B) {
	stubPath, variants, tempDir := createBenchmarkFixture(b, 4)
	fatPath := filepath.Join(tempDir, "fat-prewarm")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "bench-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		CompressionLevel:  testCompressionFastest,
		Variants:          variants,
	}
	if _, err := Pack(opts); err != nil {
		b.Fatalf("Pack fixture failed: %v", err)
	}

	data, err := os.ReadFile(fatPath)
	if err != nil {
		b.Fatalf("reading fat fixture: %v", err)
	}
	reader := bytes.NewReader(data)
	totalSize := int64(len(data))

	cacheDir := filepath.Join(tempDir, "cache")
	// Prewarm once to populate cache
	if _, _, err := PrewarmBinary(reader, totalSize, nil, cacheDir); err != nil {
		b.Fatalf("prewarming failed: %v", err)
	}

	b.Run("CachedHit", func(b *testing.B) {
		b.ReportAllocs()
		for b.Loop() {
			_, results, err := PrewarmBinary(reader, totalSize, nil, cacheDir)
			if err != nil || len(results) != 4 {
				b.Fatalf("PrewarmBinary failed: %v", err)
			}
		}
	})

	b.Run("VerifyCacheBinary", func(b *testing.B) {
		b.ReportAllocs()
		for b.Loop() {
			_, results, err := VerifyCacheBinary(reader, totalSize, nil, cacheDir)
			if err != nil || len(results) != 4 {
				b.Fatalf("VerifyCacheBinary failed: %v", err)
			}
		}
	})
}

func TestDictionaryPackingAndVerification(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("DUMMY_STUB_HEADER_DATA_1234567890"), 0o755)

	// Create 4 variants with substantial shared content (like real Go ELF binaries)
	varPaths := make(map[string]string)
	for _, lvl := range []string{"v1", "v2", "v3", "v4"} {
		p := filepath.Join(tempDir, "app_"+lvl)
		var buf bytes.Buffer
		for i := range 1200 {
			buf.WriteString(fmt.Sprintf("runtime_metadata_symbol_entry_%04d_hash_%x\n", i, (i*43)^0xA5A5A5A5))
		}
		buf.WriteString(fmt.Sprintf("variant_specific_code_segment_%s_optimization_pass\n", lvl))
		_ = os.WriteFile(p, buf.Bytes(), 0o755)
		varPaths[lvl] = p
	}

	fatWithoutDict := filepath.Join(tempDir, "fat_no_dict")
	optsNoDict := Options{
		StubPath:          stubPath,
		OutputPath:        fatWithoutDict,
		AppName:           "dict-test-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		Variants:          varPaths,
		EnableDict:        false,
		SkipELFValidation: true,
	}
	idxNoDict, err := Pack(optsNoDict)
	require.NoError(t, err, "Pack without dict failed")
	if idxNoDict.DictionarySize != 0 {
		t.Errorf("expected 0 DictionarySize for no-dict pack, got %d", idxNoDict.DictionarySize)
	}
	statNoDict, err := os.Stat(fatWithoutDict)
	require.NoError(t, err, "stat no dict failed")

	fatWithDict := filepath.Join(tempDir, "fat_with_dict")
	optsWithDict := Options{
		StubPath:          stubPath,
		OutputPath:        fatWithDict,
		AppName:           "dict-test-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		Variants:          varPaths,
		EnableDict:        true,
		DictSize:          32 * 1024,
		SkipELFValidation: true,
	}
	idxWithDict, err := Pack(optsWithDict)
	require.NoError(t, err, "Pack with dict failed")
	statWithDict, err := os.Stat(fatWithDict)
	require.NoError(t, err, "stat with dict failed")

	if idxWithDict.DictionarySize <= 0 {
		t.Errorf("expected DictionarySize > 0, got %d", idxWithDict.DictionarySize)
	}
	if idxWithDict.DictionaryOffset <= 0 {
		t.Errorf("expected DictionaryOffset > 0, got %d", idxWithDict.DictionaryOffset)
	}
	if idxWithDict.DictionarySHA256 == "" {
		t.Errorf("expected non-empty DictionarySHA256")
	}

	// Verify size reduction
	t.Logf("Fat without dict: %d bytes | Fat with dict: %d bytes (savings: %.1f%%)",
		statNoDict.Size(), statWithDict.Size(),
		(1.0-float64(statWithDict.Size())/float64(statNoDict.Size()))*100)

	// Verify binary integrity
	fDict, err := os.Open(fatWithDict)
	require.NoError(t, err, "open fatWithDict")
	defer func() { _ = fDict.Close() }()

	vIdx, results, err := VerifyBinary(fDict, statWithDict.Size())
	require.NoError(t, err, "VerifyBinary failed")
	if len(results) != 4 {
		t.Fatalf("expected 4 results, got %d", len(results))
	}
	for _, r := range results {
		if !r.Valid || r.Error != nil {
			t.Errorf("expected valid verification for %s: %v", r.Level, r.Error)
		}
	}
	if vIdx.DictionarySize != idxWithDict.DictionarySize {
		t.Errorf("VerifyBinary returned wrong dictionary size")
	}

	// Verify TrimBinary on dictionary-backed fat binary
	trimmedPath := filepath.Join(tempDir, "trimmed_v3")
	trimmedFile, err := os.Create(trimmedPath)
	require.NoError(t, err, "create trimmed file")
	trimIdx, err := TrimBinary(fDict, statWithDict.Size(), "v3", trimmedFile)
	_ = trimmedFile.Close()
	require.NoError(t, err, "TrimBinary on dict binary failed")
	if trimIdx.DictionarySize != idxWithDict.DictionarySize {
		t.Errorf("Trimmed binary lost dictionary size: %d", trimIdx.DictionarySize)
	}

	trimmedOpen, err := os.Open(trimmedPath)
	require.NoError(t, err, "open trimmed binary")
	defer func() { _ = trimmedOpen.Close() }()
	trimStat, _ := trimmedOpen.Stat()
	_, trimResults, err := VerifyBinary(trimmedOpen, trimStat.Size())
	if err != nil || len(trimResults) != 1 || !trimResults[0].Valid {
		t.Fatalf("verification of trimmed dict binary failed: %v (results: %v)", err, trimResults)
	}

	// Verify PrewarmBinary on dictionary-backed fat binary
	cacheDir := filepath.Join(tempDir, "prewarm_cache")
	_, prewarmRes, err := PrewarmBinary(fDict, statWithDict.Size(), []string{"v1", "v4"}, cacheDir)
	require.NoError(t, err, "PrewarmBinary failed on dict binary")
	if len(prewarmRes) != 2 {
		t.Fatalf("expected 2 prewarm results, got %d", len(prewarmRes))
	}
	for _, pr := range prewarmRes {
		if !pr.Valid {
			t.Errorf("prewarm invalid for %s: %s", pr.Level, pr.Error)
		}
	}
}

func TestDictionaryCorruptedVerification(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("DUMMY_STUB_HEADER_DATA_1234567890"), 0o755)

	varPaths := make(map[string]string)
	for _, lvl := range []string{"v1", "v2"} {
		p := filepath.Join(tempDir, "app_"+lvl)
		var buf bytes.Buffer
		for i := range 1200 {
			buf.WriteString(fmt.Sprintf("sample_payload_for_corruption_test_entry_%04d_hash_%x\n", i, (i*37)^0x5A5A5A5A))
		}
		buf.WriteString(fmt.Sprintf("level_specific_data_%s\n", lvl))
		_ = os.WriteFile(p, buf.Bytes(), 0o755)
		varPaths[lvl] = p
	}

	fatPath := filepath.Join(tempDir, "fat_dict")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "corrupt-test",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		Variants:          varPaths,
		EnableDict:        true,
		SkipELFValidation: true,
	}
	idx, err := Pack(opts)
	if err != nil {
		t.Fatalf("Pack failed: %v", err)
	}

	data, err := os.ReadFile(fatPath)
	if err != nil {
		t.Fatalf("reading fat binary: %v", err)
	}

	// Tamper with dictionary bytes
	tamperedData := make([]byte, len(data))
	copy(tamperedData, data)
	if idx.DictionarySize > 0 {
		tamperedData[idx.DictionaryOffset+10] ^= 0xFF
	}

	tamperedReader := bytes.NewReader(tamperedData)
	_, _, err = VerifyBinary(tamperedReader, int64(len(tamperedData)))
	if err == nil {
		t.Fatalf("expected error when dictionary is corrupted")
	}

	// Also verify PrewarmBinary fails on corrupted dictionary
	cacheDir := filepath.Join(tempDir, "cache_corrupt")
	_, _, err = PrewarmBinary(tamperedReader, int64(len(tamperedData)), nil, cacheDir)
	if err == nil {
		t.Fatalf("expected PrewarmBinary to fail on corrupted dictionary")
	}
}

func TestSampleVariantPayloadsEdgeCases(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	p1 := filepath.Join(tempDir, "p1")
	p2 := filepath.Join(tempDir, "p2")

	_ = os.WriteFile(p1, make([]byte, 1024), 0o644)
	_ = os.WriteFile(p2, make([]byte, 500*1024), 0o644)

	variants := map[string]string{"v1": p1, "v2": p2}
	samples, err := sampleVariantPayloads(variants, []string{"v1", "v2"})
	if err != nil {
		t.Fatalf("sampleVariantPayloads failed: %v", err)
	}
	if len(samples) == 0 {
		t.Fatalf("expected non-empty samples")
	}

	// Nonexistent file error
	_, err = sampleVariantPayloads(map[string]string{"v1": filepath.Join(tempDir, "missing")}, []string{"v1"})
	if err == nil {
		t.Fatalf("expected error for missing variant file in sampleVariantPayloads")
	}
}

func TestDefaultOptions(t *testing.T) {
	t.Parallel()

	t.Run("DefaultValues", func(t *testing.T) {
		t.Parallel()
		opts := DefaultOptions()

		if opts.FormatVersion != format.FormatVersionCurrent {
			t.Errorf("expected FormatVersion %d, got %d", format.FormatVersionCurrent, opts.FormatVersion)
		}
		if opts.Profile != codec.ProfileBalanced {
			t.Errorf("expected Profile %q, got %q", codec.ProfileBalanced, opts.Profile)
		}
		if opts.Compression != "" {
			t.Errorf("expected Compression to be empty, got %q", opts.Compression)
		}
		if opts.Permissions != defaultFileMode {
			t.Errorf("expected Permissions %o, got %o", defaultFileMode, opts.Permissions)
		}
		if opts.TargetOS != "linux" {
			t.Errorf("expected TargetOS %q, got %q", "linux", opts.TargetOS)
		}
		if opts.TargetArch != microarch.ArchAMD64 {
			t.Errorf("expected TargetArch %q, got %q", microarch.ArchAMD64, opts.TargetArch)
		}
		if opts.Variants == nil {
			t.Fatal("expected Variants map to be initialized non-nil")
		}
		if len(opts.Variants) != 0 {
			t.Errorf("expected empty Variants map, got %d items", len(opts.Variants))
		}
	})

	t.Run("MapIsolation", func(t *testing.T) {
		t.Parallel()
		opts1 := DefaultOptions()
		opts1.Variants["v3"] = "/tmp/fake-v3"

		opts2 := DefaultOptions()
		if len(opts2.Variants) != 0 {
			t.Errorf("expected isolated Variants map in second call, got %d items", len(opts2.Variants))
		}
	})

	t.Run("EndToEndPackWithDefaultOptions", func(t *testing.T) {
		t.Parallel()
		tempDir := t.TempDir()

		stubPath := filepath.Join(tempDir, "stub")
		require.NoError(t, os.WriteFile(stubPath, []byte("#!/bin/sh\necho Stub\n"), 0o755), "failed to write stub")

		v1Path := filepath.Join(tempDir, "bin-v1")
		require.NoError(t, os.WriteFile(v1Path, []byte("#!/bin/sh\necho v1\n"), 0o755), "failed to write v1")

		v3Path := filepath.Join(tempDir, "bin-v3")
		require.NoError(t, os.WriteFile(v3Path, []byte("#!/bin/sh\necho v3\n"), 0o755), "failed to write v3")

		outputPath := filepath.Join(tempDir, "packed.fat")

		opts := DefaultOptions()
		opts.StubPath = stubPath
		opts.OutputPath = outputPath
		opts.AppName = "default-opts-test"
		opts.SkipELFValidation = true
		opts.Variants["v1"] = v1Path
		opts.Variants["v3"] = v3Path

		idx, err := Pack(opts)
		require.NoError(t, err, "Pack with DefaultOptions failed")

		if idx.Version != format.FormatVersionCurrent {
			t.Errorf("expected index version %d, got %d", format.FormatVersionCurrent, idx.Version)
		}
		if len(idx.Variants) != 2 {
			t.Fatalf("expected 2 variants, got %d", len(idx.Variants))
		}

		f, err := os.Open(outputPath)
		require.NoError(t, err, "failed to open generated fat binary")
		defer func() { _ = f.Close() }()

		stat, err := f.Stat()
		require.NoError(t, err, "stat failed")

		if !format.IsFatBinary(f, stat.Size()) {
			t.Error("expected IsFatBinary to be true")
		}

		vIdx, results, err := VerifyBinary(f, stat.Size())
		require.NoError(t, err, "VerifyBinary failed")
		if vIdx.Version != format.FormatVersionCurrent {
			t.Errorf("verified index version mismatch: expected %d, got %d", format.FormatVersionCurrent, vIdx.Version)
		}
		for _, r := range results {
			if !r.Valid {
				t.Errorf("variant %s verification failed: %v", r.Level, r.Error)
			}
		}
	})
}

func TestVerifyCacheVariantCoverage(t *testing.T) {
	t.Parallel()

	// 1. Invalid checksum format
	invalidEntry := &format.VariantEntry{
		Level:            "v1",
		SHA256:           "../../invalid",
		UncompressedSize: 100,
	}
	resInvalid := VerifyCacheVariant(invalidEntry, t.TempDir())
	if resInvalid.Valid || resInvalid.Status != format.PrewarmStatusCorrupted {
		t.Errorf("expected PrewarmStatusCorrupted for invalid checksum, got: %+v", resInvalid)
	}

	// 2. PrewarmVariant with invalid checksum
	_, _, _, prewarmErr := PrewarmVariantWithDict(nil, invalidEntry, t.TempDir(), nil)
	if prewarmErr == nil {
		t.Error("expected error for PrewarmVariantWithDict on invalid checksum, got nil")
	}

	// 3. Size mismatch
	tempDir := t.TempDir()
	validHash := testValidSHA256
	cachedFile := filepath.Join(tempDir, validHash)
	if err := os.WriteFile(cachedFile, []byte("short"), 0o755); err != nil {
		t.Fatalf("failed to write cached file: %v", err)
	}

	entrySizeMismatch := &format.VariantEntry{
		Level:            "v1",
		SHA256:           validHash,
		UncompressedSize: 100,
	}
	resSize := VerifyCacheVariant(entrySizeMismatch, tempDir)
	if resSize.Valid || resSize.Status != format.PrewarmStatusCorrupted {
		t.Errorf("expected PrewarmStatusCorrupted for size mismatch, got: %+v", resSize)
	}

	// 4. Checksum mismatch
	entryHashMismatch := &format.VariantEntry{
		Level:            "v1",
		SHA256:           validHash,
		UncompressedSize: 5,
	}
	resHash := VerifyCacheVariant(entryHashMismatch, tempDir)
	if resHash.Valid || resHash.Status != format.PrewarmStatusCorrupted {
		t.Errorf("expected PrewarmStatusCorrupted for hash mismatch, got: %+v", resHash)
	}
}

func TestPack_OversizedDictionaryGuard(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	payload := bytes.Repeat([]byte{0x00}, 2048)

	// 1. Oversized dictionary index
	oversizedIdx := &format.Index{
		Version:          format.FormatVersion2,
		AppName:          "oversized-dict-test",
		TargetOS:         testOSLinux,
		TargetArch:       testArchAMD64,
		DictionaryOffset: 0,
		DictionarySize:   format.MaxDictionarySize + 1024,
		DictionarySHA256: testValidSHA256,
		Variants: []format.VariantEntry{
			{
				Level:            "v1",
				Compression:      codec.AlgorithmNone,
				Offset:           format.MaxDictionarySize + 2048,
				CompressedSize:   100,
				UncompressedSize: 100,
				SHA256:           testValidSHA256,
			},
		},
	}

	var buf bytes.Buffer
	buf.Write(payload)
	_, err := format.WriteIndexAndTrailer(&buf, oversizedIdx, int64(buf.Len()))
	if err != nil {
		t.Fatalf("WriteIndexAndTrailer failed: %v", err)
	}

	reader := bytes.NewReader(buf.Bytes())
	totalSize := int64(buf.Len())

	// VerifyBinary must fail with ErrInvalidDictionary
	_, _, err = VerifyBinary(reader, totalSize)
	if err == nil || !errors.Is(err, format.ErrInvalidDictionary) {
		t.Fatalf("expected ErrInvalidDictionary in VerifyBinary for oversized dictionary, got %v", err)
	}

	// PrewarmBinary must fail with ErrInvalidDictionary
	_, _, err = PrewarmBinary(reader, totalSize, nil, tmpDir)
	if err == nil || !errors.Is(err, format.ErrInvalidDictionary) {
		t.Fatalf("expected ErrInvalidDictionary in PrewarmBinary for oversized dictionary, got %v", err)
	}
}

func TestVerifyCachedBinary(t *testing.T) {
	tempDir := t.TempDir()

	validContent := []byte("hello-microfat-cached-binary-test-content")
	validSize := int64(len(validContent))
	h := sha256.Sum256(validContent)
	validSHA := hex.EncodeToString(h[:])

	validPath := filepath.Join(tempDir, "valid_file")
	if err := os.WriteFile(validPath, validContent, 0o755); err != nil {
		t.Fatalf("writing valid file: %v", err)
	}

	t.Run("ValidFile_MatchesSizeAndChecksum", func(t *testing.T) {
		if !verifyCachedBinary(validPath, validSize, validSHA) {
			t.Errorf("expected verifyCachedBinary to return true for valid file")
		}
	})

	t.Run("NonexistentFile", func(t *testing.T) {
		if verifyCachedBinary(filepath.Join(tempDir, "nonexistent"), validSize, validSHA) {
			t.Errorf("expected verifyCachedBinary to return false for nonexistent file")
		}
	})

	t.Run("DirectoryPath", func(t *testing.T) {
		if verifyCachedBinary(tempDir, validSize, validSHA) {
			t.Errorf("expected verifyCachedBinary to return false for directory path")
		}
	})

	t.Run("SizeMismatch", func(t *testing.T) {
		if verifyCachedBinary(validPath, validSize+10, validSHA) {
			t.Errorf("expected verifyCachedBinary to return false for size mismatch")
		}
	})

	t.Run("ChecksumMismatch", func(t *testing.T) {
		mismatchedSHA := "0000000000000000000000000000000000000000000000000000000000000000"
		if verifyCachedBinary(validPath, validSize, mismatchedSHA) {
			t.Errorf("expected verifyCachedBinary to return false for checksum mismatch")
		}
	})

	t.Run("UnreadableFile", func(t *testing.T) {
		if os.Geteuid() == 0 {
			t.Skip("skipping unreadable file test as root")
		}
		unreadablePath := filepath.Join(tempDir, "unreadable_file")
		if err := os.WriteFile(unreadablePath, validContent, 0o000); err != nil {
			t.Skip("skipping chmod 0000 test")
		}
		defer func() { _ = os.Chmod(unreadablePath, 0o600) }()
		if verifyCachedBinary(unreadablePath, validSize, validSHA) {
			t.Errorf("expected verifyCachedBinary to return false for unreadable file")
		}
	})

	t.Run("SymlinkRefused", func(t *testing.T) {
		symlinkPath := filepath.Join(tempDir, "symlink_to_valid")
		if err := os.Symlink(validPath, symlinkPath); err != nil {
			t.Fatalf("creating test symlink: %v", err)
		}
		if verifyCachedBinary(symlinkPath, validSize, validSHA) {
			t.Errorf("expected verifyCachedBinary to return false for symlink (O_NOFOLLOW defense)")
		}
	})
}

//revive:disable-next-line:cyclomatic Keep cache recovery, atomic replacement and concurrent-writer outcomes explicit.
func TestPrewarmVariantWithDict_IntegrityAndAtomicReplacement(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-payload-bytes"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	v1Content := []byte("v1-binary-integrity-test-payload-1234567890")
	_ = os.WriteFile(v1Path, v1Content, 0o755)

	fatPath := filepath.Join(tempDir, "fat_integrity.bin")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "integrity-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Variants: map[string]string{
			"v1": v1Path,
		},
	}

	_, err := Pack(opts)
	require.NoError(t, err, "Pack failed")

	f, err := os.Open(fatPath)
	require.NoError(t, err, "Open failed")
	defer func() { _ = f.Close() }()

	stat, err := f.Stat()
	require.NoError(t, err, "Stat failed")

	idx, err := format.ReadTrailerAndIndex(f, stat.Size())
	require.NoError(t, err, "ReadTrailerAndIndex failed")
	if len(idx.Variants) != 1 {
		t.Fatalf("expected 1 variant, got %d", len(idx.Variants))
	}
	entry := &idx.Variants[0]

	cacheDir := filepath.Join(tempDir, "integrity_cache")

	t.Run("CacheHit_Valid", func(t *testing.T) {
		cachedPath, alreadyCached, _, prewarmErr := PrewarmVariantWithDict(f, entry, cacheDir, nil)
		if prewarmErr != nil {
			t.Fatalf("first PrewarmVariantWithDict failed: %v", prewarmErr)
		}
		if alreadyCached {
			t.Errorf("expected alreadyCached=false on initial extraction")
		}

		// Second prewarm should be a verified cache hit
		cachedPath2, alreadyCached2, _, prewarmErr2 := PrewarmVariantWithDict(f, entry, cacheDir, nil)
		if prewarmErr2 != nil {
			t.Fatalf("second PrewarmVariantWithDict failed: %v", prewarmErr2)
		}
		if !alreadyCached2 {
			t.Errorf("expected alreadyCached=true on second prewarm")
		}
		if cachedPath != cachedPath2 {
			t.Errorf("expected cached paths to match: %q != %q", cachedPath, cachedPath2)
		}
	})

	t.Run("CacheHit_CorruptedPayload", func(t *testing.T) {
		cachedFile := filepath.Join(cacheDir, entry.SHA256)
		corruptedBytes := bytes.Repeat([]byte{0xFF}, int(entry.UncompressedSize))
		if writeErr := os.WriteFile(cachedFile, corruptedBytes, format.PrivateExecMode); writeErr != nil {
			t.Fatalf("writing corrupted cache file: %v", writeErr)
		}

		// PrewarmVariantWithDict should detect hash mismatch, re-extract, and atomically replace the file
		cachedPath, alreadyCached, _, prewarmErr := PrewarmVariantWithDict(f, entry, cacheDir, nil)
		if prewarmErr != nil {
			t.Fatalf("PrewarmVariantWithDict recovery failed: %v", prewarmErr)
		}
		if alreadyCached {
			t.Errorf("expected alreadyCached=false on corrupted file recovery")
		}

		fixedData, readErr := os.ReadFile(cachedPath)
		if readErr != nil {
			t.Fatalf("reading recovered cached file: %v", readErr)
		}
		if !bytes.Equal(fixedData, v1Content) {
			t.Errorf("recovered cached content mismatch: expected %q, got %q", v1Content, fixedData)
		}
	})

	t.Run("CacheHit_TruncatedPayload", func(t *testing.T) {
		cachedFile := filepath.Join(cacheDir, entry.SHA256)
		if truncErr := os.Truncate(cachedFile, 5); truncErr != nil {
			t.Fatalf("truncating cache file: %v", truncErr)
		}

		// PrewarmVariantWithDict should detect size mismatch and restore the valid binary
		cachedPath, alreadyCached, _, prewarmErr := PrewarmVariantWithDict(f, entry, cacheDir, nil)
		if prewarmErr != nil {
			t.Fatalf("PrewarmVariantWithDict truncated recovery failed: %v", prewarmErr)
		}
		if alreadyCached {
			t.Errorf("expected alreadyCached=false on truncated file recovery")
		}

		fixedData, readErr := os.ReadFile(cachedPath)
		if readErr != nil {
			t.Fatalf("reading recovered cached file: %v", readErr)
		}
		if !bytes.Equal(fixedData, v1Content) {
			t.Errorf("recovered cached content mismatch: expected %q, got %q", v1Content, fixedData)
		}
	})

	t.Run("DecompressionFailure_PreservesDiskState", func(t *testing.T) {
		corruptedReader := bytes.NewReader([]byte("not-a-valid-payload"))
		corruptedEntry := &format.VariantEntry{
			Level:            "v1",
			Compression:      "zstd",
			Offset:           0,
			CompressedSize:   int64(len("not-a-valid-payload")),
			UncompressedSize: 500,
			SHA256:           entry.SHA256,
		}

		_, _, _, errCorrupt := PrewarmVariantWithDict(corruptedReader, corruptedEntry, cacheDir, nil)
		if errCorrupt == nil {
			t.Fatalf("expected error decompressing invalid payload")
		}

		// Verify no dangling .prewarm-*.tmp files in cacheDir
		entries, dirErr := os.ReadDir(cacheDir)
		if dirErr != nil {
			t.Fatalf("reading cacheDir: %v", dirErr)
		}
		for _, e := range entries {
			if filepath.Ext(e.Name()) == ".tmp" {
				t.Errorf("dangling temporary file found after failed decompression: %s", e.Name())
			}
		}
	})

	t.Run("ConcurrentPrewarmRace", func(t *testing.T) {
		const concurrentWorkers = 20
		var wg sync.WaitGroup
		errs := make(chan error, concurrentWorkers)

		for range concurrentWorkers {
			wg.Go(func() {
				_, _, _, pErr := PrewarmVariantWithDict(f, entry, cacheDir, nil)
				if pErr != nil {
					errs <- pErr
				}
			})
		}

		wg.Wait()
		close(errs)

		for pErr := range errs {
			t.Errorf("concurrent PrewarmVariantWithDict error: %v", pErr)
		}

		cachedFile := filepath.Join(cacheDir, entry.SHA256)
		statFile, statErr := os.Stat(cachedFile)
		if statErr != nil {
			t.Fatalf("stat on concurrent cached file: %v", statErr)
		}
		if statFile.Size() != entry.UncompressedSize {
			t.Errorf("unexpected file size after concurrent race: expected %d, got %d", entry.UncompressedSize, statFile.Size())
		}
	})
}

func TestValidateOptions_NormalizedVariantsAndTiers(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "stub")
	varPath := filepath.Join(tempDir, "var")
	_ = os.WriteFile(stubPath, []byte("stub"), 0o755)
	_ = os.WriteFile(varPath, []byte("var"), 0o755)

	t.Run("Empty variant map returns ErrNoVariantsSpecified", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out1"),
			SkipELFValidation: true,
			Variants:          map[string]string{},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrNoVariantsSpecified) {
			t.Fatalf("expected ErrNoVariantsSpecified, got %v", err)
		}
	})

	t.Run("Empty variant level string returns ErrInvalidVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out2"),
			SkipELFValidation: true,
			Variants: map[string]string{
				"   ": varPath,
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrInvalidVariant) {
			t.Fatalf("expected ErrInvalidVariant for empty level, got %v", err)
		}
	})

	t.Run("Unrecognized variant level for AMD64 returns ErrInvalidVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out3"),
			TargetArch:        testArchAMD64,
			SkipELFValidation: true,
			Variants: map[string]string{
				"v99": varPath,
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrInvalidVariant) {
			t.Fatalf("expected ErrInvalidVariant for v99 on amd64, got %v", err)
		}
	})

	t.Run("ARM64 variant level for AMD64 target returns ErrInvalidVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out4"),
			TargetArch:        testArchAMD64,
			SkipELFValidation: true,
			Variants: map[string]string{
				testLevelV80: varPath,
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrInvalidVariant) {
			t.Fatalf("expected ErrInvalidVariant for v8.0 on amd64, got %v", err)
		}
	})

	t.Run("AMD64 variant level for ARM64 target returns ErrInvalidVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out5"),
			TargetArch:        "arm64",
			SkipELFValidation: true,
			Variants: map[string]string{
				"v3": varPath,
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrInvalidVariant) {
			t.Fatalf("expected ErrInvalidVariant for v3 on arm64, got %v", err)
		}
	})

	t.Run("Duplicate normalized variant aliases return ErrDuplicateVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out6"),
			TargetArch:        testArchAMD64,
			SkipELFValidation: true,
			Variants: map[string]string{
				"v3":             varPath,
				testAliasAMD64v3: varPath,
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrDuplicateVariant) {
			t.Fatalf("expected ErrDuplicateVariant for v3 + amd64_v3, got %v", err)
		}
	})

	t.Run("Duplicate case-insensitive variant aliases return ErrDuplicateVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out7"),
			TargetArch:        testArchAMD64,
			SkipELFValidation: true,
			Variants: map[string]string{
				"v2": varPath,
				"V2": varPath,
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrDuplicateVariant) {
			t.Fatalf("expected ErrDuplicateVariant for v2 + V2, got %v", err)
		}
	})

	t.Run("Duplicate ARM64 normalized aliases return ErrDuplicateVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out8"),
			TargetArch:        "arm64",
			SkipELFValidation: true,
			Variants: map[string]string{
				testLevelV80: varPath,
				"arm64_v8.0": varPath,
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrDuplicateVariant) {
			t.Fatalf("expected ErrDuplicateVariant for v8.0 + arm64_v8.0, got %v", err)
		}
	})

	t.Run("Empty variant compression level returns ErrInvalidVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out9"),
			TargetArch:        testArchAMD64,
			SkipELFValidation: true,
			Variants: map[string]string{
				"v1": varPath,
			},
			VariantCompression: map[string]VariantCompressionOptions{
				"   ": {Compression: testCompressionZstd},
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrInvalidVariant) {
			t.Fatalf("expected ErrInvalidVariant for empty variant compression level, got %v", err)
		}
	})

	t.Run("Invalid variant compression level returns ErrInvalidVariant", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        filepath.Join(tempDir, "out10"),
			TargetArch:        testArchAMD64,
			SkipELFValidation: true,
			Variants: map[string]string{
				"v1": varPath,
			},
			VariantCompression: map[string]VariantCompressionOptions{
				"v99": {Compression: testCompressionZstd},
			},
		}
		err := validateOptions(&opts)
		if !errors.Is(err, ErrInvalidVariant) {
			t.Fatalf("expected ErrInvalidVariant for invalid variant compression level, got %v", err)
		}
	})
}

func TestPack_CanonicalLevelNormalization(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "stub-canonical")
	v1Path := filepath.Join(tempDir, "bin-v1")
	v3Path := filepath.Join(tempDir, "bin-v3")
	fatBinaryPath := filepath.Join(tempDir, "fat-canonical")

	_ = os.WriteFile(stubPath, []byte("ELF_STUB_CANONICAL"), 0o755)
	_ = os.WriteFile(v1Path, []byte("ELF_PAYLOAD_V1_CANONICAL_TEST_DATA"), 0o755)
	_ = os.WriteFile(v3Path, []byte("ELF_PAYLOAD_V3_CANONICAL_TEST_DATA"), 0o755)

	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatBinaryPath,
		AppName:           "canonical-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		VariantCompression: map[string]VariantCompressionOptions{
			testAliasAMD64v3: {
				Profile:     "latency",
				Compression: "none",
				Level:       "fast",
			},
			"v1": {
				Profile:     "size",
				Compression: "zstd",
				Level:       "best",
			},
		},
		Variants: map[string]string{
			testAliasAMD64v3: v3Path,
			"AMD64_v1":       v1Path,
		},
	}

	idx, err := Pack(opts)
	if err != nil {
		t.Fatalf("Pack failed with canonical aliased variants: %v", err)
	}

	if len(idx.Variants) != 2 {
		t.Fatalf("expected 2 variants, got %d", len(idx.Variants))
	}

	if idx.Variants[0].Level != "v1" {
		t.Errorf("expected idx.Variants[0].Level to be canonical 'v1', got %q", idx.Variants[0].Level)
	}
	if idx.Variants[1].Level != "v3" {
		t.Errorf("expected idx.Variants[1].Level to be canonical 'v3', got %q", idx.Variants[1].Level)
	}

	if idx.Variants[1].Compression != "none" {
		t.Errorf("expected v3 compression override to be applied via alias, got %q", idx.Variants[1].Compression)
	}
}

func TestValidateOptions_ELFValidationErrors(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	invalidELFPath := filepath.Join(tempDir, "invalid-elf")
	_ = os.WriteFile(invalidELFPath, []byte("NOT_AN_ELF_FILE"), 0o755)

	t.Run("Invalid ELF variant binary returns error", func(t *testing.T) {
		t.Parallel()
		opts := Options{
			StubPath:   invalidELFPath,
			OutputPath: filepath.Join(tempDir, "out-elf-err"),
			TargetArch: "amd64",
			Variants: map[string]string{
				"v1": invalidELFPath,
			},
		}
		err := validateOptions(&opts)
		if err == nil {
			t.Fatalf("expected error for invalid ELF variant, got nil")
		}
	})
}

func TestPrewarmAndVerify_AliasNormalization(t *testing.T) {
	t.Parallel()

	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-payload-alias-test"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	v1Content := []byte("v1-binary-content-alias-norm")
	_ = os.WriteFile(v1Path, v1Content, 0o755)

	v3Path := filepath.Join(tempDir, "v3")
	v3Content := []byte("v3-binary-content-alias-norm-avx2")
	_ = os.WriteFile(v3Path, v3Content, 0o755)

	fatPath := filepath.Join(tempDir, "fat.bin")
	opts := Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "alias-norm-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Variants: map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		},
	}

	_, err := Pack(opts)
	require.NoError(t, err, "Pack failed")

	f, err := os.Open(fatPath)
	require.NoError(t, err, "Open failed")
	t.Cleanup(func() { _ = f.Close() })

	stat, err := f.Stat()
	require.NoError(t, err, "Stat failed")

	t.Run("PrewarmBinary with aliases", func(t *testing.T) {
		t.Parallel()

		tests := []struct {
			name           string
			targets        []string
			expectedLevels []string
			wantErr        bool
		}{
			{
				name:           "Single uppercase alias V3",
				targets:        []string{"V3"},
				expectedLevels: []string{"v3"},
			},
			{
				name:           "Single architecture prefix amd64_v3",
				targets:        []string{testAliasAMD64v3},
				expectedLevels: []string{"v3"},
			},
			{
				name:           "Single x86_64 dash alias x86_64-v1",
				targets:        []string{"x86_64-v1"},
				expectedLevels: []string{"v1"},
			},
			{
				name:           "Multiple normalized aliases",
				targets:        []string{"amd64_v1", "V3"},
				expectedLevels: []string{"v1", "v3"},
			},
			{
				name:           "Duplicate aliases resolving to same canonical level",
				targets:        []string{testAliasAMD64v3, "v3", "V3"},
				expectedLevels: []string{"v3"},
			},
			{
				name:    "Non-existent alias returns error",
				targets: []string{"amd64_v4"},
				wantErr: true,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				t.Parallel()
				cacheDir := filepath.Join(tempDir, "prewarm_"+strings.ReplaceAll(tt.name, " ", "_"))

				_, results, err := PrewarmBinary(f, stat.Size(), tt.targets, cacheDir)
				if tt.wantErr {
					if err == nil {
						t.Fatalf("expected error for targets %v, got nil", tt.targets)
					}
					return
				}
				if err != nil {
					t.Fatalf("unexpected error for targets %v: %v", tt.targets, err)
				}

				if len(results) != len(tt.expectedLevels) {
					t.Fatalf("expected %d results, got %d: %+v", len(tt.expectedLevels), len(results), results)
				}

				for i, expected := range tt.expectedLevels {
					if results[i].Level != expected {
						t.Errorf("result[%d] level: expected %q, got %q", i, expected, results[i].Level)
					}
					if !results[i].Valid {
						t.Errorf("result[%d] expected valid=true, got false", i)
					}
				}
			})
		}
	})

	t.Run("VerifyCacheBinary with aliases", func(t *testing.T) {
		t.Parallel()

		cacheDir := filepath.Join(tempDir, "verify_cache")
		_, _, err := PrewarmBinary(f, stat.Size(), nil, cacheDir)
		require.NoError(t, err, "prewarming all variants failed")

		tests := []struct {
			name           string
			targets        []string
			expectedLevels []string
			wantErr        bool
		}{
			{
				name:           "Single uppercase alias V3",
				targets:        []string{"V3"},
				expectedLevels: []string{"v3"},
			},
			{
				name:           "Single architecture prefix amd64_v3",
				targets:        []string{testAliasAMD64v3},
				expectedLevels: []string{"v3"},
			},
			{
				name:           "Single x86_64 dash alias x86_64-v1",
				targets:        []string{"x86_64-v1"},
				expectedLevels: []string{"v1"},
			},
			{
				name:           "Multiple normalized aliases",
				targets:        []string{"amd64_v1", "V3"},
				expectedLevels: []string{"v1", "v3"},
			},
			{
				name:           "Duplicate aliases resolving to same canonical level",
				targets:        []string{testAliasAMD64v3, "v3", "V3"},
				expectedLevels: []string{"v3"},
			},
			{
				name:    "Non-existent alias returns error",
				targets: []string{"amd64_v4"},
				wantErr: true,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				t.Parallel()

				_, results, err := VerifyCacheBinary(f, stat.Size(), tt.targets, cacheDir)
				if tt.wantErr {
					if err == nil {
						t.Fatalf("expected error for targets %v, got nil", tt.targets)
					}
					return
				}
				if err != nil {
					t.Fatalf("unexpected error for targets %v: %v", tt.targets, err)
				}

				if len(results) != len(tt.expectedLevels) {
					t.Fatalf("expected %d results, got %d: %+v", len(tt.expectedLevels), len(results), results)
				}

				for i, expected := range tt.expectedLevels {
					if results[i].Level != expected {
						t.Errorf("result[%d] level: expected %q, got %q", i, expected, results[i].Level)
					}
					if !results[i].Valid || results[i].Status != format.PrewarmStatusValid {
						t.Errorf("result[%d] expected valid and status valid, got %+v", i, results[i])
					}
				}
			})
		}
	})
}

//revive:disable-next-line:cyclomatic Keep explicit versus automatic dictionary failure policy and its warning expectations together.
func TestAutoDictionaryTrainingDiagnostics(t *testing.T) {
	t.Parallel()

	const (
		smallByteLen          = 3
		dictPatternIterCount  = 1200
		dictPatternMultiplier = 43
		dictPatternMask       = 0xA5A5A5A5
	)

	tempDir := t.TempDir()
	stubPath := filepath.Join(tempDir, "stub")
	require.NoError(t, os.WriteFile(stubPath, []byte("DUMMY_STUB_HEADER_DATA_1234567890"), 0o755), "failed to write stub")

	// Create small dummy variants (< 8 bytes total across variants)
	smallVar1 := filepath.Join(tempDir, "small_v1")
	smallVar3 := filepath.Join(tempDir, "small_v3")
	require.NoError(t, os.WriteFile(smallVar1, make([]byte, smallByteLen), 0o755), "failed to write small_v1")
	require.NoError(t, os.WriteFile(smallVar3, make([]byte, smallByteLen), 0o755), "failed to write small_v3")

	// Create large repetitive dummy variants (> 10 KB with repetitive symbols for valid dict training)
	largeVar1 := filepath.Join(tempDir, "large_v1")
	largeVar3 := filepath.Join(tempDir, "large_v3")
	var repBuf bytes.Buffer
	for i := range dictPatternIterCount {
		repBuf.WriteString(fmt.Sprintf("runtime_metadata_symbol_entry_%04d_hash_%x\n", i, (i*dictPatternMultiplier)^dictPatternMask))
	}
	require.NoError(t, os.WriteFile(largeVar1, append(repBuf.Bytes(), []byte("variant_v1_code_segment\n")...), 0o755),
		"failed to write large_v1")
	require.NoError(t, os.WriteFile(largeVar3, append(repBuf.Bytes(), []byte("variant_v3_code_segment\n")...), 0o755),
		"failed to write large_v3")

	t.Run("ProfileSize with small variants emits diagnostic warning and proceeds", func(t *testing.T) {
		t.Parallel()

		var warnings []string
		outPath := filepath.Join(tempDir, "out_size_small.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "size-small-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			Profile:           codec.ProfileSize,
			Variants:          map[string]string{"v1": smallVar1, "v3": smallVar3},
			SkipELFValidation: true,
			WarnFunc: func(format string, args ...any) {
				warnings = append(warnings, fmt.Sprintf(format, args...))
			},
		}

		idx, err := Pack(opts)
		require.NoError(t, err, "expected Pack to succeed, got error")
		if idx == nil {
			t.Fatalf("expected non-nil index")
		}
		if idx.DictionarySize != 0 {
			t.Errorf("expected zero dictionary size when training fails, got %d", idx.DictionarySize)
		}
		if len(warnings) != 1 {
			t.Fatalf("expected 1 warning, got %d: %v", len(warnings), warnings)
		}
		expectedMsg := "shared dictionary training failed (sample data too small for dictionary training (< 8 bytes)); " +
			"proceeding with independent variant compression"
		if !strings.Contains(warnings[0], expectedMsg) {
			t.Errorf("warning %q does not contain expected %q", warnings[0], expectedMsg)
		}

		// Verify produced binary is structurally sound and verifiable
		f, err := os.Open(outPath)
		require.NoError(t, err, "failed to open output")
		defer func() { _ = f.Close() }()

		stat, err := f.Stat()
		require.NoError(t, err, "failed to stat output")
		vIdx, results, err := VerifyBinary(f, stat.Size())
		require.NoError(t, err, "VerifyBinary failed")
		if vIdx.DictionarySize != 0 {
			t.Errorf("expected 0 DictionarySize in verified index, got %d", vIdx.DictionarySize)
		}
		if len(results) != 2 {
			t.Fatalf("expected 2 results, got %d", len(results))
		}
		for _, r := range results {
			if !r.Valid || r.Error != nil {
				t.Errorf("expected valid result for %s: %v", r.Level, r.Error)
			}
		}
	})

	t.Run("ProfileSize with small variants and nil WarnFunc falls back cleanly without panic", func(t *testing.T) {
		t.Parallel()

		outPath := filepath.Join(tempDir, "out_size_nil_warn.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "size-nil-warn-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			Profile:           codec.ProfileSize,
			Variants:          map[string]string{"v1": smallVar1, "v3": smallVar3},
			SkipELFValidation: true,
			WarnFunc:          nil,
		}

		idx, err := Pack(opts)
		require.NoError(t, err, "expected Pack to succeed, got error")
		if idx == nil {
			t.Fatalf("expected non-nil index")
		}
		if idx.DictionarySize != 0 {
			t.Errorf("expected 0 DictionarySize, got %d", idx.DictionarySize)
		}
	})

	t.Run("ProfileSize case-insensitive (' Size ') with small variants emits diagnostic and proceeds", func(t *testing.T) {
		t.Parallel()

		var warnings []string
		outPath := filepath.Join(tempDir, "out_size_case_insensitive.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "size-case-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			Profile:           " Size ",
			Variants:          map[string]string{"v1": smallVar1, "v3": smallVar3},
			SkipELFValidation: true,
			WarnFunc: func(format string, args ...any) {
				warnings = append(warnings, fmt.Sprintf(format, args...))
			},
		}

		idx, err := Pack(opts)
		require.NoError(t, err, "expected Pack to succeed, got error")
		if idx == nil {
			t.Fatalf("expected non-nil index")
		}
		if idx.DictionarySize != 0 {
			t.Errorf("expected zero dictionary size when training fails, got %d", idx.DictionarySize)
		}
		if len(warnings) != 1 {
			t.Fatalf("expected 1 warning for ' Size ', got %d: %v", len(warnings), warnings)
		}
		if !strings.Contains(warnings[0], "shared dictionary training failed") {
			t.Errorf("expected warning to mention failed training, got %q", warnings[0])
		}
	})

	t.Run("ProfileSize with large repetitive variants succeeds silently with dictionary", func(t *testing.T) {
		t.Parallel()

		var warnings []string
		outPath := filepath.Join(tempDir, "out_size_large.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "size-large-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			Profile:           codec.ProfileSize,
			Variants:          map[string]string{"v1": largeVar1, "v3": largeVar3},
			SkipELFValidation: true,
			WarnFunc: func(format string, args ...any) {
				warnings = append(warnings, fmt.Sprintf(format, args...))
			},
		}

		idx, err := Pack(opts)
		require.NoError(t, err, "expected Pack to succeed, got error")
		if idx == nil {
			t.Fatalf("expected non-nil index")
		}
		if idx.DictionarySize <= 0 {
			t.Errorf("expected DictionarySize > 0, got %d", idx.DictionarySize)
		}
		if len(warnings) != 0 {
			t.Errorf("expected 0 warnings on successful dictionary training, got %v", warnings)
		}
	})

	t.Run("Explicit EnableDict with small variants fails fast with error", func(t *testing.T) {
		t.Parallel()

		var warnings []string
		outPath := filepath.Join(tempDir, "out_explicit_small.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "explicit-small-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			EnableDict:        true,
			Variants:          map[string]string{"v1": smallVar1, "v3": smallVar3},
			SkipELFValidation: true,
			WarnFunc: func(format string, args ...any) {
				warnings = append(warnings, fmt.Sprintf(format, args...))
			},
		}

		idx, err := Pack(opts)
		require.Errorf(t, err, "expected Pack to fail, but succeeded with idx: %+v", idx)
		if !strings.Contains(err.Error(), "training shared dictionary: sample data too small for dictionary training (< 8 bytes)") {
			t.Errorf("error %q does not contain expected message", err.Error())
		}
		if len(warnings) != 0 {
			t.Errorf("expected no warnings when explicit EnableDict fails fast, got %v", warnings)
		}
	})

	t.Run("Explicit EnableDict with single variant fails fast with error", func(t *testing.T) {
		t.Parallel()

		outPath := filepath.Join(tempDir, "out_explicit_single.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "explicit-single-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			EnableDict:        true,
			Variants:          map[string]string{"v1": smallVar1},
			SkipELFValidation: true,
		}

		_, err := Pack(opts)
		require.Error(t, err, "expected Pack to fail for single variant with EnableDict, but got nil error")
		if !strings.Contains(err.Error(), "training shared dictionary: requires at least two variants") {
			t.Errorf("error %q does not contain expected message", err.Error())
		}
	})

	t.Run("Unreadable variant during sampling fails fast under EnableDict", func(t *testing.T) {
		t.Parallel()

		outPath := filepath.Join(tempDir, "out_missing_var_dict.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "missing-var-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			EnableDict:        true,
			Variants:          map[string]string{"v1": smallVar1, "v3": filepath.Join(tempDir, "non_existent")},
			SkipELFValidation: true,
		}

		_, err := Pack(opts)
		require.Error(t, err, "expected Pack to fail on missing variant with EnableDict")
		if !strings.Contains(err.Error(), "snapshot variant") {
			t.Errorf("error %q does not contain sampling variants error", err.Error())
		}
	})

	t.Run("Unreadable variant fails before sampling under ProfileSize", func(t *testing.T) {
		t.Parallel()

		var warnings []string
		outPath := filepath.Join(tempDir, "out_missing_var_size.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "missing-var-size-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			Profile:           codec.ProfileSize,
			Variants:          map[string]string{"v1": smallVar1, "v3": filepath.Join(tempDir, "non_existent")},
			SkipELFValidation: true,
			WarnFunc: func(format string, args ...any) {
				warnings = append(warnings, fmt.Sprintf(format, args...))
			},
		}

		_, err := Pack(opts)
		require.Error(t, err, "expected Pack to fail on missing variant")
		if len(warnings) != 0 {
			t.Fatalf("input rejection must precede dictionary training: %v", warnings)
		}
		if !errors.Is(err, ErrVariantNotFound) {
			t.Errorf("expected ErrVariantNotFound, got %v", err)
		}
	})

	t.Run("Zero byte variants under ProfileSize fail before dictionary training", func(t *testing.T) {
		t.Parallel()

		emptyVar1 := filepath.Join(tempDir, "empty_v1")
		emptyVar3 := filepath.Join(tempDir, "empty_v3")
		require.NoError(t, os.WriteFile(emptyVar1, []byte{}, 0o755), "failed to write empty_v1")
		require.NoError(t, os.WriteFile(emptyVar3, []byte{}, 0o755), "failed to write empty_v3")

		var warnings []string
		outPath := filepath.Join(tempDir, "out_empty_size.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "empty-size-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			Profile:           codec.ProfileSize,
			Variants:          map[string]string{"v1": emptyVar1, "v3": emptyVar3},
			SkipELFValidation: true,
			WarnFunc: func(format string, args ...any) {
				warnings = append(warnings, fmt.Sprintf(format, args...))
			},
		}

		_, err := Pack(opts)
		if !errors.Is(err, ErrInvalidELF) {
			t.Fatalf("empty variant must fail: %v", err)
		}
		if len(warnings) != 0 {
			t.Fatalf("empty input must fail before dictionary training: %v", warnings)
		}

	})

	t.Run("Zero byte variants under EnableDict fails fast with no sample data error", func(t *testing.T) {
		t.Parallel()

		emptyVar1 := filepath.Join(tempDir, "empty_v1_fail")
		emptyVar3 := filepath.Join(tempDir, "empty_v3_fail")
		require.NoError(t, os.WriteFile(emptyVar1, []byte{}, 0o755), "failed to write empty_v1")
		require.NoError(t, os.WriteFile(emptyVar3, []byte{}, 0o755), "failed to write empty_v3")

		outPath := filepath.Join(tempDir, "out_empty_dict.fat")
		opts := Options{
			StubPath:          stubPath,
			OutputPath:        outPath,
			AppName:           "empty-dict-app",
			TargetOS:          testOSLinux,
			TargetArch:        testArchAMD64,
			EnableDict:        true,
			Variants:          map[string]string{"v1": emptyVar1, "v3": emptyVar3},
			SkipELFValidation: true,
		}

		_, err := Pack(opts)
		require.Error(t, err, "expected Pack to fail on empty variants with EnableDict")
		if !strings.Contains(err.Error(), "nonempty regular file") {
			t.Errorf("error %q does not contain expected message", err.Error())
		}
	})
}

func TestPrewarm_RequiresValidDictionaryChecksum(t *testing.T) {
	t.Parallel()
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("STUB_CODE_LAUNCHER"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	v3Path := filepath.Join(tempDir, "v3")
	_ = os.WriteFile(v1Path, bytes.Repeat([]byte("PAYLOAD_V1_DATA_PATTERN_"), 100), 0o755)
	_ = os.WriteFile(v3Path, bytes.Repeat([]byte("PAYLOAD_V3_DATA_PATTERN_"), 100), 0o755)

	fatPath := filepath.Join(tempDir, "dict_app.fat")
	opts := DefaultOptions()
	opts.StubPath = stubPath
	opts.OutputPath = fatPath
	opts.AppName = "dict-app"
	opts.EnableDict = true
	opts.Variants = map[string]string{"v1": v1Path, "v3": v3Path}
	opts.SkipELFValidation = true

	_, err := Pack(opts)
	require.NoError(t, err, "Pack failed")

	fatBytes, err := os.ReadFile(fatPath)
	require.NoError(t, err, "reading fat file")

	fatReader := bytes.NewReader(fatBytes)
	statSize := int64(len(fatBytes))

	origIdx, err := format.ReadTrailerAndIndex(fatReader, statSize)
	require.NoError(t, err, "ReadTrailerAndIndex failed")
	if origIdx.DictionarySize <= 0 || origIdx.DictionarySHA256 == "" {
		t.Fatalf("expected packed binary to have shared dictionary with SHA-256")
	}

	trailerBytes := fatBytes[statSize-format.TrailerSize:]
	indexOffset := int64(binary.LittleEndian.Uint64(trailerBytes[0:8]))

	buildPoisonedFatFile := func(t *testing.T, poisonedSHA string) (*os.File, int64) {
		t.Helper()
		tamperedIdx := *origIdx
		tamperedIdx.DictionarySHA256 = poisonedSHA

		var buf bytes.Buffer
		buf.Write(fatBytes[:indexOffset])
		if _, err := format.WriteIndexAndTrailerWithVersion(&buf, &tamperedIdx, indexOffset, format.FormatVersion1); err != nil {
			t.Fatalf("failed to rewrite index and trailer: %v", err)
		}

		f, err := os.CreateTemp(t.TempDir(), "poisoned_dict_*.fat")
		require.NoError(t, err, "failed to create temp file")
		if _, err := f.Write(buf.Bytes()); err != nil {
			_ = f.Close()
			t.Fatalf("failed to write temp file: %v", err)
		}
		t.Cleanup(func() { _ = f.Close() })
		return f, int64(buf.Len())
	}

	t.Run("Empty Dictionary SHA-256 Rejected", func(t *testing.T) {
		t.Parallel()
		cacheDir := t.TempDir()
		fatFile, totalSize := buildPoisonedFatFile(t, "")
		_, _, err := PrewarmBinary(fatFile, totalSize, nil, cacheDir)
		if err == nil || !errors.Is(err, format.ErrInvalidChecksum) {
			t.Fatalf("expected ErrInvalidChecksum for empty dictionary SHA, got: %v", err)
		}
	})

	t.Run("Malformed Dictionary SHA-256 Rejected", func(t *testing.T) {
		t.Parallel()
		cacheDir := t.TempDir()
		fatFile, totalSize := buildPoisonedFatFile(t, "not-a-valid-sha256-hex-digest")
		_, _, err := PrewarmBinary(fatFile, totalSize, nil, cacheDir)
		if err == nil || !errors.Is(err, format.ErrInvalidChecksum) {
			t.Fatalf("expected ErrInvalidChecksum for malformed dictionary SHA, got: %v", err)
		}
	})

	t.Run("Mismatched Dictionary SHA-256 Rejected", func(t *testing.T) {
		t.Parallel()
		cacheDir := t.TempDir()
		wrongSHA := strings.Repeat("0", 64)
		fatFile, totalSize := buildPoisonedFatFile(t, wrongSHA)
		_, _, err := PrewarmBinary(fatFile, totalSize, nil, cacheDir)
		if err == nil || !errors.Is(err, format.ErrDictionaryCorrupted) {
			t.Fatalf("expected ErrDictionaryCorrupted for mismatched dictionary SHA, got: %v", err)
		}
	})

	t.Run("Authentic Dictionary SHA-256 Succeeds", func(t *testing.T) {
		t.Parallel()
		cacheDir := filepath.Join(t.TempDir(), "cache")
		f, err := os.Open(fatPath)
		require.NoError(t, err, "failed to open authentic fat file")
		defer func() { _ = f.Close() }()

		idx, results, err := PrewarmBinary(f, statSize, nil, cacheDir)
		require.NoError(t, err, "expected PrewarmBinary to succeed with authentic dictionary, got")
		if idx == nil || len(results) != 2 {
			t.Fatalf("expected 2 prewarm results, got: %v", results)
		}
	})
}

func TestPrewarmVariantWithDict_RejectsInvalidDimensions(t *testing.T) {
	t.Parallel()
	tempDir := t.TempDir()
	cacheDir := filepath.Join(tempDir, "cache")
	dummyReader := bytes.NewReader(make([]byte, 1024))

	validSHA := strings.Repeat("a", 64)

	t.Run("Negative Uncompressed Size", func(t *testing.T) {
		t.Parallel()
		entry := &format.VariantEntry{
			Level:            "v3",
			Offset:           0,
			CompressedSize:   100,
			UncompressedSize: -1,
			SHA256:           validSHA,
		}
		_, _, _, err := PrewarmVariantWithDict(dummyReader, entry, cacheDir, nil)
		if err == nil || !errors.Is(err, format.ErrPayloadTooLarge) {
			t.Fatalf("expected ErrPayloadTooLarge for negative uncompressed size, got: %v", err)
		}
	})

	t.Run("Zero Uncompressed Size", func(t *testing.T) {
		t.Parallel()
		entry := &format.VariantEntry{
			Level:            "v3",
			Offset:           0,
			CompressedSize:   100,
			UncompressedSize: 0,
			SHA256:           validSHA,
		}
		_, _, _, err := PrewarmVariantWithDict(dummyReader, entry, cacheDir, nil)
		if err == nil || !errors.Is(err, format.ErrPayloadTooLarge) {
			t.Fatalf("expected ErrPayloadTooLarge for zero uncompressed size, got: %v", err)
		}
	})

	t.Run("Oversized Uncompressed Size", func(t *testing.T) {
		t.Parallel()
		entry := &format.VariantEntry{
			Level:            "v3",
			Offset:           0,
			CompressedSize:   100,
			UncompressedSize: format.MaxPayloadSize + 1,
			SHA256:           validSHA,
		}
		_, _, _, err := PrewarmVariantWithDict(dummyReader, entry, cacheDir, nil)
		if err == nil || !errors.Is(err, format.ErrPayloadTooLarge) {
			t.Fatalf("expected ErrPayloadTooLarge for oversized uncompressed size, got: %v", err)
		}
	})

	t.Run("Empty or Malformed SHA256", func(t *testing.T) {
		t.Parallel()
		entry := &format.VariantEntry{
			Level:            "v3",
			Offset:           0,
			CompressedSize:   100,
			UncompressedSize: 100,
			SHA256:           "",
		}
		_, _, _, err := PrewarmVariantWithDict(dummyReader, entry, cacheDir, nil)
		if err == nil || !errors.Is(err, format.ErrInvalidChecksum) {
			t.Fatalf("expected ErrInvalidChecksum for empty SHA256, got: %v", err)
		}

		entry.SHA256 = "invalid-sha"
		_, _, _, err = PrewarmVariantWithDict(dummyReader, entry, cacheDir, nil)
		if err == nil || !errors.Is(err, format.ErrInvalidChecksum) {
			t.Fatalf("expected ErrInvalidChecksum for malformed SHA256, got: %v", err)
		}
	})
}

func TestPrewarmVariantWithDict_SymlinkRejection(t *testing.T) {
	t.Parallel()
	tempDir := t.TempDir()
	dummyReader := bytes.NewReader(make([]byte, 1024))
	validSHA := strings.Repeat("a", 64)
	entry := &format.VariantEntry{
		Level:            "v1",
		Offset:           0,
		CompressedSize:   100,
		UncompressedSize: 100,
		SHA256:           validSHA,
		Compression:      "zstd",
	}

	t.Run("SymlinkCacheDirRoot_Rejected", func(t *testing.T) {
		realCache := filepath.Join(tempDir, "real_cache")
		if err := os.MkdirAll(realCache, 0o700); err != nil {
			t.Fatalf("mkdir: %v", err)
		}
		symlinkCache := filepath.Join(tempDir, "symlink_cache_root")
		if err := os.Symlink(realCache, symlinkCache); err != nil {
			t.Fatalf("symlink: %v", err)
		}

		_, _, _, err := PrewarmVariantWithDict(dummyReader, entry, symlinkCache, nil)
		if err == nil {
			t.Fatalf("expected error for symlink cacheDir root, got nil")
		}
		if !errors.Is(err, format.ErrInsecureCacheDir) {
			t.Fatalf("expected ErrInsecureCacheDir for symlink cacheDir root, got: %v", err)
		}
	})

	t.Run("SymlinkTargetVariant_Rejected", func(t *testing.T) {
		cacheDir := filepath.Join(tempDir, "symlink_target_cache")
		if err := os.MkdirAll(cacheDir, 0o700); err != nil {
			t.Fatalf("mkdir: %v", err)
		}
		decoyFile := filepath.Join(tempDir, "decoy")
		if err := os.WriteFile(decoyFile, []byte("decoy"), 0o600); err != nil {
			t.Fatalf("write decoy: %v", err)
		}
		symlinkVariant := filepath.Join(cacheDir, validSHA)
		if err := os.Symlink(decoyFile, symlinkVariant); err != nil {
			t.Fatalf("symlink variant: %v", err)
		}

		_, _, _, err := PrewarmVariantWithDict(dummyReader, entry, cacheDir, nil)
		if err == nil {
			t.Fatalf("expected error for symlink variant target, got nil")
		}
		if !errors.Is(err, format.ErrCacheWrite) {
			t.Fatalf("expected ErrCacheWrite for symlink variant target, got: %v", err)
		}
	})
}
