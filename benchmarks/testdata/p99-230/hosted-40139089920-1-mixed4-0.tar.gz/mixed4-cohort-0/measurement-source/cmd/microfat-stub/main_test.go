//go:build !minimal

package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	json "encoding/json/v2"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"syscall"
	"testing"
	"time"

	"github.com/EpicBlackWolfZ/microfat/internal/cgroup"
	"github.com/EpicBlackWolfZ/microfat/internal/format"
	"github.com/EpicBlackWolfZ/microfat/internal/lifecycle"
	"github.com/EpicBlackWolfZ/microfat/internal/microarch"
	"github.com/EpicBlackWolfZ/microfat/internal/pack"
	"github.com/EpicBlackWolfZ/microfat/internal/testutil"
	"github.com/klauspost/compress/zstd"
	"golang.org/x/sys/unix"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const (
	testOSLinux          = "linux"
	testPolicyForceLevel = "force_level"
	testForceLevelV3     = "MICROFAT_FORCE_LEVEL=v3"
	testCompressionZstd  = "zstd"
)

func TestPrintHelpAndInfo(t *testing.T) {
	idx := &format.Index{
		Version:     1,
		AppName:     "testapp",
		TargetOS:    testOSLinux,
		TargetArch:  testArchAMD64,
		CreatedUnix: 1700000000,
		Variants: []format.VariantEntry{
			{
				Level:            "v1",
				Offset:           1000,
				CompressedSize:   500,
				UncompressedSize: 1000,
				SHA256:           "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
			},
		},
	}
	hostInfo := microarch.Info{
		OS:       testOSLinux,
		Arch:     testArchAMD64,
		Level:    "v3",
		Features: []string{"avx", "avx2"},
	}

	testForcedRes := microarch.PolicyResult{
		PolicyApplied:  testPolicyForceLevel,
		OverrideReason: "MICROFAT_FORCE_LEVEL=v1",
	}

	// Should execute without panic (text and JSON mode)
	printHelp(idx, hostInfo, &idx.Variants[0], testForcedRes)
	_ = printInfo(idx, hostInfo, &idx.Variants[0], microarch.PolicyResult{}, 2000, false)
	_ = printInfo(idx, hostInfo, &idx.Variants[0], testForcedRes, 2000, true)
	_ = printInfo(idx, hostInfo, &idx.Variants[0], testForcedRes, 2000, false)

	if !hasJSONFlag([]string{"--json"}) {
		t.Errorf("expected hasJSONFlag(--json) to be true")
	}
	if !hasJSONFlag([]string{"-json"}) {
		t.Errorf("expected hasJSONFlag(-json) to be true")
	}
	if hasJSONFlag([]string{"--other"}) {
		t.Errorf("expected hasJSONFlag(--other) to be false")
	}
}

func TestBuildAutoTunedEnviron(t *testing.T) {
	base := []string{"PATH=/usr/bin", "USER=test"}
	entry := &format.VariantEntry{
		Level:            "v3",
		SHA256:           "abcdef123456",
		UncompressedSize: 1000,
	}
	hostInfo := microarch.Info{
		OS:       testOSLinux,
		Arch:     testArchAMD64,
		Level:    "v3",
		Features: []string{"avx", "avx2"},
	}
	testPolicyRes := microarch.PolicyResult{
		SelectedVariant: "v3",
		PolicyApplied:   testPolicyForceLevel,
		OverrideReason:  testForceLevelV3,
	}

	// 1. Standard auto-tune with metadata injection
	env, _ := buildAutoTunedEnviron("", base, entry, format.ExecModeMemfd, hostInfo, testPolicyRes)
	assert.Subset(t, env, []string{
		"MICROFAT_SELECTED_VARIANT=v3", "MICROFAT_HOST_ARCH=amd64", "MICROFAT_HOST_LEVEL=v3",
		"MICROFAT_EXEC_MODE=memfd", "MICROFAT_DISPATCH_MODE=memfd", "MICROFAT_SELECTED_SHA256=abcdef123456",
		"MICROFAT_SELECTED_SIZE=1000", "MICROFAT_POLICY_APPLIED=force_level",
		"MICROFAT_OVERRIDE_REASON=MICROFAT_FORCE_LEVEL=v3",
	})

	// 2. Opt-out via MICROFAT_AUTOTUNE=0
	t.Setenv("MICROFAT_AUTOTUNE", "0")
	envOptOut, _ := buildAutoTunedEnviron("", base, entry, format.ExecModeCache, hostInfo, microarch.PolicyResult{})
	assert.GreaterOrEqual(t, len(envOptOut), len(base)+7, "base plus seven injected metadata variables")

	// 3. Opt-out via MICROFAT_AUTOTUNE=false
	t.Setenv("MICROFAT_AUTOTUNE", "false")
	envFalse, _ := buildAutoTunedEnviron("", base, entry, format.ExecModeCache, hostInfo, microarch.PolicyResult{})
	assert.Len(t, envFalse, len(envOptOut), "both opt-out spellings preserve metadata")

	// 4. Preserve existing GOMEMLIMIT and GOMAXPROCS
	t.Setenv("MICROFAT_AUTOTUNE", "1")
	existing := []string{"GOMEMLIMIT=1GiB", "GOMAXPROCS=8"}
	envPreserve, _ := buildAutoTunedEnviron("", existing, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})
	assert.Subset(t, envPreserve, existing, "preserve user runtime settings")

	// 5. Custom memory ratio variations
	t.Setenv("MICROFAT_MEM_RATIO", "0.85")
	_, _ = buildAutoTunedEnviron("", base, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})

	t.Setenv("MICROFAT_MEM_RATIO", "invalid")
	_, _ = buildAutoTunedEnviron("", base, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})

	t.Setenv("MICROFAT_MEM_RATIO", "1.5")
	_, _ = buildAutoTunedEnviron("", base, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})

	t.Setenv("MICROFAT_MEM_RATIO", "-0.2")
	_, _ = buildAutoTunedEnviron("", base, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})

	// 6. Test with mocked active cgroup limits
	oldReadCgroup := readCgroupLimitsFunc
	defer func() { readCgroupLimitsFunc = oldReadCgroup }()

	// cgroup read error
	readCgroupLimitsFunc = func() (cgroup.Limits, error) {
		return cgroup.Limits{CgroupVersion: cgroup.VersionUnknown}, errors.New("cgroup error")
	}
	t.Setenv(format.EnvDebug, "1")
	envErr, limitsErr := buildAutoTunedEnviron("", []string{testPathEnv}, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})
	require.Nil(t, limitsErr, "failed cgroup inspection must not yield active limits")
	for _, e := range envErr {
		assert.False(t, strings.HasPrefix(e, "GOMEMLIMIT="), e)
		assert.False(t, strings.HasPrefix(e, "GOMAXPROCS="), e)
		assert.False(t, strings.HasPrefix(e, "MICROFAT_CGROUP_"), e)
	}

	// cgroup unknown version
	readCgroupLimitsFunc = func() (cgroup.Limits, error) {
		return cgroup.Limits{CgroupVersion: cgroup.VersionUnknown}, nil
	}
	envUnknown, limitsUnknown := buildAutoTunedEnviron(
		"", []string{testPathEnv}, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{},
	)
	require.Nil(t, limitsUnknown, "unknown cgroups must not yield active limits")
	for _, e := range envUnknown {
		assert.False(t, strings.HasPrefix(e, "GOMEMLIMIT="), e)
		assert.False(t, strings.HasPrefix(e, "GOMAXPROCS="), e)
		assert.False(t, strings.HasPrefix(e, "MICROFAT_CGROUP_"), e)
	}
	t.Setenv(format.EnvDebug, "")

	readCgroupLimitsFunc = func() (cgroup.Limits, error) {
		return cgroup.Limits{
			CgroupVersion:    cgroup.VersionV2,
			MemoryLimitBytes: 1024 * 1024 * 1024,
			CPUQuota:         4.0,
			CPUs:             4,
		}, nil
	}

	envCgroup, limits := buildAutoTunedEnviron("", []string{testPathEnv}, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})
	require.NotNil(t, limits)
	require.Equal(t, cgroup.VersionV2, limits.CgroupVersion)
	assert.True(t, slices.ContainsFunc(envCgroup, func(e string) bool { return strings.HasPrefix(e, "GOMEMLIMIT=") }))
	assert.Contains(t, envCgroup, "GOMAXPROCS=4")
	assert.Subset(t, envCgroup, []string{
		"MICROFAT_CGROUP_VERSION=2", "MICROFAT_CGROUP_LIMIT_BYTES=1073741824", "MICROFAT_CGROUP_CPUS=4.00",
	})

	// 6b. Test dry-run simulation via MICROFAT_DRY_RUN
	for _, dryRunVal := range []string{"1", "true", "TRUE"} {
		t.Setenv("MICROFAT_AUTOTUNE", "1")
		t.Setenv("MICROFAT_DRY_RUN", dryRunVal)
		envDry, limitsDry := buildAutoTunedEnviron("", []string{testPathEnv}, entry, format.ExecModeMemfd, hostInfo, microarch.PolicyResult{})
		require.NotNil(t, limitsDry, dryRunVal)
		require.Equal(t, cgroup.VersionV2, limitsDry.CgroupVersion, dryRunVal)
		for _, e := range envDry {
			assert.False(t, strings.HasPrefix(e, "GOMEMLIMIT="), "%s: %s", dryRunVal, e)
			assert.False(t, strings.HasPrefix(e, "GOMAXPROCS="), "%s: %s", dryRunVal, e)
			assert.False(t, strings.HasPrefix(e, "GOGC="), "%s: %s", dryRunVal, e)
		}
		assert.Subset(t, envDry, []string{"MICROFAT_CGROUP_VERSION=2", "MICROFAT_CGROUP_GOMAXPROCS=4"}, dryRunVal)
		assert.True(t, slices.ContainsFunc(envDry, func(e string) bool {
			return strings.HasPrefix(e, "MICROFAT_CGROUP_GOMEMLIMIT=")
		}), dryRunVal)
	}
	t.Setenv("MICROFAT_DRY_RUN", "")

	// 7. Test printInfo with mocked limits
	idx := &format.Index{
		AppName:    "testapp",
		TargetOS:   testOSLinux,
		TargetArch: testArchAMD64,
		Variants: []format.VariantEntry{
			{Level: "v3", Offset: 100, CompressedSize: 200, UncompressedSize: 300, SHA256: "hash"},
		},
	}
	_ = printInfo(idx, hostInfo, &idx.Variants[0], microarch.PolicyResult{}, 1000, false)
	_ = printInfo(idx, hostInfo, &idx.Variants[0], microarch.PolicyResult{}, 1000, true)

	// Test printInfo with unlimited limits
	readCgroupLimitsFunc = func() (cgroup.Limits, error) {
		return cgroup.Limits{
			CgroupVersion:    cgroup.VersionV1,
			MemoryLimitBytes: 0,
			CPUQuota:         0,
			CPUs:             0,
		}, nil
	}
	_ = printInfo(idx, hostInfo, &idx.Variants[0], microarch.PolicyResult{}, 1000, false)
	_ = printInfo(idx, hostInfo, &idx.Variants[0], microarch.PolicyResult{}, 1000, true)
}

func TestBuildAutoTunedEnviron_DeduplicationAndReplacement(t *testing.T) {
	entry := &format.VariantEntry{
		Level:            "v3",
		SHA256:           "abcdef123456",
		UncompressedSize: 1000,
	}
	hostInfo := microarch.Info{
		OS:       testOSLinux,
		Arch:     testArchAMD64,
		Level:    "v3",
		Features: []string{"avx", "avx2"},
	}
	testPolicyRes := microarch.PolicyResult{
		SelectedVariant: "v3",
		PolicyApplied:   testPolicyForceLevel,
		OverrideReason:  testForceLevelV3,
	}

	base := []string{
		"PATH=/usr/bin",
		"USER=test",
		"NO_EQUALS_ENTRY",
		"=LEADING_EQUALS",
		"MICROFAT_EXEC_MODE=cache",
		"MICROFAT_SELECTED_VARIANT=v1",
		"MICROFAT_HOST_ARCH=arm64",
		"MICROFAT_HOST_LEVEL=v8.0",
		"MICROFAT_CGROUP_VERSION=1",
		"GOMEMLIMIT=256MiB",
		"GOMEMLIMIT=1GiB",
		"GOMAXPROCS=2",
		"GOMAXPROCS=4",
	}

	env, _ := buildAutoTunedEnviron("", base, entry, format.ExecModeMemfd, hostInfo, testPolicyRes)

	// Verify all keys are strictly unique
	seenKeys := make(map[string]int)
	for _, e := range env {
		key, _, found := strings.Cut(e, "=")
		if found && key != "" {
			seenKeys[key]++
			if seenKeys[key] > 1 {
				t.Errorf("duplicate key %q found %d times in environment: %v", key, seenKeys[key], env)
			}
		}
	}

	// Verify launcher-owned keys replaced stale values from baseEnv
	expectedValues := map[string]string{
		format.EnvSelectedVariant: "v3",
		format.EnvHostArch:        testArchAMD64,
		format.EnvHostLevel:       "v3",
		format.EnvExecMode:        format.ExecModeMemfd,
		format.EnvDispatchMode:    format.ExecModeMemfd,
		"GOMEMLIMIT":              "1GiB", // User-specified override preserved from later base entry
		"GOMAXPROCS":              "4",    // User-specified override preserved from later base entry
	}

	for k, expectedVal := range expectedValues {
		expectedEntry := fmt.Sprintf("%s=%s", k, expectedVal)
		var found bool
		if slices.Contains(env, expectedEntry) {
			found = true
		}
		if !found {
			t.Errorf("expected %q in environment, but not found or value mismatch. env: %v", expectedEntry, env)
		}
	}
}

func TestLogDiagnostics(t *testing.T) {
	entry := &format.VariantEntry{Level: "v3", SHA256: "abc123hash", UncompressedSize: 2048}
	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	env := []string{"GOMEMLIMIT=1000B", "GOMAXPROCS=4"}
	limits := &cgroup.Limits{
		CgroupVersion:    2,
		MemoryLimitBytes: 1024 * 1024 * 1024,
		CPUQuota:         4.0,
		CPUs:             4,
	}

	policyRes := microarch.PolicyResult{PolicyApplied: testPolicyForceLevel, OverrideReason: testForceLevelV3}

	// Text debug output
	t.Setenv("MICROFAT_DEBUG", "1")
	t.Setenv("MICROFAT_LOG", "")
	logDiagnostics(entry, format.ExecModeMemfd, hostInfo, policyRes, env, limits, 100, 500)

	// JSON log output with limits
	t.Setenv("MICROFAT_DEBUG", "0")
	t.Setenv("MICROFAT_LOG", "json")
	logDiagnostics(entry, format.ExecModeCache, hostInfo, policyRes, env, limits, 200, 600)

	// JSON log output without limits
	logDiagnostics(entry, format.ExecModeMemfd, hostInfo, policyRes, env, nil, 200, 600)

	// Debug false without log
	t.Setenv("MICROFAT_DEBUG", "0")
	t.Setenv("MICROFAT_LOG", "")
	logDiagnostics(entry, format.ExecModeMemfd, hostInfo, policyRes, env, limits, 100, 500)

	// Test error diagnostics
	t.Setenv("MICROFAT_LOG", "json")
	logErrorDiagnostics("memfd_create", errors.New("memfd error"), hostInfo, entry, policyRes, "details test")
	logErrorDiagnostics("test_stage", errors.New("no entry error"), hostInfo, nil, policyRes, "details test")

	t.Setenv("MICROFAT_LOG", "")
	logErrorDiagnostics("test_stage", errors.New("silent error"), hostInfo, entry, policyRes, "should not log")
}

func TestEscapeJSONString(t *testing.T) {
	input := "hello \"world\" \\ \b \f \n \r \t \x00 \x1f test"
	escaped := format.EscapeJSONString(input)
	expected := `hello \"world\" \\ \b \f \n \r \t \u0000 \u001f test`
	if escaped != expected {
		t.Errorf("escapeJSONString mismatch: got %q, want %q", escaped, expected)
	}
}

func TestGetSelfExecutablePath(t *testing.T) {
	path, err := getSelfExecutablePathFunc()
	if err != nil {
		t.Fatalf("getSelfExecutablePathFunc failed: %v", err)
	}
	if path == "" {
		t.Errorf("expected non-empty executable path")
	}
}

func TestHelperFunctions(t *testing.T) {
	if !isPrefixOrExact("--microfat:trim", "--microfat:trim") {
		t.Errorf("expected exact match true")
	}
	if !isPrefixOrExact("--microfat:trim=dest", "--microfat:trim") {
		t.Errorf("expected prefix match true")
	}
	if isPrefixOrExact("--microfat:other", "--microfat:trim") {
		t.Errorf("expected mismatch false")
	}
	if isPrefixOrExact("anything", "") {
		t.Errorf("expected empty flag to return false")
	}

	target, err := extractTargetPath("--microfat:trim-to=/path/to/target", "--microfat:trim-to", "")
	if err != nil || target != "/path/to/target" {
		t.Errorf("extractTargetPath with = failed: %v, got %s", err, target)
	}

	targetAlias, err := extractTargetPath("--microfat:specialize-to=/path/alias", "--microfat:trim-to", "--microfat:specialize-to")
	if err != nil || targetAlias != "/path/alias" {
		t.Errorf("extractTargetPath with alias failed: %v, got %s", err, targetAlias)
	}

	oldArgs := os.Args
	defer func() { os.Args = oldArgs }()
	os.Args = []string{testAppArg, "--microfat:trim-to"}

	_, err = extractTargetPath("--microfat:trim-to", "--microfat:trim-to", "")
	if err == nil {
		t.Errorf("expected error when no target path provided")
	}

	_, err = extractTargetPath("--microfat:trim-to=", "--microfat:trim-to", "")
	if err == nil {
		t.Errorf("expected error for --microfat:trim-to=")
	}

	_, err = extractTargetPath("--microfat:specialize-to=", "--microfat:trim-to", "--microfat:specialize-to")
	if err == nil {
		t.Errorf("expected error for --microfat:specialize-to=")
	}

	os.Args = []string{testAppArg, "--microfat:trim-to", "  "}
	target, err = extractTargetPath("--microfat:trim-to", "--microfat:trim-to", "")
	require.NoError(t, err)
	require.Equal(t, "  ", target, "whitespace is valid destination path data")

	err = trimTo("", nil, 0, "v1", lifecycle.DefaultOptions())
	if err == nil {
		t.Errorf("expected trimTo with empty destPath to fail")
	}

	err = optimizeTo("", nil, nil, nil, lifecycle.DefaultOptions())
	if err == nil {
		t.Errorf("expected optimizeTo with empty destPath to fail")
	}
}

func TestExtractVariantAndOptimize(t *testing.T) {
	tempDir := t.TempDir()

	// Create dummy compressed file
	payloadData := []byte("HELLO EXECUTABLE PAYLOAD")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	// Test extractVariantToWriter
	var buf bytes.Buffer
	if err := extractVariantToWriter(rawFile, entry, nil, &buf); err != nil {
		t.Fatalf("extractVariantToWriter failed: %v", err)
	}
	if !bytes.Equal(buf.Bytes(), payloadData) {
		t.Errorf("extracted payload mismatch: got %q, expected %q", buf.String(), string(payloadData))
	}

	// Test optimizeTo
	destPath := filepath.Join(tempDir, "sub", "extracted_binary")
	if err := optimizeTo(destPath, rawFile, entry, nil, lifecycle.DefaultOptions()); err != nil {
		t.Fatalf("optimizeTo failed: %v", err)
	}

	readBack, err := os.ReadFile(destPath)
	if err != nil {
		t.Fatalf("reading back optimized binary: %v", err)
	}
	if !bytes.Equal(readBack, payloadData) {
		t.Errorf("materialized binary content mismatch: got %q", string(readBack))
	}

	// Test optimizeInPlace
	replaceTarget := filepath.Join(tempDir, "to_replace")
	_ = os.Link(rawFile.Name(), replaceTarget)
	breakOpts := lifecycle.DefaultOptions()
	breakOpts.BreakHardlinks = true
	if err := optimizeInPlace(replaceTarget, rawFile, entry, nil, breakOpts); err != nil {
		t.Fatalf("optimizeInPlace failed: %v", err)
	}
	readReplaced, _ := os.ReadFile(replaceTarget)
	if !bytes.Equal(readReplaced, payloadData) {
		t.Errorf("optimizeInPlace content mismatch: got %q", string(readReplaced))
	}
}

func TestTrimToAndInPlace(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-bytes-data"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	_ = os.WriteFile(v1Path, []byte("variant-v1-bytes-long-content"), 0o755)

	fatPath := filepath.Join(tempDir, "fat_app")
	_, err := pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "testapp",
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Path},
	})
	if err != nil {
		t.Fatalf("pack failed: %v", err)
	}

	fatFile, err := os.Open(fatPath)
	if err != nil {
		t.Fatalf("open fat file: %v", err)
	}
	defer func() { _ = fatFile.Close() }()

	stat, _ := fatFile.Stat()

	// Test trimTo
	trimmedTarget := filepath.Join(tempDir, "sub2", "trimmed_app")
	if err := trimTo(trimmedTarget, fatFile, stat.Size(), "v1", lifecycle.DefaultOptions()); err != nil {
		t.Fatalf("trimTo failed: %v", err)
	}

	// Test trimInPlace on a copy
	copyPath := filepath.Join(tempDir, "fat_copy")
	data, _ := os.ReadFile(fatPath)
	_ = os.WriteFile(copyPath, data, 0o755)
	copyFile, _ := os.Open(copyPath)
	defer func() { _ = copyFile.Close() }()

	if err := trimInPlace(copyPath, copyFile, stat.Size(), "v1", lifecycle.DefaultOptions()); err != nil {
		t.Fatalf("trimInPlace failed: %v", err)
	}

	// The first trim replaced the inode. Reopen before a deliberate second transformation.
	_ = copyFile.Close()
	copyFile, err = os.Open(copyPath)
	if err != nil {
		t.Fatal(err)
	}
	// Test trimInPlace via symlink
	symPath := filepath.Join(tempDir, "fat_symlink")
	if err := os.Symlink(copyPath, symPath); err != nil {
		t.Fatalf("creating symlink: %v", err)
	}
	if err := trimInPlace(symPath, copyFile, stat.Size(), "v1", lifecycle.DefaultOptions()); err != nil {
		t.Fatalf("trimInPlace on symlink failed: %v", err)
	}
}

func TestRunBinaryMetaCommands(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-bytes-data"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	_ = os.WriteFile(v1Path, []byte("v1-bytes-data"), 0o755)

	fatPath := filepath.Join(tempDir, "fat_runner_app")
	_, err := pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "runnertest",
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Path},
	})
	require.NoError(t, err, "pack failed")

	oldArgs := os.Args
	defer func() { os.Args = oldArgs }()

	// 1. --microfat:help
	os.Args = []string{fatPath, "--microfat:help"}
	require.NoError(t, runBinary(fatPath), "runBinary --microfat:help failed")

	// 2. --microfat:info
	os.Args = []string{fatPath, "--microfat:info"}
	require.NoError(t, runBinary(fatPath), "runBinary --microfat:info failed")

	// 3. --microfat:trim-to
	destTrim := filepath.Join(tempDir, "trimmed_via_run")
	os.Args = []string{fatPath, "--microfat:trim-to=" + destTrim}
	require.NoError(t, runBinary(fatPath), "runBinary --microfat:trim-to failed")

	// 3b. --microfat:specialize-to alias
	destSpec := filepath.Join(tempDir, "specialized_via_run")
	os.Args = []string{fatPath, "--microfat:specialize-to=" + destSpec}
	require.NoError(t, runBinary(fatPath), "runBinary --microfat:specialize-to failed")

	// 3c. --microfat:trim-to without argument
	os.Args = []string{fatPath, "--microfat:trim-to"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error when --microfat:trim-to has no target path")
	}

	// 3d. --microfat:trim-to with separate target path argument
	destTrimSep := filepath.Join(tempDir, "trimmed_via_run_sep")
	os.Args = []string{fatPath, "--microfat:trim-to", destTrimSep}
	require.NoError(t, runBinary(fatPath), "runBinary --microfat:trim-to separate arg failed")

	// 4. --microfat:optimize-to
	destOpt := filepath.Join(tempDir, "optimized_via_run")
	os.Args = []string{fatPath, "--microfat:optimize-to=" + destOpt}
	require.NoError(t, runBinary(fatPath), "runBinary --microfat:optimize-to failed")

	// 4b. --microfat:optimize-to without path
	os.Args = []string{fatPath, "--microfat:optimize-to"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error when --microfat:optimize-to has no target path")
	}

	// 4c. --microfat:optimize-to with separate arg
	destOptSep := filepath.Join(tempDir, "optimized_via_run_sep")
	os.Args = []string{fatPath, "--microfat:optimize-to", destOptSep}
	require.NoError(t, runBinary(fatPath), "runBinary --microfat:optimize-to separate arg failed")

	// 4d. --microfat:optimize-to with forbidden path
	os.Args = []string{fatPath, "--microfat:optimize-to=/dev/null/forbidden/opt"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error on --microfat:optimize-to with forbidden path")
	}

	// 4e. --microfat:trim-to with forbidden path
	os.Args = []string{fatPath, "--microfat:trim-to=/dev/null/forbidden/trim"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error on --microfat:trim-to with forbidden path")
	}

	// 5. --microfat:trim in-place on a copy
	copyFat := filepath.Join(tempDir, "fat_for_trim")
	data, _ := os.ReadFile(fatPath)
	_ = os.WriteFile(copyFat, data, 0o755)
	os.Args = []string{copyFat, "--microfat:trim"}
	require.NoError(t, runBinary(copyFat), "runBinary --microfat:trim failed")

	// 5b. --microfat:trim in read-only directory
	roDir := filepath.Join(tempDir, "ro_run_dir")
	_ = os.MkdirAll(roDir, 0o755)
	roFat := filepath.Join(roDir, "ro_fat")
	_ = os.WriteFile(roFat, data, 0o755)
	_ = os.Chmod(roDir, 0o555)
	defer func() { _ = os.Chmod(roDir, 0o755) }()
	os.Args = []string{roFat, "--microfat:trim"}
	if err := runBinary(roFat); err == nil {
		t.Errorf("expected error on --microfat:trim in read-only directory")
	}

	// 6. --microfat:optimize in-place on a copy
	copyFat2 := filepath.Join(tempDir, "fat_for_opt")
	_ = os.WriteFile(copyFat2, data, 0o755)
	os.Args = []string{copyFat2, "--microfat:optimize"}
	require.NoError(t, runBinary(copyFat2), "runBinary --microfat:optimize failed")

	// 6b. --microfat:optimize in read-only directory
	os.Args = []string{roFat, "--microfat:optimize"}
	if err := runBinary(roFat); err == nil {
		t.Errorf("expected error on --microfat:optimize in read-only directory")
	}

	// 7. Transparent application argument forwarding
	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return nil
	}
	os.Args = []string{fatPath, "myarg1", "--flag"}
	require.NoError(t, runBinary(fatPath), "runBinary standard execution failed")

	// 8. Invalid metadata policy flag fails fast
	os.Args = []string{fatPath, "--microfat:trim", "--microfat:metadata-policy=invalid"}
	require.Error(t, runBinary(fatPath), "expected error on invalid metadata-policy")

	// 8. Error cases
	os.Args = []string{stubPath, "--microfat:info"}
	if err := runBinary(stubPath); err == nil {
		t.Errorf("expected error running non-fat binary")
	}

	if err := runBinary(filepath.Join(tempDir, "nonexistent")); err == nil {
		t.Errorf("expected error running non-existent binary")
	}

	// 9. Incompatible architecture fat binary
	incompatibleFat := filepath.Join(tempDir, "fat_incompatible")
	_, _ = pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        incompatibleFat,
		TargetArch:        "unknown_arch_xyz",
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Path},
	})
	if err := runBinary(incompatibleFat); err == nil {
		t.Errorf("expected error running fat binary with incompatible arch")
	}
}

func TestExecuteVariantExecutionPaths(t *testing.T) {
	tempDir := t.TempDir()
	oldExisting := resolveExistingCacheDirFunc
	t.Cleanup(func() { resolveExistingCacheDirFunc = oldExisting })
	resolveExistingCacheDirFunc = func(string) (int, string, error) { return -1, "", os.ErrNotExist }
	payloadData := []byte("PAYLOAD_EXEC_TEST")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()

	// 1. Successful memfd execve
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return nil
	}
	policyRes := microarch.PolicyResult{}
	if err := executeVariant(
		rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now(),
	); err != nil {
		t.Errorf("expected success for executeVariant, got %v", err)
	}

	// 2. Fallback to cache when memfd execution returns error
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return errors.New("simulated execve error")
	}
	err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
	if err == nil || !strings.Contains(err.Error(), "cache fallback execve failed") {
		t.Errorf("expected cache fallback error, got %v", err)
	}

	// 3. Fallback to cache when cached binary already exists
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return nil
	}
	if err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	); err != nil {
		t.Errorf("expected success for existing cached binary, got %v", err)
	}

	// 4. Fallback to cache with fresh cache directory extraction
	freshCacheDir := filepath.Join(tempDir, "fresh_cache_dir")
	t.Setenv("XDG_CACHE_HOME", freshCacheDir)
	if err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	); err != nil {
		t.Errorf("expected success for fresh cache directory extraction, got %v", err)
	}

	// 5. Fallback when XDG_CACHE_HOME is empty (uses user home dir)
	t.Setenv("XDG_CACHE_HOME", "")
	if err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	); err != nil {
		t.Errorf("expected success when XDG_CACHE_HOME is empty, got %v", err)
	}

	// 5b. Fallback when XDG_CACHE_HOME is empty and userHomeDirFunc fails (uses os.TempDir())
	oldHome := userHomeDirFunc
	defer func() { userHomeDirFunc = oldHome }()
	userHomeDirFunc = func() (string, error) {
		return "", errors.New("no home dir")
	}
	if err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	); err != nil {
		t.Errorf("expected success when userHomeDir fails, got %v", err)
	}
	userHomeDirFunc = oldHome

	// 6. Fallback when primary cacheDir cannot be created (forbidden path)
	t.Setenv("XDG_CACHE_HOME", "/dev/null/forbidden_path")
	if err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	); err != nil {
		t.Errorf("expected success falling back to /tmp/.microfat-uid, got %v", err)
	}

	// 6b. Fallback failure when both primary and secondary cacheDir cannot be created
	t.Setenv("XDG_CACHE_HOME", "/dev/null/forbidden_primary")
	t.Setenv("TMPDIR", "/dev/null/forbidden_secondary")
	if err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	); err == nil {
		t.Errorf("expected error when both cache directories cannot be created")
	}
	t.Setenv("TMPDIR", "")

	// 7. Error extracting variant to cache fallback
	badEntryCache := &format.VariantEntry{
		Level: "v1", Offset: 0, CompressedSize: 10, UncompressedSize: 50, SHA256: "unique_bad_hash_123",
	}
	t.Setenv("XDG_CACHE_HOME", filepath.Join(tempDir, "bad_cache_extract"))
	err = executeViaCache(
		rawFile.Name(), rawFile, badEntryCache, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	)
	if err == nil {
		t.Errorf("expected error extracting invalid entry in executeViaCache")
	}

	// 8. Error creating temp file in read-only cache dir
	roCacheDir := filepath.Join(tempDir, "ro_cache_dir")
	_ = os.MkdirAll(filepath.Join(roCacheDir, "microfat"), 0o755)
	_ = os.Chmod(filepath.Join(roCacheDir, "microfat"), 0o555)
	defer func() { _ = os.Chmod(filepath.Join(roCacheDir, "microfat"), 0o755) }()
	t.Setenv("XDG_CACHE_HOME", roCacheDir)
	newHashEntry := &format.VariantEntry{
		Level: "v1", Offset: 0, CompressedSize: 10, UncompressedSize: 50, SHA256: "brand_new_hash_456",
	}
	err = executeViaCache(
		rawFile.Name(), rawFile, newHashEntry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, errors.New("memfd err"), time.Now(),
	)
	if err == nil {
		t.Errorf("expected error when cache dir is not writable")
	}

	// 9. Error in executeViaMemfd when variant extraction fails
	if err := executeViaMemfd(
		rawFile.Name(), rawFile, badEntryCache, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now(),
	); err == nil {
		t.Errorf("expected error in executeViaMemfd when extractVariantToWriter fails")
	}

	// 10. Error in executeViaMemfd when execve fails
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return errors.New("memfd execve failed")
	}
	if err := executeViaMemfd(
		rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now(),
	); err == nil {
		t.Errorf("expected error in executeViaMemfd when execve returns error")
	}
}

func TestOptimizeInPlaceSymlink(t *testing.T) {
	tempDir := t.TempDir()
	payloadData := []byte("OPTIMIZE_SYMLINK_TEST")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	realTarget := filepath.Join(tempDir, "real_opt_file")
	_ = os.Link(rawFile.Name(), realTarget)

	symTarget := filepath.Join(tempDir, "sym_opt_file")
	if err := os.Symlink(realTarget, symTarget); err != nil {
		t.Fatalf("creating symlink: %v", err)
	}

	breakOptsReal := lifecycle.DefaultOptions()
	breakOptsReal.BreakHardlinks = true
	if err := optimizeInPlace(symTarget, rawFile, entry, nil, breakOptsReal); err != nil {
		t.Fatalf("optimizeInPlace on symlink failed: %v", err)
	}

	content, _ := os.ReadFile(realTarget)
	if !bytes.Equal(content, payloadData) {
		t.Errorf("optimizeInPlace on symlink did not update target: got %q", string(content))
	}

	// Test extractVariantToWriter with wrong UncompressedSize
	entrySizeMismatch := &format.VariantEntry{
		Level:            entry.Level,
		Offset:           entry.Offset,
		CompressedSize:   entry.CompressedSize,
		UncompressedSize: entry.UncompressedSize + 100, // wrong size
	}
	var dummyBuf bytes.Buffer
	if err := extractVariantToWriter(rawFile, entrySizeMismatch, nil, &dummyBuf); err == nil {
		t.Errorf("expected error on uncompressed size mismatch")
	}

	// Test optimizeTo and trimTo error on invalid destination directory
	if err := optimizeTo("/dev/null/forbidden/bin", rawFile, entry, nil, lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected optimizeTo to fail on invalid destination directory")
	}
	if err := trimTo("/dev/null/forbidden/bin", rawFile, 1000, "v1", lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected trimTo to fail on invalid destination directory")
	}

	// Test optimizeInPlace and trimInPlace in read-only directory
	roDir := filepath.Join(tempDir, "readonly_dir")
	_ = os.MkdirAll(roDir, 0o755)
	roFile := filepath.Join(roDir, "ro_app")
	_ = os.WriteFile(roFile, []byte("data"), 0o755)
	_ = os.Chmod(roDir, 0o555)
	defer func() { _ = os.Chmod(roDir, 0o755) }()

	if err := optimizeInPlace(roFile, rawFile, entry, nil, lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected optimizeInPlace to fail in read-only directory")
	}
	if err := trimInPlace(roFile, rawFile, 1000, "v1", lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected trimInPlace to fail in read-only directory")
	}

	// Test optimizeInPlace and trimInPlace when selfPath is a directory (rename error)
	dirTarget := filepath.Join(tempDir, "existing_target_dir")
	_ = os.MkdirAll(dirTarget, 0o755)
	if err := optimizeInPlace(dirTarget, rawFile, entry, nil, lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected optimizeInPlace to fail when selfPath is directory")
	}
	if err := trimInPlace(dirTarget, rawFile, 1000, "v1", lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected trimInPlace to fail when selfPath is directory")
	}

	// Test optimizeTo with invalid entry
	badEntry := &format.VariantEntry{Level: "v1", Offset: 0, CompressedSize: 10, UncompressedSize: 50}
	if err := optimizeTo(filepath.Join(tempDir, "bad_opt"), rawFile, badEntry, nil, lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected optimizeTo with bad entry to fail")
	}

	// Test optimizeTo when destination is an existing directory
	if err := optimizeTo(tempDir, rawFile, entry, nil, lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected optimizeTo to fail when target is directory")
	}

	// Test trimTo with invalid variant level
	if err := trimTo(filepath.Join(tempDir, "bad_trim"), rawFile, 1000, "nonexistent", lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected trimTo with nonexistent variant to fail")
	}

	// Test trimTo when destination is an existing directory
	if err := trimTo(tempDir, rawFile, 1000, "v1", lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected trimTo to fail when target is directory")
	}
}

func TestRunBinarySpecializeAndRun(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("stub-bytes"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	_ = os.WriteFile(v1Path, []byte("v1-bytes"), 0o755)

	fatPath := filepath.Join(tempDir, "fat_specialize_app")
	_, err := pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "specializeapp",
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Path},
	})
	if err != nil {
		t.Fatalf("pack failed: %v", err)
	}

	oldArgs := os.Args
	defer func() { os.Args = oldArgs }()

	// 1. --microfat:specialize
	copyFat := filepath.Join(tempDir, "fat_copy_specialize")
	data, _ := os.ReadFile(fatPath)
	_ = os.WriteFile(copyFat, data, 0o755)
	os.Args = []string{copyFat, "--microfat:specialize"}
	if err := runBinary(copyFat); err != nil {
		t.Fatalf("runBinary --microfat:specialize failed: %v", err)
	}

	// 2. --microfat:specialize-to
	destSpec := filepath.Join(tempDir, "specialize_to_out")
	os.Args = []string{fatPath, "--microfat:specialize-to=" + destSpec}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("runBinary --microfat:specialize-to failed: %v", err)
	}

	// 3. run() when current test binary is not fat binary
	_ = run()

	// 3b. run() when resolving executable path fails
	oldGetSelf := getSelfExecutablePathFunc
	defer func() { getSelfExecutablePathFunc = oldGetSelf }()
	getSelfExecutablePathFunc = func() (string, error) {
		return "", errors.New("cannot determine executable path")
	}
	if err := run(); err == nil {
		t.Errorf("expected error when getSelfExecutablePathFunc fails")
	}

	// 4. main() invocation
	oldExit := exitFunc
	defer func() { exitFunc = oldExit }()
	exitCalled := false
	exitFunc = func(code int) {
		exitCalled = true
	}
	main()
	if !exitCalled {
		t.Errorf("expected exitFunc to be called from main() on non-fat binary")
	}

	// 4b. main() with MICROFAT_LOG=json
	t.Setenv("MICROFAT_LOG", "json")
	exitCalled = false
	main()
	if !exitCalled {
		t.Errorf("expected exitFunc to be called from main() with json log")
	}
	t.Setenv("MICROFAT_LOG", "")
}

func TestTrimAndOptimizeErrorPaths(t *testing.T) {
	tempDir := t.TempDir()

	// 1. Create a dummy file with corrupted payload bytes
	corruptContainer := filepath.Join(tempDir, "corrupt_container")
	corruptFile, err := os.OpenFile(corruptContainer, os.O_CREATE|os.O_RDWR, 0o755)
	if err != nil {
		t.Fatalf("creating corrupt file: %v", err)
	}
	defer func() { _ = corruptFile.Close() }()

	_, _ = corruptFile.WriteAt([]byte("THIS IS NOT VALID ZSTD DATA 1234567890"), 50)
	corruptEntry := &format.VariantEntry{
		Level:            "v1",
		Offset:           50,
		CompressedSize:   30,
		UncompressedSize: 100,
	}

	// Test extractVariantToWriter error on corrupted zstd stream
	var dummyBuf bytes.Buffer
	if err := extractVariantToWriter(corruptFile, corruptEntry, nil, &dummyBuf); err == nil {
		t.Errorf("expected extractVariantToWriter to fail on corrupt zstd data")
	}

	// Test optimizeInPlace error when extractVariantToWriter fails
	optTarget := filepath.Join(tempDir, "opt_target")
	_ = os.Link(corruptFile.Name(), optTarget)
	breakOptsCorrupt := lifecycle.DefaultOptions()
	breakOptsCorrupt.BreakHardlinks = true
	if err := optimizeInPlace(optTarget, corruptFile, corruptEntry, nil, breakOptsCorrupt); err == nil {
		t.Errorf("expected optimizeInPlace to fail on corrupt variant")
	}

	// Test optimizeTo error when extractVariantToWriter fails
	if err := optimizeTo(filepath.Join(tempDir, "opt_to_corrupt"), corruptFile, corruptEntry, nil, lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected optimizeTo to fail on corrupt variant")
	}

	// 2. Test trimInPlace error when pack.TrimBinary fails (invalid level)
	stubPath := filepath.Join(tempDir, "stub_err")
	_ = os.WriteFile(stubPath, []byte("stub-bytes"), 0o755)
	v1Path := filepath.Join(tempDir, "v1_err")
	_ = os.WriteFile(v1Path, []byte("v1-bytes"), 0o755)

	fatErrPath := filepath.Join(tempDir, "fat_err_app")
	_, err = pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatErrPath,
		AppName:           "errtest",
		SkipELFValidation: true,
		Variants:          map[string]string{"v1": v1Path},
	})
	if err != nil {
		t.Fatalf("pack failed: %v", err)
	}

	fatErrFile, err := os.Open(fatErrPath)
	if err != nil {
		t.Fatalf("open fat file: %v", err)
	}
	defer func() { _ = fatErrFile.Close() }()

	stat, _ := fatErrFile.Stat()

	// trimTo with nonexistent variant
	trimmedErrOut := filepath.Join(tempDir, "trimmed_err_out")
	if err := trimTo(trimmedErrOut, fatErrFile, stat.Size(), "nonexistent_variant_level", lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected trimTo to fail with nonexistent variant level")
	}

	// Test optimizeInPlace and trimInPlace when rename fails (target is non-empty dir)
	targetNonEmptyDir := filepath.Join(tempDir, "non_empty_dir")
	_ = os.MkdirAll(filepath.Join(targetNonEmptyDir, "nested"), 0o755)
	if err := optimizeInPlace(targetNonEmptyDir, corruptFile, corruptEntry, nil, lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected optimizeInPlace to fail when target is non-empty directory")
	}
	if err := trimInPlace(targetNonEmptyDir, fatErrFile, stat.Size(), "v1", lifecycle.DefaultOptions()); err == nil {
		t.Errorf("expected trimInPlace to fail when target is non-empty directory")
	}
}

func createDummyVariantFile(t *testing.T, dir string, content []byte) (*format.VariantEntry, *os.File) {
	t.Helper()
	filePath := filepath.Join(dir, "dummy_container")
	f, err := os.OpenFile(filePath, os.O_CREATE|os.O_RDWR, 0o755)
	if err != nil {
		t.Fatalf("creating dummy file: %v", err)
	}

	// Compress content with zstd
	var zstdBuf bytes.Buffer
	enc, err := zstd.NewWriter(&zstdBuf)
	if err != nil {
		t.Fatalf("creating zstd encoder: %v", err)
	}
	if _, err := enc.Write(content); err != nil {
		t.Fatalf("writing zstd: %v", err)
	}
	if err := enc.Close(); err != nil {
		t.Fatalf("closing zstd: %v", err)
	}

	offset := int64(100)
	if _, err := f.WriteAt(zstdBuf.Bytes(), offset); err != nil {
		t.Fatalf("writing at offset: %v", err)
	}

	hash := sha256.Sum256(content)
	entry := &format.VariantEntry{
		Level:            "v1",
		Offset:           offset,
		CompressedSize:   int64(zstdBuf.Len()),
		UncompressedSize: int64(len(content)),
		SHA256:           hex.EncodeToString(hash[:]),
	}

	return entry, f
}

func TestPolicyDispatchIntegration(t *testing.T) {
	tempDir := t.TempDir()
	fatPath := filepath.Join(tempDir, "policy_app_fat")

	stubPath := filepath.Join(tempDir, "stub_binary")
	require.NoError(t, os.WriteFile(stubPath, []byte("\x7fELF_DUMMY_STUB"), 0o755), "writing stub")

	v1Path := filepath.Join(tempDir, "app_v1")
	v2Path := filepath.Join(tempDir, "app_v2")
	v3Path := filepath.Join(tempDir, "app_v3")
	require.NoError(t, os.WriteFile(v1Path, []byte("\x7fELF_PAYLOAD_V1"), 0o755), "writing v1")
	require.NoError(t, os.WriteFile(v2Path, []byte("\x7fELF_PAYLOAD_V2"), 0o755), "writing v2")
	require.NoError(t, os.WriteFile(v3Path, []byte("\x7fELF_PAYLOAD_V3"), 0o755), "writing v3")

	opts := pack.Options{
		StubPath:   stubPath,
		OutputPath: fatPath,
		AppName:    "policyapp",
		TargetOS:   testOSLinux,
		TargetArch: testArchAMD64,
		Variants: map[string]string{
			"v1": v1Path,
			"v2": v2Path,
			"v3": v3Path,
		},
		SkipELFValidation: true,
	}
	if _, err := pack.Pack(opts); err != nil {
		t.Fatalf("packaging fat binary: %v", err)
	}

	var lastExecVariant string
	var lastPolicyApplied string
	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		for _, e := range envv {
			if after, ok := strings.CutPrefix(e, "MICROFAT_SELECTED_VARIANT="); ok {
				lastExecVariant = after
			}
			if after, ok := strings.CutPrefix(e, "MICROFAT_POLICY_APPLIED="); ok {
				lastPolicyApplied = after
			}
		}
		return nil
	}

	oldArgs := os.Args
	defer func() { os.Args = oldArgs }()
	os.Args = []string{fatPath}

	// 1. Force Level v1
	t.Setenv(format.EnvForceLevel, "v1")
	t.Setenv(format.EnvMaxLevel, "")
	t.Setenv(format.EnvDisableVariants, "")
	require.NoError(t, runBinary(fatPath), "runBinary force v1 failed")
	if lastExecVariant != "v1" || lastPolicyApplied != testPolicyForceLevel {
		t.Errorf("expected force v1, got variant=%s policy=%s", lastExecVariant, lastPolicyApplied)
	}

	// 2. Max Level v2
	t.Setenv(format.EnvForceLevel, "")
	t.Setenv(format.EnvMaxLevel, "v2")
	t.Setenv(format.EnvDisableVariants, "")
	lastPolicyApplied = ""
	require.NoError(t, runBinary(fatPath), "runBinary max v2 failed")
	if lastExecVariant != "v2" || lastPolicyApplied != "max_level" {
		t.Errorf("expected max v2, got variant=%s policy=%s", lastExecVariant, lastPolicyApplied)
	}

	// 3. Disable Variant v3
	t.Setenv(format.EnvForceLevel, "")
	t.Setenv(format.EnvMaxLevel, "")
	t.Setenv(format.EnvDisableVariants, "v3")
	lastPolicyApplied = ""
	require.NoError(t, runBinary(fatPath), "runBinary disable v3 failed")
	if lastExecVariant != "v2" || lastPolicyApplied != "disable_variants" {
		t.Errorf("expected disable v3 to select v2, got variant=%s policy=%s", lastExecVariant, lastPolicyApplied)
	}
}

func TestStubPrewarmAndCacheDispatch(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("#!/bin/sh\n"), 0o755)
	v1Path := filepath.Join(tempDir, "v1")
	v2Path := filepath.Join(tempDir, "v2")
	_ = os.WriteFile(v1Path, []byte("#!/bin/sh\necho v1\n"), 0o755)
	_ = os.WriteFile(v2Path, []byte("#!/bin/sh\necho v2\n"), 0o755)

	fatPath := filepath.Join(tempDir, "prewarm_stub.fat")
	_, err := pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "stubprewarmapp",
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Variants: map[string]string{
			"v1": v1Path,
			"v2": v2Path,
		},
	})
	require.NoError(t, err, "packing test binary")

	oldArgs := os.Args
	defer func() { os.Args = oldArgs }()

	cacheDir := filepath.Join(tempDir, "stub_cache")
	t.Setenv(format.EnvCacheDir, cacheDir)

	// 1. Default --microfat:prewarm
	os.Args = []string{fatPath, flagPrewarm}
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm failed")

	// 2. Second time default --microfat:prewarm (already cached path)
	require.NoError(t, runBinary(fatPath), "second --microfat:prewarm failed")

	// 3. --microfat:prewarm=all
	os.Args = []string{fatPath, "--microfat:prewarm=all"}
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm=all failed")

	// 4. --microfat:prewarm=v1
	os.Args = []string{fatPath, "--microfat:prewarm=v1"}
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm=v1 failed")

	// 4a. Multi-variant comma-separated --microfat:prewarm=v1,v2
	os.Args = []string{fatPath, "--microfat:prewarm=v1,v2"}
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm=v1,v2 failed")

	// 4b. Multi-variant with all and duplicates --microfat:prewarm=all,v1
	os.Args = []string{fatPath, "--microfat:prewarm=all,v1"}
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm=all,v1 failed")

	// 5. --microfat:prewarm=json
	os.Args = []string{fatPath, "--microfat:prewarm=json"}
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm=json failed")

	// 5a. Multi-variant with json modifier --microfat:prewarm=v1,v2,json
	os.Args = []string{fatPath, "--microfat:prewarm=v1,v2,json"}
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm=v1,v2,json failed")

	// 6. --microfat:prewarm with --json flag and MICROFAT_LOG=json
	os.Args = []string{fatPath, flagPrewarm, "--json"}
	t.Setenv(format.EnvLog, "json")
	require.NoError(t, runBinary(fatPath), "--microfat:prewarm with MICROFAT_LOG=json failed")
	t.Setenv(format.EnvLog, "")

	// 7. --microfat:prewarm with non-existent level
	os.Args = []string{fatPath, "--microfat:prewarm=v99"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error for --microfat:prewarm=v99")
	}

	// 8. Cache resolution error during prewarm
	oldResolver := resolveCacheDirFunc
	defer func() { resolveCacheDirFunc = oldResolver }()
	resolveCacheDirFunc = func(string) (int, string, error) {
		return -1, "", errors.New("cache init failed")
	}
	os.Args = []string{fatPath, flagPrewarm}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error when cache resolution fails")
	}
	resolveCacheDirFunc = oldResolver

	// 9. Runtime cache execution dispatch with MICROFAT_EXEC_MODE=cache
	var executedPath string
	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		if link, err := os.Readlink(argv0); err == nil {
			executedPath = strings.TrimSuffix(link, " (deleted)")
		} else {
			executedPath = argv0
		}
		return nil
	}

	os.Args = []string{fatPath, "arg1"}
	t.Setenv(format.EnvExecMode, format.ExecModeCache)
	require.NoError(t, runBinary(fatPath), "runBinary with MICROFAT_EXEC_MODE=cache failed")
	if !strings.Contains(executedPath, cacheDir) {
		t.Errorf("expected execve from cacheDir %s, got %s", cacheDir, executedPath)
	}

	// 10. Runtime cache execution dispatch with MICROFAT_DISPATCH_MODE=cache
	t.Setenv(format.EnvExecMode, "")
	t.Setenv(format.EnvDispatchMode, format.ExecModeCache)
	executedPath = ""
	require.NoError(t, runBinary(fatPath), "runBinary with MICROFAT_DISPATCH_MODE=cache failed")
	if !strings.Contains(executedPath, cacheDir) {
		t.Errorf("expected execve from cacheDir %s, got %s", cacheDir, executedPath)
	}
	t.Setenv(format.EnvDispatchMode, "")

	// 11. Runtime cache execution failing execve when primaryErr is nil
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return errors.New("execve failed permission")
	}
	t.Setenv(format.EnvExecMode, format.ExecModeCache)
	if err := runBinary(fatPath); err == nil || !strings.Contains(err.Error(), "cache execve failed") {
		t.Errorf("expected 'cache execve failed' error, got %v", err)
	}
	t.Setenv(format.EnvExecMode, "")
}

func TestExecuteVariant_SyscallMocking(t *testing.T) {
	tempDir := t.TempDir()
	payloadData := []byte("PAYLOAD_SYSCALL_MOCK_TEST")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	cacheDir := filepath.Join(tempDir, "mock_cache")
	t.Setenv(format.EnvCacheDir, cacheDir)

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	oldMemfd := memfdCreateFunc
	oldExec := execveFunc
	defer func() {
		memfdCreateFunc = oldMemfd
		execveFunc = oldExec
	}()

	tests := []struct {
		name     string
		memfdErr error
	}{
		{"EPERM seccomp blocked", syscall.EPERM},
		{"ENOSYS kernel unsupported", syscall.ENOSYS},
		{"EMFILE descriptor exhaustion", syscall.EMFILE},
		{"EACCES permission denied", syscall.EACCES},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			memfdCreateFunc = func(name string, flags int) (int, error) {
				return -1, tc.memfdErr
			}

			var executedBinary string
			execveFunc = func(argv0 string, argv []string, envv []string) error {
				if link, err := os.Readlink(argv0); err == nil {
					executedBinary = strings.TrimSuffix(link, " (deleted)")
				} else {
					executedBinary = argv0
				}
				return nil
			}

			err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
			if err != nil {
				t.Fatalf("expected graceful fallback to cache, got error: %v", err)
			}

			if !strings.Contains(executedBinary, cacheDir) {
				t.Errorf("expected execve on cached binary in %s, got %s", cacheDir, executedBinary)
			}
		})
	}
}

func TestExecuteVariant_TruncatedCacheRecovery(t *testing.T) {
	tempDir := t.TempDir()
	payloadData := []byte("TRUNCATED_RECOVERY_PAYLOAD_CONTENT_12345")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	cacheDir := filepath.Join(tempDir, "recovery_cache")
	t.Setenv(format.EnvCacheDir, cacheDir)
	_ = os.MkdirAll(cacheDir, 0o700)

	cachedPath := filepath.Join(cacheDir, entry.SHA256)

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()

	var executedPath string
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		if link, err := os.Readlink(argv0); err == nil {
			executedPath = strings.TrimSuffix(link, " (deleted)")
		} else {
			executedPath = argv0
		}
		return nil
	}

	// 1. Zero-byte truncated cache file
	_ = os.WriteFile(cachedPath, []byte{}, 0o755)

	t.Setenv(format.EnvDebug, "1")
	err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, nil, time.Now(),
	)
	if err != nil {
		t.Fatalf("executeViaCache failed on zero-byte cache file: %v", err)
	}
	if executedPath != cachedPath {
		t.Errorf("expected execution of %s, got %s", cachedPath, executedPath)
	}

	// Verify cached file was replaced with full content
	data, err := os.ReadFile(cachedPath)
	if err != nil || !bytes.Equal(data, payloadData) {
		t.Errorf("expected cached file to be restored to payload content, got %q (err: %v)", string(data), err)
	}

	// 2. Partial/corrupted size cache file (half length)
	_ = os.WriteFile(cachedPath, payloadData[:len(payloadData)/2], 0o755)
	executedPath = ""
	err = executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, nil, time.Now(),
	)
	if err != nil {
		t.Fatalf("executeViaCache failed on partial cache file: %v", err)
	}
	data2, err := os.ReadFile(cachedPath)
	if err != nil || !bytes.Equal(data2, payloadData) {
		t.Errorf("expected cached file to be restored after partial file corruption, got %q", string(data2))
	}
	t.Setenv(format.EnvDebug, "")
}

func TestPrewarmStub_VerifyMode(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub_vfy")
	_ = os.WriteFile(stubPath, []byte("#!/bin/sh\n"), 0o755)
	v1Path := filepath.Join(tempDir, "v1_vfy")
	v2Path := filepath.Join(tempDir, "v2_vfy")
	v1Data := []byte("#!/bin/sh\necho v1_vfy\n")
	v2Data := []byte("#!/bin/sh\necho v2_vfy\n")
	_ = os.WriteFile(v1Path, v1Data, 0o755)
	_ = os.WriteFile(v2Path, v2Data, 0o755)

	fatPath := filepath.Join(tempDir, "prewarm_verify.fat")
	idx, err := pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "verifyapp",
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		Variants: map[string]string{
			"v1": v1Path,
			"v2": v2Path,
		},
	})
	if err != nil {
		t.Fatalf("packing test binary: %v", err)
	}

	oldArgs := os.Args
	defer func() { os.Args = oldArgs }()

	cacheDir := filepath.Join(tempDir, "verify_cache")
	t.Setenv(format.EnvCacheDir, cacheDir)

	// 1. Verify clean cache (should fail with missing status)
	os.Args = []string{fatPath, "--microfat:prewarm=verify"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error running --microfat:prewarm=verify on clean cache")
	}

	// 2. Prewarm v1 and verify v1 (should succeed)
	os.Args = []string{fatPath, "--microfat:prewarm=v1"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("prewarming v1 failed: %v", err)
	}

	os.Args = []string{fatPath, "--microfat:prewarm=verify,v1"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("--microfat:prewarm=verify,v1 failed on valid cache: %v", err)
	}

	// 3. Verify all when only v1 is cached (should fail because v2 is missing)
	os.Args = []string{fatPath, "--microfat:prewarm=verify,all"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error verifying all when v2 is missing")
	}

	// 4. Prewarm all and verify all (should succeed)
	os.Args = []string{fatPath, "--microfat:prewarm=all"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("prewarming all failed: %v", err)
	}

	os.Args = []string{fatPath, "--microfat:prewarm=verify,all"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("--microfat:prewarm=verify,all failed on complete cache: %v", err)
	}

	// 4a. Verify multiple specific variants
	os.Args = []string{fatPath, "--microfat:prewarm=verify,v1,v2"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("--microfat:prewarm=verify,v1,v2 failed on complete cache: %v", err)
	}

	// 5. Verify mode with --json flag
	os.Args = []string{fatPath, "--microfat:prewarm=verify,all", "--json"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("--microfat:prewarm=verify,all with --json failed: %v", err)
	}

	// 6. Verify mode with standalone --verify in args
	os.Args = []string{fatPath, flagPrewarm, "--verify"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("--microfat:prewarm with --verify failed: %v", err)
	}

	// 7. Verify mode on corrupted cache entry (truncate v1)
	v1Entry, _ := idx.FindVariant("v1")
	v1Cached := filepath.Join(cacheDir, v1Entry.SHA256)
	_ = os.WriteFile(v1Cached, []byte("broken"), 0o755)

	os.Args = []string{fatPath, "--microfat:prewarm=verify,v1"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error verifying corrupted cache entry")
	}

	// 8. Verify mode on corrupted cache entry with JSON output
	os.Args = []string{fatPath, "--microfat:prewarm=verify,v1", "--json"}
	if err := runBinary(fatPath); err == nil {
		t.Errorf("expected error verifying corrupted cache entry with JSON output")
	}
}

func TestExecuteVariant_StrictEnvironmentMatrix(t *testing.T) {
	tempDir := t.TempDir()
	payloadData := []byte("STRICT_ENV_MATRIX_PAYLOAD")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	cacheDir := filepath.Join(tempDir, "matrix_cache")
	t.Setenv(format.EnvCacheDir, cacheDir)

	hostInfo := microarch.Info{
		OS:       testOSLinux,
		Arch:     testArchAMD64,
		Level:    "v3",
		Features: []string{"avx", "avx2", "bmi1", "bmi2", "fma"},
	}

	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()

	var capturedEnv []string
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		capturedEnv = envv
		return nil
	}

	t.Run("memfd execution strict env assertions", func(t *testing.T) {
		policyRes := microarch.PolicyResult{
			SelectedVariant: "v3",
			PolicyApplied:   testPolicyForceLevel,
			OverrideReason:  testForceLevelV3,
		}
		base := []string{"USER=deployer", "LANG=en_US.UTF-8"}

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, base, hostInfo, policyRes, time.Now())
		if err != nil {
			t.Fatalf("executeVariant failed: %v", err)
		}

		envMap := make(map[string]string)
		for _, e := range capturedEnv {
			parts := strings.SplitN(e, "=", 2)
			if len(parts) == 2 {
				envMap[parts[0]] = parts[1]
			}
		}

		expected := map[string]string{
			"USER":                    "deployer",
			"LANG":                    "en_US.UTF-8",
			format.EnvSelectedVariant: "v1",
			format.EnvHostArch:        testArchAMD64,
			format.EnvHostLevel:       "v3",
			format.EnvExecMode:        format.ExecModeMemfd,
			format.EnvDispatchMode:    format.ExecModeMemfd,
			format.EnvSelectedSHA256:  entry.SHA256,
			format.EnvSelectedSize:    fmt.Sprintf("%d", entry.UncompressedSize),
			format.EnvPolicyApplied:   testPolicyForceLevel,
			format.EnvOverrideReason:  testForceLevelV3,
		}

		for k, expVal := range expected {
			if val, ok := envMap[k]; !ok || val != expVal {
				t.Errorf("env key %s: expected %q, got %q (exists: %v)", k, expVal, val, ok)
			}
		}
	})
}

func TestExecuteVariant_TelemetryJSONValidation(t *testing.T) {
	tempDir := t.TempDir()
	payloadData := []byte("TELEMETRY_JSON_VALIDATION_PAYLOAD")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	cacheDir := filepath.Join(tempDir, "telem_cache")
	t.Setenv(format.EnvCacheDir, cacheDir)

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{PolicyApplied: "test_policy", OverrideReason: "test"}

	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return nil
	}

	// 1. DispatchTelemetry validation (JSON)
	t.Setenv(format.EnvLog, "json")
	var capturedOutput bytes.Buffer

	oldStderr := os.Stderr
	r, w, _ := os.Pipe()
	os.Stderr = w

	logDiagnostics(
		entry, format.ExecModeMemfd, hostInfo, policyRes, []string{"GOMEMLIMIT=1000B"}, nil,
		150*time.Microsecond, 500*time.Microsecond,
	)
	_ = w.Close()
	os.Stderr = oldStderr

	_, _ = io.Copy(&capturedOutput, r)
	outStr := strings.TrimSpace(capturedOutput.String())

	jsonPart := strings.TrimPrefix(outStr, "[microfat] ")
	var dt format.DispatchTelemetry
	if err := json.Unmarshal([]byte(jsonPart), &dt); err != nil {
		t.Fatalf("unmarshaling DispatchTelemetry JSON failed: %v (raw: %s)", err, outStr)
	}

	if dt.Event != format.EventDispatch || dt.HostArch != testArchAMD64 || dt.SelectedVariant != entry.Level {
		t.Errorf("DispatchTelemetry validation mismatch: %+v", dt)
	}
	if dt.TimestampUnixNano <= 0 || dt.DecompressionDurationUs <= 0 || dt.TotalLauncherUs <= 0 {
		t.Errorf("DispatchTelemetry invalid timestamps/durations: %+v", dt)
	}

	// 2. ErrorTelemetry validation (JSON)
	capturedOutput.Reset()
	r2, w2, _ := os.Pipe()
	os.Stderr = w2

	logErrorDiagnostics(format.StageMemfdCreate, syscall.EPERM, hostInfo, entry, policyRes, "mock details")
	_ = w2.Close()
	os.Stderr = oldStderr

	_, _ = io.Copy(&capturedOutput, r2)
	errStr := strings.TrimSpace(capturedOutput.String())
	errJSON := strings.TrimPrefix(errStr, "[microfat] ")

	var et format.ErrorTelemetry
	if err := json.Unmarshal([]byte(errJSON), &et); err != nil {
		t.Fatalf("unmarshaling ErrorTelemetry JSON failed: %v (raw: %s)", err, errStr)
	}

	if et.Event != format.EventError || et.Stage != format.StageMemfdCreate ||
		et.Error != syscall.EPERM.Error() || et.Details != "mock details" || et.Hint != format.HintMemfdSeccomp {
		t.Errorf("ErrorTelemetry validation mismatch: %+v", et)
	}

	t.Setenv(format.EnvLog, "")
}

func TestExecuteVariant_DiagnosticHints(t *testing.T) {
	oldExisting := resolveExistingCacheDirFunc
	t.Cleanup(func() { resolveExistingCacheDirFunc = oldExisting })
	resolveExistingCacheDirFunc = func(string) (int, string, error) { return -1, "", os.ErrNotExist }
	tempDir := t.TempDir()
	payloadData := []byte("DIAGNOSTIC_HINTS_PAYLOAD")
	entry, rawFile := createDummyVariantFile(t, tempDir, payloadData)
	defer func() { _ = rawFile.Close() }()

	cacheDir := filepath.Join(tempDir, "hint_cache")
	t.Setenv(format.EnvCacheDir, cacheDir)

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	oldMemfd := memfdCreateFunc
	oldExec := execveFunc
	defer func() {
		memfdCreateFunc = oldMemfd
		execveFunc = oldExec
	}()

	// 1. In default mode (no MICROFAT_DEBUG), non-fatal memfd fallback should NOT emit hints to stderr
	t.Run("suppressed in default mode", func(t *testing.T) {
		t.Setenv(format.EnvDebug, "")
		t.Setenv(format.EnvLog, "")

		memfdCreateFunc = func(name string, flags int) (int, error) {
			return -1, syscall.EPERM
		}
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			return nil
		}

		oldStderr := os.Stderr
		r, w, _ := os.Pipe()
		os.Stderr = w

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		_ = w.Close()
		os.Stderr = oldStderr

		var buf bytes.Buffer
		_, _ = io.Copy(&buf, r)

		if err != nil {
			t.Fatalf("expected fallback to succeed, got: %v", err)
		}
		if strings.Contains(buf.String(), "[microfat:hint]") {
			t.Errorf("expected no hint in default mode, got: %s", buf.String())
		}
	})

	// 2. In debug mode (MICROFAT_DEBUG=1), non-fatal memfd fallback should emit hints to stderr
	t.Run("emitted in debug mode", func(t *testing.T) {
		t.Setenv(format.EnvDebug, "1")
		t.Setenv(format.EnvLog, "")

		memfdCreateFunc = func(name string, flags int) (int, error) {
			return -1, syscall.EPERM
		}
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			return nil
		}

		oldStderr := os.Stderr
		r, w, _ := os.Pipe()
		os.Stderr = w

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		_ = w.Close()
		os.Stderr = oldStderr

		var buf bytes.Buffer
		_, _ = io.Copy(&buf, r)

		if err != nil {
			t.Fatalf("expected fallback to succeed, got: %v", err)
		}
		out := buf.String()
		if !strings.Contains(out, "[microfat:hint]") || !strings.Contains(out, "seccomp") {
			t.Errorf("expected seccomp hint in debug output, got: %s", out)
		}
	})

	// 3. ENOSYS in debug mode
	t.Run("enosys kernel hint in debug mode", func(t *testing.T) {
		t.Setenv(format.EnvDebug, "true")
		t.Setenv(format.EnvLog, "")

		memfdCreateFunc = func(name string, flags int) (int, error) {
			return -1, syscall.ENOSYS
		}
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			return nil
		}

		oldStderr := os.Stderr
		r, w, _ := os.Pipe()
		os.Stderr = w

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		_ = w.Close()
		os.Stderr = oldStderr

		var buf bytes.Buffer
		_, _ = io.Copy(&buf, r)

		if err != nil {
			t.Fatalf("expected fallback to succeed, got: %v", err)
		}
		out := buf.String()
		if !strings.Contains(out, "[microfat:hint]") || !strings.Contains(out, "unsupported on this Linux kernel") {
			t.Errorf("expected kernel unsupported hint, got: %s", out)
		}
	})
}

func TestMain_DiagnosticHints(t *testing.T) {
	oldExit := exitFunc
	defer func() { exitFunc = oldExit }()

	var exitCode int
	exitFunc = func(code int) {
		exitCode = code
	}

	oldGetSelf := getSelfExecutablePathFunc
	defer func() { getSelfExecutablePathFunc = oldGetSelf }()

	// 1. Fatal error without hint
	t.Run("fatal error without specific hint", func(t *testing.T) {
		t.Setenv(format.EnvLog, "")
		getSelfExecutablePathFunc = func() (string, error) {
			return "", errors.New("cannot determine self path")
		}

		oldStderr := os.Stderr
		r, w, _ := os.Pipe()
		os.Stderr = w

		main()
		_ = w.Close()
		os.Stderr = oldStderr

		var buf bytes.Buffer
		_, _ = io.Copy(&buf, r)

		if exitCode != 1 {
			t.Errorf("expected exit code 1, got %d", exitCode)
		}
		if !strings.Contains(buf.String(), "[microfat] error:") {
			t.Errorf("expected error message in stderr, got: %s", buf.String())
		}
	})

	// 2. Fatal error with diagnosed hint (e.g. read-only filesystem EROFS)
	t.Run("fatal error with diagnosed hint in default mode", func(t *testing.T) {
		t.Setenv(format.EnvLog, "")
		getSelfExecutablePathFunc = func() (string, error) {
			return "", syscall.EROFS
		}

		oldStderr := os.Stderr
		r, w, _ := os.Pipe()
		os.Stderr = w

		main()
		_ = w.Close()
		os.Stderr = oldStderr

		var buf bytes.Buffer
		_, _ = io.Copy(&buf, r)

		if exitCode != 1 {
			t.Errorf("expected exit code 1, got %d", exitCode)
		}
		out := buf.String()
		if !strings.Contains(out, "[microfat] error:") {
			t.Errorf("expected error in stderr, got: %s", out)
		}
		if !strings.Contains(out, "[microfat:hint]") || !strings.Contains(out, "Read-only filesystem detected") {
			t.Errorf("expected hint in stderr on fatal exit, got: %s", out)
		}
	})

	// 3. Fatal error with JSON logging includes Hint field
	t.Run("fatal error with JSON logging", func(t *testing.T) {
		t.Setenv(format.EnvLog, "json")
		getSelfExecutablePathFunc = func() (string, error) {
			return "", syscall.EROFS
		}

		oldStderr := os.Stderr
		r, w, _ := os.Pipe()
		os.Stderr = w

		main()
		_ = w.Close()
		os.Stderr = oldStderr

		var buf bytes.Buffer
		_, _ = io.Copy(&buf, r)

		out := buf.String()
		var lines []string
		for line := range strings.SplitSeq(out, "\n") {
			line = strings.TrimSpace(line)
			if strings.HasPrefix(line, "[microfat] {") {
				lines = append(lines, line)
			}
		}

		if len(lines) == 0 {
			t.Fatalf("expected JSON telemetry line, got: %s", out)
		}

		jsonStr := strings.TrimPrefix(lines[0], "[microfat] ")
		var telem format.ErrorTelemetry
		if err := json.Unmarshal([]byte(jsonStr), &telem); err != nil {
			t.Fatalf("failed to unmarshal JSON: %v (raw: %s)", err, jsonStr)
		}

		if telem.Hint != format.HintReadOnlyFS {
			t.Errorf("expected Hint=%q, got %q", format.HintReadOnlyFS, telem.Hint)
		}
	})
}

func TestStubMultiCodecExecutionAndErrors(t *testing.T) {
	tempDir := t.TempDir()

	// 1. Create fake launcher stub & dummy variants
	stubPath := filepath.Join(tempDir, "microfat-stub")
	_ = os.WriteFile(stubPath, []byte("#!/bin/sh\necho stub\n"), 0o755)

	v1Path := filepath.Join(tempDir, "v1")
	_ = os.WriteFile(v1Path, []byte("#!/bin/sh\necho v1\n"), 0o755)
	v3Path := filepath.Join(tempDir, "v3")
	_ = os.WriteFile(v3Path, []byte("#!/bin/sh\necho v3\n"), 0o755)

	// Create fat binary with lz4 v1 and none v3
	fatPath := filepath.Join(tempDir, "multicodec.fat")
	opts := pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "multicodec-stub-test",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		SkipELFValidation: true,
		VariantCompression: map[string]pack.VariantCompressionOptions{
			"v1": {Compression: "lz4"},
			"v3": {Compression: "none"},
		},
		Variants: map[string]string{
			"v1": v1Path,
			"v3": v3Path,
		},
	}
	idx, err := pack.Pack(opts)
	if err != nil {
		t.Fatalf("pack multicodec fat binary: %v", err)
	}

	selfFile, err := os.Open(fatPath)
	if err != nil {
		t.Fatalf("open fat binary: %v", err)
	}
	defer func() { _ = selfFile.Close() }()

	v1Entry, _ := idx.FindVariant("v1")
	v3Entry, _ := idx.FindVariant("v3")

	// 2. Test extractVariantToWriter for lz4
	var bufLZ4 bytes.Buffer
	if err := extractVariantToWriter(selfFile, v1Entry, nil, &bufLZ4); err != nil {
		t.Fatalf("extract lz4 variant failed: %v", err)
	}
	if bufLZ4.String() != "#!/bin/sh\necho v1\n" {
		t.Errorf("lz4 extracted payload mismatch: %q", bufLZ4.String())
	}

	// 3. Test extractVariantToWriter for none
	var bufNone bytes.Buffer
	if err := extractVariantToWriter(selfFile, v3Entry, nil, &bufNone); err != nil {
		t.Fatalf("extract none variant failed: %v", err)
	}
	if bufNone.String() != "#!/bin/sh\necho v3\n" {
		t.Errorf("none extracted payload mismatch: %q", bufNone.String())
	}

	// 4. Test extractVariantToWriter with unsupported codec
	badEntry := *v1Entry
	badEntry.Compression = "unknown_codec_xyz"
	var bufBad bytes.Buffer
	if err := extractVariantToWriter(selfFile, &badEntry, nil, &bufBad); err == nil {
		t.Errorf("expected error extracting variant with unknown codec")
	}

	// 5. Test optimizeTo with lz4 variant
	optDest := filepath.Join(tempDir, "opt_dest")
	if err := optimizeTo(optDest, selfFile, v1Entry, nil, lifecycle.DefaultOptions()); err != nil {
		t.Fatalf("optimizeTo with lz4 variant failed: %v", err)
	}
	optBytes, _ := os.ReadFile(optDest)
	if string(optBytes) != "#!/bin/sh\necho v1\n" {
		t.Errorf("optimizeTo content mismatch: %q", string(optBytes))
	}
}

func TestBuildAutoTunedEnviron_GCProfiles(t *testing.T) {
	entry := &format.VariantEntry{
		Level:            "v3",
		SHA256:           "abcdef123456",
		UncompressedSize: 4096,
	}
	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	oldRead := readCgroupLimitsFunc
	defer func() { readCgroupLimitsFunc = oldRead }()

	readCgroupLimitsFunc = func() (cgroup.Limits, error) {
		return cgroup.Limits{
			CgroupVersion:    cgroup.VersionV2,
			MemoryLimitBytes: 1024 * 1024 * 1024,
			CPUQuota:         4.0,
			CPUs:             4,
		}, nil
	}

	t.Run("LatencyCriticalProfile", func(t *testing.T) {
		t.Setenv(format.EnvGCProfile, "latency_critical")
		env, limits := buildAutoTunedEnviron("", nil, entry, format.ExecModeMemfd, hostInfo, policyRes)
		if limits == nil {
			t.Fatalf("expected limits")
		}
		envMap := make(map[string]string)
		for _, e := range env {
			parts := strings.SplitN(e, "=", 2)
			if len(parts) == 2 {
				envMap[parts[0]] = parts[1]
			}
		}
		if envMap["GOGC"] != "75" {
			t.Errorf("expected GOGC=75, got %q", envMap["GOGC"])
		}
		if envMap[format.EnvCgroupGCProfile] != "latency_critical" {
			t.Errorf("expected profile telemetry latency_critical, got %q", envMap[format.EnvCgroupGCProfile])
		}
	})

	t.Run("BatchETLProfile", func(t *testing.T) {
		t.Setenv(format.EnvGCProfile, "batch_etl")
		env, _ := buildAutoTunedEnviron("", nil, entry, format.ExecModeMemfd, hostInfo, policyRes)
		envMap := make(map[string]string)
		for _, e := range env {
			parts := strings.SplitN(e, "=", 2)
			if len(parts) == 2 {
				envMap[parts[0]] = parts[1]
			}
		}
		if envMap["GOGC"] != "off" {
			t.Errorf("expected GOGC=off, got %q", envMap["GOGC"])
		}
	})

	t.Run("ExplicitGOGCPrecedence", func(t *testing.T) {
		t.Setenv(format.EnvGCProfile, "latency_critical")
		baseEnv := []string{"GOGC=120"}
		env, _ := buildAutoTunedEnviron("", baseEnv, entry, format.ExecModeMemfd, hostInfo, policyRes)
		gogcCount := 0
		var finalGOGC string
		for _, e := range env {
			if strings.HasPrefix(e, "GOGC=") {
				gogcCount++
				finalGOGC = strings.TrimPrefix(e, "GOGC=")
			}
		}
		if gogcCount != 1 || finalGOGC != "120" {
			t.Errorf("expected single explicit GOGC=120, got count=%d final=%q", gogcCount, finalGOGC)
		}
	})
}

func TestStubDictionaryExecutionAndMetaCommands(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "microfat-stub")
	_ = os.WriteFile(stubPath, []byte("#!/bin/sh\necho stub launcher\n"), 0o755)

	makeVariant := func(lvl string) []byte {
		var buf bytes.Buffer
		for i := range 800 {
			buf.WriteString(fmt.Sprintf("symbol_entry_%04d_runtime_pkg_metadata_hash_%x\n", i, (i*37)^0xDEADBEEF))
		}
		buf.WriteString(fmt.Sprintf("variant_specific_instructions_%s\n", lvl))
		return buf.Bytes()
	}

	v1Data := makeVariant("v1")
	v3Data := makeVariant("v3")

	v1Path := filepath.Join(tempDir, "v1")
	v3Path := filepath.Join(tempDir, "v3")
	_ = os.WriteFile(v1Path, v1Data, 0o755)
	_ = os.WriteFile(v3Path, v3Data, 0o755)

	fatPath := filepath.Join(tempDir, "dict_stub_test.fat")
	packOpts := pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "dict-stub-app",
		TargetOS:          testOSLinux,
		TargetArch:        testArchAMD64,
		Variants:          map[string]string{"v1": v1Path, "v3": v3Path},
		EnableDict:        true,
		SkipELFValidation: true,
	}
	idx, err := pack.Pack(packOpts)
	if err != nil {
		t.Fatalf("Pack failed: %v", err)
	}

	if idx.DictionarySize <= 0 {
		t.Fatalf("expected DictionarySize > 0")
	}

	oldArgs := os.Args
	defer func() { os.Args = oldArgs }()

	oldExec := execveFunc
	defer func() { execveFunc = oldExec }()

	var executedPath string
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		executedPath = argv0
		return nil
	}

	// 1. Test transparent execution via runBinary (calls executeVariant with idx)
	os.Args = []string{fatPath, "arg1", "arg2"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("runBinary failed on dict fat binary: %v", err)
	}
	if !strings.HasPrefix(executedPath, "/proc/self/fd/") {
		t.Errorf("expected memfd execution, got %s", executedPath)
	}

	// 2. Test --microfat:info and --microfat:info=json
	os.Args = []string{fatPath, "--microfat:info"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("--microfat:info failed on dict binary: %v", err)
	}

	os.Args = []string{fatPath, "--microfat:info=json"}
	if err := runBinary(fatPath); err != nil {
		t.Fatalf("--microfat:info=json failed on dict binary: %v", err)
	}

	// 3. Test optimizeTo on dict binary
	selfFile, err := os.Open(fatPath)
	if err != nil {
		t.Fatalf("open fat binary: %v", err)
	}
	defer func() { _ = selfFile.Close() }()

	v3Entry, _ := idx.FindVariant("v3")
	optDest := filepath.Join(tempDir, "opt_out_v3")
	if err := optimizeTo(optDest, selfFile, v3Entry, idx, lifecycle.DefaultOptions()); err != nil {
		t.Fatalf("optimizeTo failed on dict binary: %v", err)
	}
	optBytes, _ := os.ReadFile(optDest)
	if !bytes.Equal(optBytes, v3Data) {
		t.Errorf("optimizeTo payload mismatch")
	}

	// 4. Test optimizeInPlace on dict binary
	optInPlaceTarget := filepath.Join(tempDir, "opt_inplace_target")
	_ = os.Link(selfFile.Name(), optInPlaceTarget)
	breakOptsDict := lifecycle.DefaultOptions()
	breakOptsDict.BreakHardlinks = true
	if err := optimizeInPlace(optInPlaceTarget, selfFile, v3Entry, idx, breakOptsDict); err != nil {
		t.Fatalf("optimizeInPlace failed on dict binary: %v", err)
	}
	inPlaceBytes, _ := os.ReadFile(optInPlaceTarget)
	if !bytes.Equal(inPlaceBytes, v3Data) {
		t.Errorf("optimizeInPlace payload mismatch")
	}
}

func TestStubDictionaryCorruptedError(t *testing.T) {
	tempDir := t.TempDir()

	stubPath := filepath.Join(tempDir, "stub")
	_ = os.WriteFile(stubPath, []byte("#!/bin/sh\n"), 0o755)

	makeVariant := func(lvl string) []byte {
		var buf bytes.Buffer
		for i := range 800 {
			buf.WriteString(fmt.Sprintf("symbol_entry_%04d_runtime_pkg_metadata_hash_%x\n", i, (i*37)^0xCAFEBABE))
		}
		buf.WriteString(fmt.Sprintf("variant_specific_instructions_%s\n", lvl))
		return buf.Bytes()
	}

	v1Path := filepath.Join(tempDir, "v1")
	v2Path := filepath.Join(tempDir, "v2")
	_ = os.WriteFile(v1Path, makeVariant("v1"), 0o755)
	_ = os.WriteFile(v2Path, makeVariant("v2"), 0o755)

	fatPath := filepath.Join(tempDir, "fat.corrupt.dict")
	idx, err := pack.Pack(pack.Options{
		StubPath:          stubPath,
		OutputPath:        fatPath,
		AppName:           "corruptdictapp",
		TargetArch:        testArchAMD64,
		Variants:          map[string]string{"v1": v1Path, "v2": v2Path},
		EnableDict:        true,
		SkipELFValidation: true,
	})
	if err != nil {
		t.Fatalf("Pack failed: %v", err)
	}

	// Corrupt the dictionary SHA256 in Index
	corruptIdx := *idx
	corruptIdx.DictionarySHA256 = "0000000000000000000000000000000000000000000000000000000000000000"

	selfFile, err := os.Open(fatPath)
	if err != nil {
		t.Fatalf("open fat binary: %v", err)
	}
	defer func() { _ = selfFile.Close() }()

	var buf bytes.Buffer
	v1Entry, _ := idx.FindVariant("v1")
	err = extractVariantToWriter(selfFile, v1Entry, &corruptIdx, &buf)
	if err == nil || !errors.Is(err, format.ErrDictionaryCorrupted) {
		t.Fatalf("expected ErrDictionaryCorrupted, got %v", err)
	}
}

func TestExtractVariantToWriter_OversizedDictionaryGuard(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	fatPath := filepath.Join(tmpDir, "test.fat")
	dummyData := bytes.Repeat([]byte{0x42}, 1024)
	if err := os.WriteFile(fatPath, dummyData, 0o755); err != nil {
		t.Fatalf("write dummy file: %v", err)
	}

	selfFile, err := os.Open(fatPath)
	if err != nil {
		t.Fatalf("open dummy file: %v", err)
	}
	defer func() { _ = selfFile.Close() }()

	entry := &format.VariantEntry{
		Level:            "v1",
		Compression:      "none",
		Offset:           0,
		CompressedSize:   100,
		UncompressedSize: 100,
	}

	var buf bytes.Buffer

	// 1. Oversized dictionary size (> MaxDictionarySize)
	oversizedIdx := &format.Index{
		Version:          format.FormatVersion2,
		DictionaryOffset: 0,
		DictionarySize:   format.MaxDictionarySize + 1,
	}
	err = extractVariantToWriter(selfFile, entry, oversizedIdx, &buf)
	if err == nil || !errors.Is(err, format.ErrInvalidDictionary) {
		t.Fatalf("expected ErrInvalidDictionary for oversized dictionary in extractVariantToWriter, got %v", err)
	}

	// 2. Negative dictionary offset
	negativeOffsetIdx := &format.Index{
		Version:          format.FormatVersion2,
		DictionaryOffset: -1,
		DictionarySize:   1024,
	}
	err = extractVariantToWriter(selfFile, entry, negativeOffsetIdx, &buf)
	if err == nil || !errors.Is(err, format.ErrInvalidDictionary) {
		t.Fatalf("expected ErrInvalidDictionary for negative dictionary offset in extractVariantToWriter, got %v", err)
	}
}

func TestExplicitMemfdModeEnforcement(t *testing.T) {
	entry, rawFile := createDummyVariantFile(t, t.TempDir(), []byte("#!/bin/sh\necho 'memfd-mode-test'\n"))
	defer func() { _ = rawFile.Close() }()

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origCreate := memfdCreateFunc
	origSeal := memfdSealFunc
	origExec := execveFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		memfdCreateFunc = origCreate
		memfdSealFunc = origSeal
		execveFunc = origExec
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v1"}
	policyRes := microarch.PolicyResult{}

	t.Run("memfdCreate failure with MICROFAT_EXEC_MODE=memfd fails immediately without cache fallback", func(t *testing.T) {
		t.Setenv(format.EnvExecMode, format.ExecModeMemfd)

		var cacheExecuted bool
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			if strings.HasPrefix(argv0, cacheDir) {
				cacheExecuted = true
			}
			return nil
		}

		memfdCreateFunc = func(name string, flags int) (int, error) {
			return -1, syscall.EPERM
		}

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		if err == nil {
			t.Fatal("expected executeVariant to fail, got nil")
		}
		if !errors.Is(err, format.ErrMemfdCreate) {
			t.Errorf("expected ErrMemfdCreate, got: %v", err)
		}
		if cacheExecuted {
			t.Fatal("cache execution must NOT be attempted when MICROFAT_EXEC_MODE=memfd")
		}
	})

	t.Run("memfdSeal failure with MICROFAT_EXEC_MODE=memfd fails immediately without cache fallback", func(t *testing.T) {
		t.Setenv(format.EnvExecMode, format.ExecModeMemfd)

		var cacheExecuted bool
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			if strings.HasPrefix(argv0, cacheDir) {
				cacheExecuted = true
			}
			return nil
		}

		memfdCreateFunc = origCreate
		memfdSealFunc = func(fd int, seals int) error {
			return syscall.EPERM
		}

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		if err == nil {
			t.Fatal("expected executeVariant to fail on seal failure in memfd mode, got nil")
		}
		if !errors.Is(err, format.ErrMemfdSealingFailed) {
			t.Errorf("expected ErrMemfdSealingFailed, got: %v", err)
		}
		if cacheExecuted {
			t.Fatal("cache execution must NOT be attempted when MICROFAT_EXEC_MODE=memfd")
		}
	})

	t.Run("memfdSeal failure with MICROFAT_EXEC_MODE=auto falls back cleanly to cache", func(t *testing.T) {
		t.Setenv(format.EnvExecMode, "")
		t.Setenv(format.EnvDispatchMode, "")

		var cacheExecuted bool
		expectedTarget := filepath.Join(cacheDir, entry.SHA256)
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			target := argv0
			if link, err := os.Readlink(argv0); err == nil {
				target = strings.TrimSuffix(link, " (deleted)")
			}
			if target == expectedTarget {
				cacheExecuted = true
				return nil
			}
			return errors.New("unexpected exec path: " + argv0)
		}

		memfdCreateFunc = origCreate
		memfdSealFunc = func(fd int, seals int) error {
			return syscall.ENOSYS
		}

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		if err != nil {
			t.Fatalf("expected fallback to cache in auto mode on seal failure, got error: %v", err)
		}
		if !cacheExecuted {
			t.Fatal("expected cache execution to succeed on seal fallback in auto mode")
		}
	})
}

func TestStub_SecurityInvariants(t *testing.T) {
	origExecve := execveFunc
	origCreate := memfdCreateFunc
	origSeal := memfdSealFunc
	t.Cleanup(func() {
		execveFunc = origExecve
		memfdCreateFunc = origCreate
		memfdSealFunc = origSeal
	})

	t.Run("Cache isolation invariant enforces 0700 permissions", func(t *testing.T) {
		tmpDir := t.TempDir()
		cacheDir := filepath.Join(tmpDir, "secure_cache")
		t.Setenv(format.EnvCacheDir, cacheDir)
		t.Setenv(format.EnvExecMode, format.ExecModeCache)
		t.Setenv(format.EnvVerifyCache, "1")

		payload := []byte("SECURITY_INVARIANT_TEST_PAYLOAD")
		entry, rawFile := createDummyVariantFile(t, tmpDir, payload)
		defer rawFile.Close()
		entry.Compression = testCompressionZstd

		hostInfo := microarch.Info{
			OS:    testOSLinux,
			Arch:  testArchAMD64,
			Level: "v1",
		}
		policyRes := microarch.PolicyResult{
			SelectedVariant: "v1",
		}

		var execCalled bool
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			execCalled = true
			return nil
		}

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		if err != nil {
			t.Fatalf("executeVariant failed: %v", err)
		}
		if !execCalled {
			t.Fatal("expected execve to be called")
		}

		// Security Invariant: Cache dir and cached files must strictly maintain 0700 private permissions
		testutil.AssertCacheIsolation(t, cacheDir)

		// Pre-execution SHA-256 verification: tampering with binary on disk must trigger re-extraction
		cachedFile := filepath.Join(cacheDir, entry.SHA256)
		tamperedBytes := make([]byte, len(payload))
		copy(tamperedBytes, []byte("TAMPERED_BYTES_"))
		if err := os.WriteFile(cachedFile, tamperedBytes, testutil.PrivatePermissionMode); err != nil {
			t.Fatalf("writing tampered file: %v", err)
		}

		err = executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		if err != nil {
			t.Fatalf("executeVariant failed on re-extraction: %v", err)
		}

		// Verify that tampered file was overwritten with valid payload matching expectedHash
		restoredBytes, err := os.ReadFile(cachedFile)
		if err != nil {
			t.Fatalf("reading restored cached file: %v", err)
		}
		if !bytes.Equal(restoredBytes, payload) {
			t.Fatal("expected tampered file to be re-extracted and restored to original payload")
		}
	})

	t.Run("Memfd sealing invariant requires all four immutable seals", func(t *testing.T) {
		t.Setenv(format.EnvExecMode, format.ExecModeMemfd)

		tmpDir := t.TempDir()
		payload := []byte("MEMFD_SEAL_TEST_PAYLOAD")
		entry, rawFile := createDummyVariantFile(t, tmpDir, payload)
		defer rawFile.Close()
		entry.Compression = testCompressionZstd

		hostInfo := microarch.Info{
			OS:    testOSLinux,
			Arch:  testArchAMD64,
			Level: "v1",
		}
		policyRes := microarch.PolicyResult{
			SelectedVariant: "v1",
		}

		var appliedSeals int
		memfdSealFunc = func(fd int, seals int) error {
			appliedSeals = seals
			return nil
		}

		execveFunc = func(argv0 string, argv []string, envv []string) error {
			return nil
		}

		err := executeVariant(rawFile.Name(), rawFile, entry, nil, []string{testAppArg}, []string{testPathEnv}, hostInfo, policyRes, time.Now())
		if err != nil {
			t.Fatalf("executeVariant failed: %v", err)
		}

		if appliedSeals != memfdTargetSeals {
			t.Fatalf("memfd seals invariant violation: expected %x, got %x", memfdTargetSeals, appliedSeals)
		}
	})
}

func TestExecuteViaCache_InstallationFailures(t *testing.T) {
	tmpDir := t.TempDir()
	payload := []byte("hello cache installation failure test payload")
	entry, rawFile := createDummyVariantFile(t, tmpDir, payload)
	defer rawFile.Close()
	entry.Compression = testCompressionZstd

	hostInfo := microarch.Info{
		OS:    testOSLinux,
		Arch:  testArchAMD64,
		Level: "v1",
	}
	policyRes := microarch.PolicyResult{
		SelectedVariant: "v1",
	}

	t.Run("RenameFailure_WhenTargetIsDirectory", func(t *testing.T) {
		cacheHome := filepath.Join(tmpDir, "cache_rename_fail")
		microfatCache := filepath.Join(cacheHome, "microfat")
		require.NoError(t, os.MkdirAll(microfatCache, 0o700), "mkdir failed")
		t.Setenv("XDG_CACHE_HOME", cacheHome)

		// Create non-empty target destination as a directory so os.Remove and os.Rename fail with ENOTEMPTY/EISDIR
		targetPath := filepath.Join(microfatCache, entry.SHA256)
		require.NoError(t, os.MkdirAll(targetPath, 0o700), "mkdir targetPath failed")
		require.NoError(t, os.WriteFile(filepath.Join(targetPath, "blocking_child"), []byte("blocker"), 0o600), "write child file failed")

		primaryErr := errors.New("simulated primary memfd exhaustion")
		err := executeViaCache(
			rawFile.Name(), rawFile, entry, nil,
			[]string{testAppArg}, []string{testPathEnv},
			hostInfo, policyRes, primaryErr, time.Now(),
		)
		require.Error(t, err, "expected error when rename fails, got nil")
		if !errors.Is(err, format.ErrCacheWrite) {
			t.Fatalf("expected ErrCacheWrite, got %v", err)
		}
		if !strings.Contains(err.Error(), "primary memfd error: simulated primary memfd exhaustion") {
			t.Fatalf("expected primaryErr preserved in error string, got %v", err)
		}
	})

	t.Run("VerifyCache_CorruptedFileReextracted_Unconditional", func(t *testing.T) {
		cacheHome := filepath.Join(tmpDir, "cache_verify_corrupt")
		microfatCache := filepath.Join(cacheHome, "microfat")
		require.NoError(t, os.MkdirAll(microfatCache, 0o700), "mkdir failed")
		t.Setenv("XDG_CACHE_HOME", cacheHome)
		t.Setenv(format.EnvDebug, "1")
		t.Setenv(format.EnvVerifyCache, "0") // Even when explicitly set to 0, verification is unconditional

		// Create corrupted file with matching size but invalid content
		targetPath := filepath.Join(microfatCache, entry.SHA256)
		corruptedData := bytes.Repeat([]byte{0x42}, int(entry.UncompressedSize))
		require.NoError(t, os.WriteFile(targetPath, corruptedData, 0o700), "writing corrupted file")

		execveFunc = func(argv0 string, argv []string, envv []string) error {
			return nil
		}

		err := executeViaCache(
			rawFile.Name(), rawFile, entry, nil,
			[]string{testAppArg}, []string{testPathEnv},
			hostInfo, policyRes, nil, time.Now(),
		)
		require.NoError(t, err, "expected re-extraction and successful execution, got")
	})

	t.Run("TruncatedCacheFile_DebugLogging", func(t *testing.T) {
		cacheHome := filepath.Join(tmpDir, "cache_truncated")
		microfatCache := filepath.Join(cacheHome, "microfat")
		require.NoError(t, os.MkdirAll(microfatCache, 0o700), "mkdir failed")
		t.Setenv("XDG_CACHE_HOME", cacheHome)
		t.Setenv(format.EnvDebug, "1")

		// Write file with wrong size
		targetPath := filepath.Join(microfatCache, entry.SHA256)
		require.NoError(t, os.WriteFile(targetPath, []byte("short"), 0o700), "writing short file")

		execveFunc = func(argv0 string, argv []string, envv []string) error {
			return nil
		}

		err := executeViaCache(
			rawFile.Name(), rawFile, entry, nil,
			[]string{testAppArg}, []string{testPathEnv},
			hostInfo, policyRes, nil, time.Now(),
		)
		require.NoError(t, err, "expected re-extraction on truncated cache file, got")
	})

	t.Run("ExecveFailure_WithoutPrimaryErr", func(t *testing.T) {
		cacheHome := filepath.Join(tmpDir, "cache_exec_fail_no_primary")
		t.Setenv("XDG_CACHE_HOME", cacheHome)

		execveFunc = func(argv0 string, argv []string, envv []string) error {
			return errors.New("execve simulated failure")
		}

		err := executeViaCache(
			rawFile.Name(), rawFile, entry, nil,
			[]string{testAppArg}, []string{testPathEnv},
			hostInfo, policyRes, nil, time.Now(),
		)
		require.Error(t, err, "expected execve failure, got nil")
		if !strings.Contains(err.Error(), "cache execve failed") {
			t.Fatalf("expected cache execve failed error without primary memfd error, got %v", err)
		}
	})

	t.Run("OpenCachedBinaryFailure_CleansUpDestinationBinary", func(t *testing.T) {
		cacheHome := filepath.Join(tmpDir, "cache_open_fail")
		microfatCache := filepath.Join(cacheHome, "microfat")
		require.NoError(t, os.MkdirAll(microfatCache, 0o700), "mkdir failed")
		t.Setenv("XDG_CACHE_HOME", cacheHome)

		origOpen := openCachedBinaryFunc
		origOpenAt := openCachedBinaryAtFunc
		defer func() {
			openCachedBinaryFunc = origOpen
			openCachedBinaryAtFunc = origOpenAt
		}()

		callCount := 0
		openCachedBinaryFunc = func(path string) (int, error) {
			callCount++
			if callCount == 1 {
				// Initial check before extraction: report not existing
				return -1, os.ErrNotExist
			}
			// Second call after extraction and rename: simulate failure to open
			return -1, errors.New("simulated open error after rename")
		}
		openCachedBinaryAtFunc = func(dirFD int, name string) (int, error) {
			callCount++
			if callCount == 1 {
				// Initial check before extraction: report not existing
				return -1, os.ErrNotExist
			}
			// Second call after extraction and rename: simulate failure to open
			return -1, errors.New("simulated open error after rename")
		}

		err := executeViaCache(
			rawFile.Name(), rawFile, entry, nil,
			[]string{testAppArg}, []string{testPathEnv},
			hostInfo, policyRes, nil, time.Now(),
		)
		require.Error(t, err, "expected error when openCachedBinary fails after rename, got nil")

		// Verify that cachedBinary was removed so no defective file lingers
		cachedBinary := filepath.Join(microfatCache, entry.SHA256)
		if _, statErr := os.Stat(cachedBinary); !os.IsNotExist(statErr) {
			t.Errorf("expected cached binary %s to be removed on open failure, stat err: %v", cachedBinary, statErr)
		}

		// Verify no temporary files remain
		tmpMatches, _ := filepath.Glob(filepath.Join(microfatCache, ".exec-*.tmp"))
		if len(tmpMatches) > 0 {
			t.Errorf("expected no temporary files remaining in cache, found: %v", tmpMatches)
		}
	})
}

func TestCacheExecution_SymlinkRefusalAndTOCTOUDefense(t *testing.T) {
	tmpDir := t.TempDir()
	payload := []byte("hello toctou defense test payload 12345")
	entry, rawFile := createDummyVariantFile(t, tmpDir, payload)
	defer rawFile.Close()
	entry.Compression = testCompressionZstd

	hostInfo := microarch.Info{
		OS:    testOSLinux,
		Arch:  testArchAMD64,
		Level: "v1",
	}
	policyRes := microarch.PolicyResult{
		SelectedVariant: "v1",
	}

	t.Run("SymlinkRefusal_WhenCacheTargetIsSymlink", func(t *testing.T) {
		cacheHome := filepath.Join(tmpDir, "symlink_refusal_cache")
		microfatCache := filepath.Join(cacheHome, "microfat")
		if err := os.MkdirAll(microfatCache, 0o700); err != nil {
			t.Fatalf("mkdir failed: %v", err)
		}
		t.Setenv("XDG_CACHE_HOME", cacheHome)

		// Create a symlink at the target binary path
		targetPath := filepath.Join(microfatCache, entry.SHA256)
		targetTrap := filepath.Join(tmpDir, "trap_binary")
		if err := os.WriteFile(targetTrap, []byte("trap"), 0o755); err != nil {
			t.Fatalf("write trap failed: %v", err)
		}
		if err := os.Symlink(targetTrap, targetPath); err != nil {
			t.Fatalf("symlink creation failed: %v", err)
		}

		var execveCalled bool
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			execveCalled = true
			return nil
		}

		err := executeViaCache(
			rawFile.Name(), rawFile, entry, nil,
			[]string{testAppArg}, []string{testPathEnv},
			hostInfo, policyRes, nil, time.Now(),
		)
		if err == nil {
			t.Fatalf("expected error refusing symlink execution, got nil")
		}
		if !errors.Is(err, format.ErrCacheWrite) {
			t.Fatalf("expected ErrCacheWrite, got: %v", err)
		}
		if !strings.Contains(err.Error(), "refusal to execute symlink") {
			t.Fatalf("expected refusal to execute symlink message, got: %v", err)
		}
		if execveCalled {
			t.Fatalf("execve must NOT be called when cache entry is a symlink")
		}
	})

	t.Run("ConcurrentPathReplacement_InodeBindingDefense", func(t *testing.T) {
		cacheHome := filepath.Join(tmpDir, "toctou_inode_cache")
		microfatCache := filepath.Join(cacheHome, "microfat")
		if err := os.MkdirAll(microfatCache, 0o700); err != nil {
			t.Fatalf("mkdir failed: %v", err)
		}
		t.Setenv("XDG_CACHE_HOME", cacheHome)

		targetPath := filepath.Join(microfatCache, entry.SHA256)
		originalBytes := payload
		if err := os.WriteFile(targetPath, originalBytes, 0o700); err != nil {
			t.Fatalf("write original cache file failed: %v", err)
		}

		// Intercept openCachedBinaryFunc and openCachedBinaryAtFunc to replace the file on disk immediately AFTER open
		oldOpen := openCachedBinaryFunc
		oldOpenAt := openCachedBinaryAtFunc
		defer func() {
			openCachedBinaryFunc = oldOpen
			openCachedBinaryAtFunc = oldOpenAt
		}()

		openCachedBinaryFunc = func(path string) (int, error) {
			fd, err := oldOpen(path)
			if err != nil {
				return fd, err
			}
			// Replace file on disk with a new inode (atomic rename) concurrently
			hostilePath := filepath.Join(tmpDir, "hostile_replacement")
			hostileBytes := []byte("HOSTILE_REPLACED_PAYLOAD_DATA_OVERWRITTEN")
			_ = os.WriteFile(hostilePath, hostileBytes, 0o700)
			_ = os.Rename(hostilePath, path)
			return fd, nil
		}
		openCachedBinaryAtFunc = func(dirFD int, name string) (int, error) {
			fd, err := oldOpenAt(dirFD, name)
			if err != nil {
				return fd, err
			}
			// Replace file on disk with a new inode (atomic rename) concurrently
			hostilePath := filepath.Join(tmpDir, "hostile_replacement")
			hostileBytes := []byte("HOSTILE_REPLACED_PAYLOAD_DATA_OVERWRITTEN")
			_ = os.WriteFile(hostilePath, hostileBytes, 0o700)
			_ = os.Rename(hostilePath, filepath.Join(microfatCache, name))
			return fd, nil
		}

		var descriptorContent []byte
		execveFunc = func(argv0 string, argv []string, envv []string) error {
			// Read the descriptor directly via /proc/self/fd/<fd>
			var err error
			descriptorContent, err = os.ReadFile(argv0)
			if err != nil {
				return fmt.Errorf("reading /proc/self/fd descriptor: %w", err)
			}
			return nil
		}

		err := executeViaCache(
			rawFile.Name(), rawFile, entry, nil,
			[]string{testAppArg}, []string{testPathEnv},
			hostInfo, policyRes, nil, time.Now(),
		)
		if err != nil {
			t.Fatalf("executeViaCache failed: %v", err)
		}

		// Verify descriptor content is the ORIGINAL inode content, immune to concurrent disk replacement
		if !bytes.Equal(descriptorContent, originalBytes) {
			t.Fatalf("TOCTOU vulnerability detected: descriptor read %q, expected original %q",
				string(descriptorContent), string(originalBytes))
		}
	})
}

func TestOpenAndValidateCacheFD_SecurityContract(t *testing.T) {
	t.Setenv(format.EnvDebug, "1")
	tmpDir := t.TempDir()
	payload := []byte("canonical descriptor-bound cache validation payload test 98765")
	entry, rawFile := createDummyVariantFile(t, tmpDir, payload)
	defer rawFile.Close()

	t.Run("NonexistentFile_ReturnsError", func(t *testing.T) {
		fd, err := openAndValidateCacheFD(filepath.Join(tmpDir, "does_not_exist"), entry)
		if err == nil {
			_ = unix.Close(fd)
			t.Fatalf("expected error for nonexistent file, got nil")
		}
		if fd != -1 {
			t.Errorf("expected fd -1 on error, got %d", fd)
		}
	})

	t.Run("SymlinkTarget_ReturnsErrorAndNoFollow", func(t *testing.T) {
		validPath := filepath.Join(tmpDir, "valid_for_symlink")
		require.NoError(t, os.WriteFile(validPath, payload, 0o700), "write valid file")
		symlinkPath := filepath.Join(tmpDir, "symlink_test")
		require.NoError(t, os.Symlink(validPath, symlinkPath), "create symlink")

		fd, err := openAndValidateCacheFD(symlinkPath, entry)
		if err == nil {
			_ = unix.Close(fd)
			t.Fatalf("expected error on symlink open, got nil")
		}
		if !errors.Is(err, unix.ELOOP) && !errors.Is(err, syscall.ELOOP) {
			t.Fatalf("expected ELOOP error on symlink, got: %v", err)
		}
	})

	t.Run("NonRegularFile_Directory_RejectedAndClosed", func(t *testing.T) {
		dirPath := filepath.Join(tmpDir, "dir_as_cache")
		require.NoError(t, os.MkdirAll(dirPath, 0o700), "mkdir")

		fd, err := openAndValidateCacheFD(dirPath, entry)
		if err == nil {
			_ = unix.Close(fd)
			t.Fatalf("expected error on directory cache target, got nil")
		}
		if _, statErr := os.Stat(dirPath); statErr != nil {
			t.Fatalf("non-regular directory should not be removed from disk: %v", statErr)
		}
	})

	t.Run("SizeMismatch_PurgesFileAndReturnsError", func(t *testing.T) {
		sizeMismatchPath := filepath.Join(tmpDir, "size_mismatch_test")
		require.NoError(t, os.WriteFile(sizeMismatchPath, []byte("short"), 0o700), "write short file")

		fd, err := openAndValidateCacheFD(sizeMismatchPath, entry)
		if err == nil {
			_ = unix.Close(fd)
			t.Fatalf("expected error on size mismatch, got nil")
		}
		if fd != -1 {
			t.Errorf("expected fd -1, got %d", fd)
		}
		if _, statErr := os.Stat(sizeMismatchPath); !os.IsNotExist(statErr) {
			t.Fatalf("expected truncated file to be removed from disk, stat err: %v", statErr)
		}
	})

	t.Run("ChecksumMismatch_PurgesFileAndReturnsError", func(t *testing.T) {
		corruptPath := filepath.Join(tmpDir, "corrupt_checksum_test")
		tampered := bytes.Repeat([]byte{0x77}, len(payload))
		require.NoError(t, os.WriteFile(corruptPath, tampered, 0o700), "write corrupt file")

		fd, err := openAndValidateCacheFD(corruptPath, entry)
		if err == nil {
			_ = unix.Close(fd)
			t.Fatalf("expected error on checksum mismatch, got nil")
		}
		if !errors.Is(err, format.ErrPayloadCorrupted) {
			t.Fatalf("expected ErrPayloadCorrupted, got: %v", err)
		}
		if _, statErr := os.Stat(corruptPath); !os.IsNotExist(statErr) {
			t.Fatalf("expected corrupted file to be removed from disk, stat err: %v", statErr)
		}
	})

	t.Run("ValidFile_ReturnsOpenPinnedDescriptor", func(t *testing.T) {
		validPath := filepath.Join(tmpDir, "valid_cache_test")
		require.NoError(t, os.WriteFile(validPath, payload, 0o700), "write valid file")

		fd, err := openAndValidateCacheFD(validPath, entry)
		require.NoError(t, err, "expected success for valid file, got")
		defer func() { _ = unix.Close(fd) }()

		if fd < 0 {
			t.Fatalf("expected valid non-negative fd, got %d", fd)
		}

		var stat unix.Stat_t
		if statErr := unix.Fstat(fd, &stat); statErr != nil {
			t.Fatalf("fstat on returned fd failed: %v", statErr)
		}
		if stat.Size != entry.UncompressedSize {
			t.Fatalf("stat size %d does not match uncompressed size %d", stat.Size, entry.UncompressedSize)
		}
	})

	t.Run("ValidFile_DescriptorPinningSurvivesTamperingAndUnlink", func(t *testing.T) {
		pinPath := filepath.Join(tmpDir, "stub_pinning_test")
		require.NoError(t, os.WriteFile(pinPath, payload, 0o700), "write pin file")

		fd, err := openAndValidateCacheFD(pinPath, entry)
		require.NoError(t, err, "expected success for valid file, got")
		defer func() { _ = unix.Close(fd) }()

		// Attacker replaces pathname by renaming a tampered file over it
		tampered := bytes.Repeat([]byte{0x55}, len(payload))
		tamperedPath := pinPath + ".tampered"
		require.NoError(t, os.WriteFile(tamperedPath, tampered, 0o700), "write tampered file")
		require.NoError(t, os.Rename(tamperedPath, pinPath), "rename over pinPath")

		// Read from pinned fd
		buf := make([]byte, len(payload))
		n, preadErr := unix.Pread(fd, buf, 0)
		if preadErr != nil || n != len(payload) || !bytes.Equal(buf, payload) {
			t.Fatalf("pinned fd read mismatch after rename replacement: err=%v, n=%d", preadErr, n)
		}

		// Unlink file completely
		require.NoError(t, os.Remove(pinPath), "unlink pinPath")

		// Pinned fd remains valid after unlinking
		n, preadErr = unix.Pread(fd, buf, 0)
		if preadErr != nil || n != len(payload) || !bytes.Equal(buf, payload) {
			t.Fatalf("pinned fd read mismatch after unlink: err=%v, n=%d", preadErr, n)
		}
	})
}

type failReader struct{}

func (failReader) Read([]byte) (int, error) {
	return 0, errors.New("simulated rand failure")
}

func TestCreateTempFileAt_Errors(t *testing.T) {
	tmpDir := t.TempDir()
	dirFD, err := unix.Open(tmpDir, unix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)
	if err != nil {
		t.Fatalf("open dir: %v", err)
	}
	defer func() { _ = unix.Close(dirFD) }()

	t.Run("InvalidDirFD", func(t *testing.T) {
		fd, _, _, err := createTempFileAt(-1, tmpDir)
		if err == nil {
			_ = unix.Close(fd)
			t.Fatalf("expected error for invalid dirFD, got nil")
		}
	})

	t.Run("CryptoRandReaderError", func(t *testing.T) {
		origRand := cryptoRandReader
		defer func() { cryptoRandReader = origRand }()
		cryptoRandReader = failReader{}

		fd, _, _, err := createTempFileAt(dirFD, tmpDir)
		if err == nil {
			_ = unix.Close(fd)
			t.Fatalf("expected error on rand reader failure, got nil")
		}
	})
}

func TestCacheExecution_PostExtractionValidationFailure(t *testing.T) {
	tmpDir := t.TempDir()
	payload := []byte("post-extraction validation failure scenario")
	entry, rawFile := createDummyVariantFile(t, tmpDir, payload)
	defer rawFile.Close()
	entry.Compression = testCompressionZstd

	hostInfo := microarch.Info{OS: testOSLinux, Arch: testArchAMD64, Level: "v1"}
	policyRes := microarch.PolicyResult{SelectedVariant: "v1"}

	cacheHome := filepath.Join(tmpDir, "cache_post_extract_fail")
	microfatCache := filepath.Join(cacheHome, "microfat")
	if err := os.MkdirAll(microfatCache, 0o700); err != nil {
		t.Fatalf("mkdir failed: %v", err)
	}
	t.Setenv("XDG_CACHE_HOME", cacheHome)

	origOpen := openCachedBinaryFunc
	origOpenAt := openCachedBinaryAtFunc
	defer func() {
		openCachedBinaryFunc = origOpen
		openCachedBinaryAtFunc = origOpenAt
	}()

	callCount := 0
	openCachedBinaryFunc = func(path string) (int, error) {
		callCount++
		if callCount == 1 {
			// First call before extraction: report not existing to trigger extraction
			return -1, os.ErrNotExist
		}
		// Second call after extraction and rename: open a corrupted file instead to simulate tamper/corruption
		corruptedPath := filepath.Join(tmpDir, "post_extract_corrupted")
		_ = os.WriteFile(corruptedPath, bytes.Repeat([]byte{0xFF}, len(payload)), 0o700)
		return origOpen(corruptedPath)
	}
	openCachedBinaryAtFunc = func(dirFD int, name string) (int, error) {
		callCount++
		if callCount == 1 {
			return -1, os.ErrNotExist
		}
		corruptedPath := filepath.Join(tmpDir, "post_extract_corrupted")
		_ = os.WriteFile(corruptedPath, bytes.Repeat([]byte{0xFF}, len(payload)), 0o700)
		return origOpen(corruptedPath)
	}

	err := executeViaCache(
		rawFile.Name(), rawFile, entry, nil,
		[]string{testAppArg}, []string{testPathEnv},
		hostInfo, policyRes, nil, time.Now(),
	)
	if err == nil {
		t.Fatalf("expected error when post-extraction validation fails, got nil")
	}
	if !errors.Is(err, format.ErrCacheWrite) {
		t.Fatalf("expected ErrCacheWrite on post-extraction validation failure, got: %v", err)
	}

	// Verify that destination cache file was removed
	cachedBinary := filepath.Join(microfatCache, entry.SHA256)
	if _, statErr := os.Stat(cachedBinary); !os.IsNotExist(statErr) {
		t.Errorf("expected cached binary %s to be unlinked after post-extraction validation failure", cachedBinary)
	}
}

func TestParsePrewarmArgs(t *testing.T) {
	t.Parallel()

	idx := &format.Index{
		AppName:    "testapp",
		TargetOS:   testOSLinux,
		TargetArch: testArchAMD64,
		Variants: []format.VariantEntry{
			{Level: "v1"},
			{Level: "v2"},
			{Level: "v3"},
		},
	}

	tests := []struct {
		name         string
		arg          string
		defaultLevel string
		idx          *format.Index
		wantLevels   []string
		wantJSON     bool
		wantVerify   bool
		wantErr      bool
	}{
		{
			name:         "BareFlag_UsesDefaultLevel",
			arg:          flagPrewarm,
			defaultLevel: "v1",
			idx:          idx,
			wantLevels:   []string{"v1"},
		},
		{
			name:         "BareFlag_CanonicalizesDefaultLevel",
			arg:          flagPrewarm,
			defaultLevel: "AMD64_V2",
			idx:          idx,
			wantLevels:   []string{"v2"},
		},
		{
			name:         "EmptyFlagValue_UsesDefaultLevel",
			arg:          "--microfat:prewarm=",
			defaultLevel: "v3",
			idx:          idx,
			wantLevels:   []string{"v3"},
		},
		{
			name:         "SingleVariant",
			arg:          "--microfat:prewarm=v2",
			defaultLevel: "v1",
			idx:          idx,
			wantLevels:   []string{"v2"},
		},
		{
			name:         "MultiVariant_CommaSeparated",
			arg:          "--microfat:prewarm=v1,v3",
			defaultLevel: "v2",
			idx:          idx,
			wantLevels:   []string{"v1", "v3"},
		},
		{
			name:         "MultiVariant_AliasCanonicalization",
			arg:          "--microfat:prewarm=amd64_v1,x86_64-v3",
			defaultLevel: "v2",
			idx:          idx,
			wantLevels:   []string{"v1", "v3"},
		},
		{
			name:         "MultiVariant_DeduplicationPreservesOrder",
			arg:          "--microfat:prewarm=v3,v1,v3,amd64_v1",
			defaultLevel: "v2",
			idx:          idx,
			wantLevels:   []string{"v3", "v1"},
		},
		{
			name:         "AllModifier_AppendsAllVariants",
			arg:          "--microfat:prewarm=all",
			defaultLevel: "v1",
			idx:          idx,
			wantLevels:   []string{"v1", "v2", "v3"},
		},
		{
			name:         "AllModifier_CombinedWithVariant_Deduplicated",
			arg:          "--microfat:prewarm=all,v1",
			defaultLevel: "v1",
			idx:          idx,
			wantLevels:   []string{"v1", "v2", "v3"},
		},
		{
			name:         "Variant_CombinedWithAll_PreservesOrder",
			arg:          "--microfat:prewarm=v3,all",
			defaultLevel: "v1",
			idx:          idx,
			wantLevels:   []string{"v3", "v1", "v2"},
		},
		{
			name:         "VerifyModifier_WithVariants",
			arg:          "--microfat:prewarm=v1,v3,verify",
			defaultLevel: "v2",
			idx:          idx,
			wantLevels:   []string{"v1", "v3"},
			wantVerify:   true,
		},
		{
			name:         "JSONModifier_WithVariants",
			arg:          "--microfat:prewarm=v2,json",
			defaultLevel: "v1",
			idx:          idx,
			wantLevels:   []string{"v2"},
			wantJSON:     true,
		},
		{
			name:         "VerifyAndJSONModifiers_Together",
			arg:          "--microfat:prewarm=v1,verify,json",
			defaultLevel: "v2",
			idx:          idx,
			wantLevels:   []string{"v1"},
			wantJSON:     true,
			wantVerify:   true,
		},
		{
			name:         "BareModifiers_NoVariants_UsesDefault",
			arg:          "--microfat:prewarm=verify,json",
			defaultLevel: "v2",
			idx:          idx,
			wantLevels:   []string{"v2"},
			wantJSON:     true,
			wantVerify:   true,
		},
		{
			name:         "WhitespaceAndEmptyTokens",
			arg:          "--microfat:prewarm=v1, , ,v2,",
			defaultLevel: "v3",
			idx:          idx,
			wantLevels:   []string{"v1", "v2"},
		},
		{
			name:         "NonExistentVariant_ReturnsError",
			arg:          "--microfat:prewarm=v1,v99",
			defaultLevel: "v1",
			idx:          idx,
			wantErr:      true,
		},
		{
			name:         "NilIndex_ReturnsErrorOnVariant",
			arg:          "--microfat:prewarm=v1",
			defaultLevel: "v1",
			idx:          nil,
			wantErr:      true,
		},
		{
			name:         "EmptyDefaultLevel_ReturnsNil",
			arg:          flagPrewarm,
			defaultLevel: "",
			idx:          idx,
			wantLevels:   nil,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			levels, jsonOut, verifyOnly, err := parsePrewarmArgs(tc.arg, tc.defaultLevel, tc.idx)
			if tc.wantErr {
				if err == nil {
					t.Fatalf("parsePrewarmArgs(%q) expected error, got nil", tc.arg)
				}
				return
			}
			if err != nil {
				t.Fatalf("parsePrewarmArgs(%q) unexpected error: %v", tc.arg, err)
			}
			if jsonOut != tc.wantJSON {
				t.Errorf("parsePrewarmArgs(%q) json = %v, want %v", tc.arg, jsonOut, tc.wantJSON)
			}
			if verifyOnly != tc.wantVerify {
				t.Errorf("parsePrewarmArgs(%q) verify = %v, want %v", tc.arg, verifyOnly, tc.wantVerify)
			}
			if len(levels) != len(tc.wantLevels) {
				t.Fatalf("parsePrewarmArgs(%q) levels = %v, want %v", tc.arg, levels, tc.wantLevels)
			}
			for i := range levels {
				if levels[i] != tc.wantLevels[i] {
					t.Errorf("parsePrewarmArgs(%q) level[%d] = %q, want %q", tc.arg, i, levels[i], tc.wantLevels[i])
				}
			}
		})
	}
}

func TestBuildAutoTunedEnviron_OriginalExeReflection(t *testing.T) {
	t.Parallel()

	wd, err := os.Getwd()
	if err != nil {
		t.Fatalf("failed to get current working directory: %v", err)
	}

	entry := &format.VariantEntry{
		Level:            "v3",
		Offset:           0,
		CompressedSize:   500,
		UncompressedSize: 1000,
		SHA256:           "abcdef123456",
	}
	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	tests := []struct {
		name        string
		selfPath    string
		baseEnv     []string
		wantOrigExe string
		wantPresent bool
	}{
		{
			name:        "EmptySelfPath_NotPresent",
			selfPath:    "",
			baseEnv:     []string{testPathEnv},
			wantPresent: false,
		},
		{
			name:        "AbsolutePath",
			selfPath:    "/usr/bin/myfat",
			baseEnv:     []string{testPathEnv},
			wantOrigExe: "/usr/bin/myfat",
			wantPresent: true,
		},
		{
			name:        "RelativePathNormalizedToAbsolute",
			selfPath:    "relative/fat_app",
			baseEnv:     []string{testPathEnv},
			wantOrigExe: filepath.Join(wd, "relative", "fat_app"),
			wantPresent: true,
		},
		{
			name:        "PathWithDotSegmentsCleaned",
			selfPath:    "/usr/local/../bin/./myapp",
			baseEnv:     []string{testPathEnv},
			wantOrigExe: "/usr/bin/myapp",
			wantPresent: true,
		},
		{
			name:        "OverridesPreExistingEnvInBase",
			selfPath:    "/usr/bin/new_binary",
			baseEnv:     []string{testPathEnv, format.EnvOriginalExe + "=/legacy/old_binary"},
			wantOrigExe: "/usr/bin/new_binary",
			wantPresent: true,
		},
		{
			name:        "EmptySelfPath_StripsBaseEnvOriginalExe",
			selfPath:    "",
			baseEnv:     []string{testPathEnv, format.EnvOriginalExe + "=/spoofed/path"},
			wantPresent: false,
		},
		{
			name:        "WhitespaceOnlySelfPath_PreservedAsPathnameData",
			selfPath:    "   ",
			baseEnv:     []string{testPathEnv, format.EnvOriginalExe + "=/spoofed/path"},
			wantOrigExe: filepath.Join(wd, "   "),
			wantPresent: true,
		},
		{
			name:        "TrailingSpaceInBasename_Preserved",
			selfPath:    "/usr/bin/app ",
			baseEnv:     []string{testPathEnv},
			wantOrigExe: "/usr/bin/app ",
			wantPresent: true,
		},
		{
			name:        "LeadingSpaceInBasename_Preserved",
			selfPath:    "/usr/bin/ app",
			baseEnv:     []string{testPathEnv},
			wantOrigExe: "/usr/bin/ app",
			wantPresent: true,
		},
		{
			name:        "SpacesInParentDirectories_Preserved",
			selfPath:    "/opt/my app/bin/app",
			baseEnv:     []string{testPathEnv},
			wantOrigExe: "/opt/my app/bin/app",
			wantPresent: true,
		},
		{
			name:        "TabInFilename_Preserved",
			selfPath:    "/usr/bin/app\ttest",
			baseEnv:     []string{testPathEnv},
			wantOrigExe: "/usr/bin/app\ttest",
			wantPresent: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			env, _ := buildAutoTunedEnviron(tt.selfPath, tt.baseEnv, entry, format.ExecModeMemfd, hostInfo, policyRes)

			var gotOrigExe string
			var found bool
			seenCount := 0
			for _, e := range env {
				if strings.HasPrefix(e, format.EnvOriginalExe+"=") {
					seenCount++
					found = true
					gotOrigExe = strings.TrimPrefix(e, format.EnvOriginalExe+"=")
				}
			}

			if tt.wantPresent {
				if !found {
					t.Fatalf("expected %s in env, but not found", format.EnvOriginalExe)
				}
				if seenCount != 1 {
					t.Errorf("expected exactly 1 occurrence of %s, got %d", format.EnvOriginalExe, seenCount)
				}
				if gotOrigExe != tt.wantOrigExe {
					t.Errorf("got %s=%q, want %q", format.EnvOriginalExe, gotOrigExe, tt.wantOrigExe)
				}
			} else if found {
				t.Errorf("expected %s to NOT be present, got %q", format.EnvOriginalExe, gotOrigExe)
			}
		})
	}
}

func TestExecution_OriginalExePropagation(t *testing.T) {
	tempDir := t.TempDir()
	payload := []byte("ORIGINAL_EXE_PROPAGATION_TEST_PAYLOAD")
	entry, rawFile := createDummyVariantFile(t, tempDir, payload)
	defer rawFile.Close()

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	origExec := execveFunc
	defer func() { execveFunc = origExec }()

	expectedAbsPath, err := filepath.Abs(rawFile.Name())
	if err != nil {
		t.Fatalf("resolving abs path: %v", err)
	}

	tests := []struct {
		name     string
		execMode string
		invoke   func(selfPath string, baseEnv []string) error
	}{
		{
			name:     "MemfdExecutionMode",
			execMode: format.ExecModeMemfd,
			invoke: func(selfPath string, baseEnv []string) error {
				return executeViaMemfd(selfPath, rawFile, entry, nil, []string{testAppArg}, baseEnv, hostInfo, policyRes, time.Now())
			},
		},
		{
			name:     "CacheExecutionMode",
			execMode: format.ExecModeCache,
			invoke: func(selfPath string, baseEnv []string) error {
				return executeViaCache(
					selfPath, rawFile, entry, nil, []string{testAppArg}, baseEnv, hostInfo, policyRes, nil, time.Now(),
				)
			},
		},
		{
			name:     "ExecuteVariantAutoMode",
			execMode: "",
			invoke: func(selfPath string, baseEnv []string) error {
				return executeVariant(selfPath, rawFile, entry, nil, []string{testAppArg}, baseEnv, hostInfo, policyRes, time.Now())
			},
		},
		{
			name:     "ExecuteVariant_EmptySelfPath_FallbackToSelfFile",
			execMode: "",
			invoke: func(_ string, baseEnv []string) error {
				return executeVariant("", rawFile, entry, nil, []string{testAppArg}, baseEnv, hostInfo, policyRes, time.Now())
			},
		},
		{
			name:     "ExecuteViaMemfd_EmptySelfPath_FallbackToSelfFile",
			execMode: format.ExecModeMemfd,
			invoke: func(_ string, baseEnv []string) error {
				return executeViaMemfd("", rawFile, entry, nil, []string{testAppArg}, baseEnv, hostInfo, policyRes, time.Now())
			},
		},
		{
			name:     "ExecuteViaCache_EmptySelfPath_FallbackToSelfFile",
			execMode: format.ExecModeCache,
			invoke: func(_ string, baseEnv []string) error {
				return executeViaCache("", rawFile, entry, nil, []string{testAppArg}, baseEnv, hostInfo, policyRes, nil, time.Now())
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.execMode != "" {
				t.Setenv(format.EnvExecMode, tt.execMode)
			} else {
				t.Setenv(format.EnvExecMode, "")
				t.Setenv(format.EnvDispatchMode, "")
			}

			var capturedEnv []string
			execveFunc = func(argv0 string, argv []string, envv []string) error {
				capturedEnv = envv
				return nil
			}

			baseEnv := []string{testPathEnv, format.EnvOriginalExe + "=/stale/fake/path"}
			if err := tt.invoke(rawFile.Name(), baseEnv); err != nil {
				t.Fatalf("execution failed: %v", err)
			}

			var gotOrigExe string
			var found bool
			for _, e := range capturedEnv {
				if strings.HasPrefix(e, format.EnvOriginalExe+"=") {
					found = true
					gotOrigExe = strings.TrimPrefix(e, format.EnvOriginalExe+"=")
				}
			}

			if !found {
				t.Fatalf("expected %s in execve environment, but was missing", format.EnvOriginalExe)
			}
			if gotOrigExe != expectedAbsPath {
				t.Errorf("got %s=%q, want %q (overriding stale path)", format.EnvOriginalExe, gotOrigExe, expectedAbsPath)
			}
		})
	}
}

func TestParseLifecycleOptions(t *testing.T) {
	t.Parallel()

	// Default options
	opts, err := parseLifecycleOptions([]string{})
	require.NoError(t, err)
	assert.Equal(t, lifecycle.PolicyStrict, opts.Policy)
	assert.False(t, opts.BreakHardlinks)

	// Valid policy flag strip
	opts, err = parseLifecycleOptions([]string{"--microfat:metadata-policy=strip"})
	require.NoError(t, err)
	assert.Equal(t, lifecycle.PolicyStrip, opts.Policy)

	// Valid policy flag strict
	opts, err = parseLifecycleOptions([]string{"--microfat:metadata-policy=strict"})
	require.NoError(t, err)
	assert.Equal(t, lifecycle.PolicyStrict, opts.Policy)

	// Valid break hardlinks flag
	opts, err = parseLifecycleOptions([]string{"--microfat:break-hardlinks"})
	require.NoError(t, err)
	assert.True(t, opts.BreakHardlinks)

	// Both flags
	opts, err = parseLifecycleOptions([]string{"--microfat:metadata-policy=strict", "--microfat:break-hardlinks"})
	require.NoError(t, err)
	assert.Equal(t, lifecycle.PolicyStrict, opts.Policy)
	assert.True(t, opts.BreakHardlinks)

	// Invalid policy flag
	_, err = parseLifecycleOptions([]string{"--microfat:metadata-policy=invalid"})
	require.Error(t, err)
}
