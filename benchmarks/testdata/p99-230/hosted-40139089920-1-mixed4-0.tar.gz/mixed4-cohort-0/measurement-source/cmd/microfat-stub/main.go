// Package main provides the microfat launcher stub.
package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/EpicBlackWolfZ/microfat/internal/format"
	"github.com/EpicBlackWolfZ/microfat/internal/inputfile"
	"github.com/EpicBlackWolfZ/microfat/internal/microarch"
)

var (
	exitFunc                  = os.Exit
	getSelfExecutablePathFunc = os.Executable
)

const incompleteArtifactHint = "post-pack ELF rewriting (strip/objcopy) or truncation may have removed or damaged packed data; " +
	"obtain or rebuild a complete artifact and strip inputs before packing"

func main() {
	if err := run(); err != nil {
		if errors.Is(err, errElevatedExecution) {
			fmt.Fprintf(os.Stderr, "[microfat] error: %v\n", err)
			exitFunc(1)
			return
		}
		hint := format.DiagnoseError(format.StageLauncherMain, err)
		if strings.EqualFold(os.Getenv(format.EnvLog), "json") {
			e := format.ErrorTelemetry{
				Event:             format.EventError,
				TimestampUnixNano: time.Now().UnixNano(),
				Stage:             format.StageLauncherMain,
				Error:             err.Error(),
				Hint:              hint,
			}
			fmt.Fprintf(os.Stderr, "[microfat] %s\n", formatErrorTelemetryJSON(e))
		}
		fmt.Fprintf(os.Stderr, "[microfat] error: %v\n", err)
		if hint != "" {
			fmt.Fprintf(os.Stderr, "[microfat:hint] %s\n", hint)
		}
		exitFunc(1)
	}
}

func run() error {
	if err := checkLauncherPrivilegeFunc(); err != nil {
		return err
	}
	selfPath, err := getSelfExecutablePathFunc()
	if err != nil {
		return fmt.Errorf("resolving executable path: %w", err)
	}
	// The pathname is informational metadata. Linux keeps this image alive even
	// after unlink or atomic replacement of the deployment pathname.
	return runImage(selfPath, "/proc/self/exe")
}

func runBinary(selfPath string) error {
	return runImage(selfPath, selfPath)
}

func runImage(selfPath, imagePath string) error {
	if err := checkLauncherPrivilegeFunc(); err != nil {
		return err
	}
	launcherStart := time.Now()

	// #nosec G304 -- launcher opens its own binary image to read payload index
	selfFile, err := inputfile.Open(filepath.Clean(imagePath))
	if err != nil {
		return fmt.Errorf("opening executable %s: %w", selfPath, err)
	}
	defer func() { _ = selfFile.Close() }()

	stat, err := selfFile.Stat()
	if err != nil {
		return fmt.Errorf("stat executable: %w", err)
	}

	if !format.IsFatBinary(selfFile, stat.Size()) {
		return fmt.Errorf("file %s is not a valid microfat fat binary (missing magic trailer); %s", selfPath, incompleteArtifactHint)
	}

	idx, err := format.ReadTrailerAndIndex(selfFile, stat.Size())
	if err != nil {
		return fmt.Errorf("reading binary manifest: %w; %s", err, incompleteArtifactHint)
	}

	hostInfo := microarch.Detect()
	policy := microarch.ReadPolicyFromEnv()
	policyRes, err := microarch.SelectVariantForHost(idx.TargetArch, hostInfo, idx.VariantLevels(), policy)
	if err != nil {
		selectionErr := fmt.Errorf("selecting compatible CPU microarchitecture variant: %w", err)
		if len(os.Args) > 1 {
			handled, metaErr := handleSelectionFailure(os.Args[1], selfFile, stat.Size(), idx, hostInfo, policyRes, selectionErr)
			if handled {
				return metaErr
			}
		}
		return selectionErr
	}

	selectedLevel := policyRes.SelectedVariant
	selectedEntry, found := idx.FindVariant(selectedLevel)
	if !found {
		return fmt.Errorf("internal error: matched variant %s not present in index", selectedLevel)
	}

	// Check for meta-commands
	if len(os.Args) > 1 {
		handled, err := handleMetaCommand(
			os.Args[1], selfPath, selfFile, stat.Size(), idx, hostInfo, selectedEntry, policyRes,
		)
		if handled {
			return err
		}
	}

	// Standard transparent execution
	return executeVariant(selfPath, selfFile, selectedEntry, idx, os.Args, os.Environ(), hostInfo, policyRes, launcherStart)
}
