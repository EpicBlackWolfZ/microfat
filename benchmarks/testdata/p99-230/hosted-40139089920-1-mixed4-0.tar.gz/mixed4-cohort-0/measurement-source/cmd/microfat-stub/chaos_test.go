//go:build !minimal

package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"testing"
	"time"

	"github.com/EpicBlackWolfZ/microfat/internal/cgroup"
	"github.com/EpicBlackWolfZ/microfat/internal/codec"
	"github.com/EpicBlackWolfZ/microfat/internal/format"
	"github.com/EpicBlackWolfZ/microfat/internal/microarch"
	"golang.org/x/sys/unix"
)

// createSyntheticFatFile creates a synthetic fat binary file with a dummy payload.
func createSyntheticFatFile(t *testing.T, payload []byte) (*os.File, *format.VariantEntry, *format.Index) {
	t.Helper()
	tempDir := t.TempDir()
	fatPath := filepath.Join(tempDir, "sample.fat")

	zCodec := codec.NewZstdCodec()
	var compBuf bytes.Buffer
	if err := zCodec.Compress(&compBuf, payload, "default"); err != nil {
		t.Fatalf("failed to compress payload: %v", err)
	}

	compBytes := compBuf.Bytes()
	payloadOffset := int64(64) // 64 bytes mock stub header

	h := sha256.Sum256(payload)
	shaHex := hex.EncodeToString(h[:])

	entry := format.VariantEntry{
		Level:            "v3",
		Offset:           payloadOffset,
		CompressedSize:   int64(len(compBytes)),
		UncompressedSize: int64(len(payload)),
		SHA256:           shaHex,
		Compression:      codec.AlgorithmZstd,
	}

	idx := &format.Index{
		Version:     format.FormatVersion2,
		AppName:     "chaos-app",
		TargetOS:    testOSLinux,
		TargetArch:  testArchAMD64,
		CreatedUnix: time.Now().Unix(),
		Variants:    []format.VariantEntry{entry},
	}

	var fatBuf bytes.Buffer
	fatBuf.Write(make([]byte, payloadOffset)) // Mock stub
	fatBuf.Write(compBytes)                   // Payload

	indexStart := int64(fatBuf.Len())
	if _, err := format.WriteIndexAndTrailerWithVersion(&fatBuf, idx, indexStart, format.FormatVersion2); err != nil {
		t.Fatalf("failed to write index and trailer: %v", err)
	}

	if err := os.WriteFile(fatPath, fatBuf.Bytes(), 0o755); err != nil {
		t.Fatalf("failed to write fat file: %v", err)
	}

	f, err := os.Open(fatPath)
	if err != nil {
		t.Fatalf("failed to open fat file: %v", err)
	}
	t.Cleanup(func() { _ = f.Close() })

	return f, &entry, idx
}

func TestConcurrentCacheRacingStress(t *testing.T) {

	payload := []byte("#!/bin/sh\necho 'microfat-concurrent-execution-payload'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origExecve := execveFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		execveFunc = origExecve
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	var execCount int64
	var mu sync.Mutex
	expectedTarget := filepath.Join(cacheDir, entry.SHA256)
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		mu.Lock()
		execCount++
		mu.Unlock()
		target := argv0
		if link, err := os.Readlink(argv0); err == nil {
			target = strings.TrimSuffix(link, " (deleted)")
		}
		if target != expectedTarget {
			t.Errorf("execve target mismatch: got %q, want %q", target, expectedTarget)
		}
		return nil
	}

	const concurrentWorkers = 50
	var wg sync.WaitGroup
	errCh := make(chan error, concurrentWorkers)

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	for i := range concurrentWorkers {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			err := executeViaCache(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now())
			if err != nil {
				errCh <- fmt.Errorf("worker %d failed: %w", workerID, err)
			}
		}(i)
	}

	wg.Wait()
	close(errCh)

	for err := range errCh {
		if err != nil {
			t.Fatalf("concurrent execution worker error: %v", err)
		}
	}

	if execCount != int64(concurrentWorkers) {
		t.Fatalf("expected %d executions, got %d", concurrentWorkers, execCount)
	}

	// Verify cached file exists, is valid, and matches payload exactly
	cachedFile := filepath.Join(cacheDir, entry.SHA256)
	content, err := os.ReadFile(cachedFile)
	if err != nil {
		t.Fatalf("failed to read cached binary: %v", err)
	}
	if !bytes.Equal(payload, content) {
		t.Fatalf("cached binary content mismatch: got %q, want %q", string(content), string(payload))
	}
}

func TestCorruptedCacheEvictionAndRecovery(t *testing.T) {

	payload := []byte("#!/bin/sh\necho 'microfat-recovery-test'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origExecve := execveFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		execveFunc = origExecve
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	// 1. Plant a truncated/corrupt cache file with wrong size
	cachedFile := filepath.Join(cacheDir, entry.SHA256)
	if err := os.WriteFile(cachedFile, []byte("corrupt-short"), 0o755); err != nil {
		t.Fatalf("failed to plant corrupt cache: %v", err)
	}

	var executed bool
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		executed = true
		return nil
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	// Execute should detect size mismatch, re-extract cleanly, and execute
	err := executeViaCache(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now())
	if err != nil {
		t.Fatalf("executeViaCache failed on corrupted cache recovery: %v", err)
	}
	if !executed {
		t.Fatal("expected execve to be called after recovery")
	}

	// Verify content was restored to real payload
	content, err := os.ReadFile(cachedFile)
	if err != nil {
		t.Fatalf("failed to read recovered cache file: %v", err)
	}
	if !bytes.Equal(payload, content) {
		t.Fatalf("recovered cache content mismatch: got %q, want %q", string(content), string(payload))
	}
}

func TestReadOnlyCacheDirectoryHandling(t *testing.T) {

	payload := []byte("#!/bin/sh\necho 'readonly-cache-test'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	origResolve := resolveCacheDirFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		return -1, "", errors.New("permission denied")
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	err := executeViaCache(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now())
	if err == nil {
		t.Fatal("expected error on read-only cache dir, got nil")
	}
	if !errors.Is(err, format.ErrCacheInit) {
		t.Fatalf("expected ErrCacheInit, got: %v", err)
	}
}

func TestSimulatedSeccompMemfdFallback(t *testing.T) {
	oldExisting := resolveExistingCacheDirFunc
	t.Cleanup(func() { resolveExistingCacheDirFunc = oldExisting })
	resolveExistingCacheDirFunc = func(string) (int, string, error) { return -1, "", os.ErrNotExist }

	payload := []byte("#!/bin/sh\necho 'memfd-fallback-test'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origMemfd := memfdCreateFunc
	origExecve := execveFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		memfdCreateFunc = origMemfd
		execveFunc = origExecve
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	// Simulate strict seccomp filter blocking memfd_create with EPERM
	memfdCreateFunc = func(name string, flags int) (int, error) {
		return -1, syscall.EPERM
	}

	var cacheExecuted bool
	expectedTarget := filepath.Join(cacheDir, entry.SHA256)
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		target := argv0
		if link, err := os.Readlink(argv0); err == nil {
			target = strings.TrimSuffix(link, " (deleted)")
		}
		if target == expectedTarget {
			cacheExecuted = true
			return nil
		}
		return errors.New("unexpected exec path: " + argv0)
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	// executeVariant should try memfd, encounter EPERM, and seamlessly fall back to cache
	err := executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
	if err != nil {
		t.Fatalf("executeVariant failed on seccomp fallback: %v", err)
	}
	if !cacheExecuted {
		t.Fatal("expected cache execution fallback when memfd_create is blocked")
	}
}

func TestMaliciousPathTraversalChecksumBlocked(t *testing.T) {

	payload := []byte("#!/bin/sh\necho 'path-traversal-test'\n")
	fatFile, _, idx := createSyntheticFatFile(t, payload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	maliciousEntry := &format.VariantEntry{
		Level:            "v3",
		Offset:           64,
		CompressedSize:   100,
		UncompressedSize: int64(len(payload)),
		SHA256:           "../../../../tmp/malicious_payload",
		Compression:      codec.AlgorithmZstd,
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	err := executeViaCache(
		fatFile.Name(), fatFile, maliciousEntry, idx,
		[]string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now(),
	)
	if err == nil {
		t.Fatal("expected error on malicious path traversal checksum, got nil")
	}
	if !errors.Is(err, format.ErrCacheWrite) {
		t.Fatalf("expected ErrCacheWrite, got: %v", err)
	}
}

func TestDecompressionBombPayloadBlocked(t *testing.T) {
	const (
		bombPayloadBytes  = 1024 * 1024 // 1 MB
		declaredFakeBytes = 256         // 256 bytes declared
	)

	largePayload := bytes.Repeat([]byte("MICROFAT_HOSTILE_DECOMPRESSION_BOMB_PAYLOAD_TEST_0123456789\n"), bombPayloadBytes/60)

	fatFile, _, idx := createSyntheticFatFile(t, largePayload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origExecve := execveFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		execveFunc = origExecve
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	var execveCalled bool
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		execveCalled = true
		return nil
	}

	// Craft hostile entry with declared fake size much smaller than true payload
	h := sha256.Sum256(largePayload)
	hostileEntry := &format.VariantEntry{
		Level:            "v3",
		Offset:           64,
		CompressedSize:   idx.Variants[0].CompressedSize,
		UncompressedSize: declaredFakeBytes,
		SHA256:           hex.EncodeToString(h[:]),
		Compression:      codec.AlgorithmZstd,
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	t.Run("Blocked on memfd path", func(t *testing.T) {
		execveCalled = false
		err := executeViaMemfd(fatFile.Name(), fatFile, hostileEntry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
		if err == nil {
			t.Fatal("expected error decompressing bomb payload into memfd, got nil")
		}
		if !errors.Is(err, codec.ErrSizeMismatch) {
			t.Fatalf("expected ErrSizeMismatch, got %v", err)
		}
		if execveCalled {
			t.Fatal("execve was called despite decompression bomb error")
		}
	})

	t.Run("Blocked on cache path", func(t *testing.T) {
		execveCalled = false
		err := executeViaCache(fatFile.Name(), fatFile, hostileEntry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now())
		if err == nil {
			t.Fatal("expected error decompressing bomb payload into cache, got nil")
		}
		if !errors.Is(err, format.ErrCacheExtract) || !errors.Is(err, codec.ErrSizeMismatch) {
			t.Fatalf("expected ErrCacheExtract wrapping ErrSizeMismatch, got %v", err)
		}
		if execveCalled {
			t.Fatal("execve was called despite cache decompression error")
		}
	})
}

func TestPayloadChecksumMismatchAbort(t *testing.T) {
	payload := []byte("#!/bin/sh\necho 'microfat-payload-hash-integrity-test'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origExecve := execveFunc
	origMemfd := memfdCreateFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		execveFunc = origExecve
		memfdCreateFunc = origMemfd
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	var execveCalled bool
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		execveCalled = true
		return nil
	}

	// Tampered entry with mismatched SHA256 checksum
	fakeSHA := "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
	tamperedEntry := &format.VariantEntry{
		Level:            entry.Level,
		Offset:           entry.Offset,
		CompressedSize:   entry.CompressedSize,
		UncompressedSize: entry.UncompressedSize,
		SHA256:           fakeSHA,
		Compression:      entry.Compression,
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	t.Run("Mismatched hash fails in extractVariantToWriter", func(t *testing.T) {
		var out bytes.Buffer
		err := extractVariantToWriter(fatFile, tamperedEntry, idx, &out)
		if err == nil {
			t.Fatal("expected error from extractVariantToWriter on tampered hash, got nil")
		}
		if !errors.Is(err, format.ErrPayloadCorrupted) {
			t.Fatalf("expected ErrPayloadCorrupted, got: %v", err)
		}
	})

	t.Run("Blocked on memfd path", func(t *testing.T) {
		execveCalled = false
		err := executeViaMemfd(fatFile.Name(), fatFile, tamperedEntry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
		if err == nil {
			t.Fatal("expected error executing tampered entry via memfd, got nil")
		}
		if !errors.Is(err, format.ErrPayloadCorrupted) {
			t.Fatalf("expected ErrPayloadCorrupted, got: %v", err)
		}
		if execveCalled {
			t.Fatal("execve was called despite payload checksum mismatch on memfd path")
		}
	})

	t.Run("Blocked on cache path", func(t *testing.T) {
		execveCalled = false
		err := executeViaCache(
			fatFile.Name(), fatFile, tamperedEntry, idx,
			[]string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now(),
		)
		if err == nil {
			t.Fatal("expected error executing tampered entry via cache, got nil")
		}
		if !errors.Is(err, format.ErrCacheExtract) || !errors.Is(err, format.ErrPayloadCorrupted) {
			t.Fatalf("expected ErrCacheExtract wrapping ErrPayloadCorrupted, got: %v", err)
		}
		if execveCalled {
			t.Fatal("execve was called despite payload checksum mismatch on cache path")
		}
	})

	t.Run("executeVariant aborts fast without attempting cache fallback", func(t *testing.T) {
		execveCalled = false
		err := executeVariant(fatFile.Name(), fatFile, tamperedEntry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
		if err == nil {
			t.Fatal("expected error executing tampered entry via executeVariant, got nil")
		}
		if !errors.Is(err, format.ErrPayloadCorrupted) {
			t.Fatalf("expected ErrPayloadCorrupted, got: %v", err)
		}
		if execveCalled {
			t.Fatal("execve was called despite payload checksum mismatch in executeVariant")
		}
	})
}

func TestWarmCacheVerifyOption(t *testing.T) {
	payload := []byte("#!/bin/sh\necho 'microfat-warm-cache-verify-payload'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origExecve := execveFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		execveFunc = origExecve
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	cachedBinary := filepath.Join(cacheDir, entry.SHA256)

	// 1. Plant a modified/tampered file with matching size but different content
	tamperedContent := bytes.Repeat([]byte("X"), len(payload))
	if err := os.WriteFile(cachedBinary, tamperedContent, 0o755); err != nil {
		t.Fatalf("failed to plant tampered cache file: %v", err)
	}

	var executedPath string
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		if link, err := os.Readlink(argv0); err == nil {
			executedPath = link
		} else {
			executedPath = argv0
		}
		return nil
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	t.Run("Warm cache hit unconditionally verifies checksum and rejects tampered file even if MICROFAT_VERIFY_CACHE=0", func(t *testing.T) {
		t.Setenv(format.EnvVerifyCache, "0")
		executedPath = ""
		err := executeViaCache(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now())
		if err != nil {
			t.Fatalf("executeViaCache failed: %v", err)
		}
		if executedPath != cachedBinary {
			t.Fatalf("expected execution of %q, got %q", cachedBinary, executedPath)
		}
		diskBytes, err := os.ReadFile(cachedBinary)
		if err != nil {
			t.Fatalf("failed to read cached binary after re-extraction: %v", err)
		}
		if !bytes.Equal(diskBytes, payload) {
			t.Fatalf("expected tampered file to be purged and re-extracted with authentic payload even when MICROFAT_VERIFY_CACHE=0")
		}
	})

	t.Run("Warm cache hit without environment variables invalidates and re-extracts", func(t *testing.T) {
		t.Setenv(format.EnvDebug, "1")
		// Explicitly re-tamper the cache to test default verification
		if err := os.WriteFile(cachedBinary, tamperedContent, 0o700); err != nil {
			t.Fatalf("failed to re-write tampered cache file: %v", err)
		}
		executedPath = ""

		err := executeViaCache(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now())
		if err != nil {
			t.Fatalf("executeViaCache with verify failed: %v", err)
		}
		if executedPath != cachedBinary {
			t.Fatalf("expected execution of %q, got %q", cachedBinary, executedPath)
		}

		// Check that the corrupted cache file was replaced with the real payload
		diskBytes, err := os.ReadFile(cachedBinary)
		if err != nil {
			t.Fatalf("failed to read cached binary after re-extraction: %v", err)
		}
		if !bytes.Equal(diskBytes, payload) {
			t.Fatalf("cached binary content mismatch: got %q, want %q", string(diskBytes), string(payload))
		}
	})
}

func TestOversizedDictionaryChaos(t *testing.T) {
	payload := []byte("#!/bin/sh\necho 'microfat-oversized-dict-payload'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	var execveCalled bool
	origExecve := execveFunc
	t.Cleanup(func() {
		execveFunc = origExecve
	})
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		execveCalled = true
		return nil
	}

	oversizedIdx := *idx
	oversizedIdx.DictionarySize = format.MaxDictionarySize + 1024
	oversizedIdx.DictionaryOffset = 0

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	t.Run("Oversized dictionary fails in extractVariantToWriter", func(t *testing.T) {
		var out bytes.Buffer
		err := extractVariantToWriter(fatFile, entry, &oversizedIdx, &out)
		if err == nil {
			t.Fatal("expected error from extractVariantToWriter on oversized dictionary, got nil")
		}
		if !errors.Is(err, format.ErrInvalidDictionary) {
			t.Fatalf("expected ErrInvalidDictionary, got: %v", err)
		}
	})

	t.Run("Blocked on memfd path", func(t *testing.T) {
		execveCalled = false
		err := executeViaMemfd(fatFile.Name(), fatFile, entry, &oversizedIdx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
		if err == nil {
			t.Fatal("expected error executing oversized dictionary entry via memfd, got nil")
		}
		if !errors.Is(err, format.ErrInvalidDictionary) {
			t.Fatalf("expected ErrInvalidDictionary, got: %v", err)
		}
		if execveCalled {
			t.Fatal("execve was called despite oversized dictionary size on memfd path")
		}
	})

	t.Run("Blocked on cache path", func(t *testing.T) {
		execveCalled = false
		err := executeViaCache(
			fatFile.Name(), fatFile, entry, &oversizedIdx,
			[]string{testAppArg}, []string{}, hostInfo, policyRes, nil, time.Now(),
		)
		if err == nil {
			t.Fatal("expected error executing oversized dictionary entry via cache, got nil")
		}
		if !errors.Is(err, format.ErrCacheExtract) || !errors.Is(err, format.ErrInvalidDictionary) {
			t.Fatalf("expected ErrCacheExtract wrapping ErrInvalidDictionary, got: %v", err)
		}
		if execveCalled {
			t.Fatal("execve was called despite oversized dictionary size on cache path")
		}
	})
}

func TestMemfdSealingVerificationAndImmutability(t *testing.T) {
	payload := []byte("#!/bin/sh\necho 'memfd-sealing-test'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	origExecve := execveFunc
	origSeal := memfdSealFunc
	t.Cleanup(func() {
		execveFunc = origExecve
		memfdSealFunc = origSeal
	})

	var sealedFD int
	var execveCalled bool
	var actualSeals int
	var writeErr error

	execveFunc = func(argv0 string, argv []string, envv []string) error {
		execveCalled = true
		// argv0 is /proc/self/fd/<fd>
		parts := strings.Split(argv0, "/")
		if len(parts) > 0 {
			fdNum, err := strconv.Atoi(parts[len(parts)-1])
			if err == nil {
				sealedFD = fdNum
				// Query active seals on fd
				seals, getErr := unix.FcntlInt(uintptr(sealedFD), unix.F_GET_SEALS, 0)
				if getErr == nil {
					actualSeals = seals
				}
				// Attempt to write to sealed memfd
				_, writeErr = unix.Write(sealedFD, []byte("tampered"))
			}
		}
		return nil
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	err := executeViaMemfd(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
	if err != nil {
		t.Fatalf("executeViaMemfd failed: %v", err)
	}
	if !execveCalled {
		t.Fatal("expected execve to be called")
	}

	expectedSeals := unix.F_SEAL_WRITE | unix.F_SEAL_SHRINK | unix.F_SEAL_GROW | unix.F_SEAL_SEAL
	if actualSeals != expectedSeals {
		t.Errorf("active seals mismatch: got %d, want %d", actualSeals, expectedSeals)
	}

	if writeErr == nil {
		t.Error("expected write to sealed memfd to fail with EPERM/EBUSY, but it succeeded")
	} else if !errors.Is(writeErr, syscall.EPERM) && !errors.Is(writeErr, syscall.EBUSY) {
		t.Errorf("expected write error to be EPERM or EBUSY, got: %v", writeErr)
	}
}

func TestMemfdSealingGracefulFallback(t *testing.T) {
	oldExisting := resolveExistingCacheDirFunc
	t.Cleanup(func() { resolveExistingCacheDirFunc = oldExisting })
	resolveExistingCacheDirFunc = func(string) (int, string, error) { return -1, "", os.ErrNotExist }
	payload := []byte("#!/bin/sh\necho 'memfd-seal-fallback-test'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)

	cacheDir := t.TempDir()
	origResolve := resolveCacheDirFunc
	origExecve := execveFunc
	origSeal := memfdSealFunc
	t.Cleanup(func() {
		resolveCacheDirFunc = origResolve
		execveFunc = origExecve
		memfdSealFunc = origSeal
	})

	resolveCacheDirFunc = func(string) (int, string, error) {
		fd, err := format.OpenAndValidateCacheDirFD(cacheDir, true)
		return fd, cacheDir, err
	}

	testCases := []struct {
		name    string
		sealErr error
	}{
		{name: "ENOSYS", sealErr: syscall.ENOSYS},
		{name: "EINVAL", sealErr: syscall.EINVAL},
		{name: "EPERM", sealErr: syscall.EPERM},
	}

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{}

	for _, tc := range testCases {
		t.Run(tc.name+"_executeViaMemfd_fails_fast", func(t *testing.T) {
			var execveCalled bool
			execveFunc = func(argv0 string, argv []string, envv []string) error {
				execveCalled = true
				return nil
			}
			memfdSealFunc = func(fd int, seals int) error {
				return tc.sealErr
			}

			err := executeViaMemfd(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
			if err == nil {
				t.Fatalf("expected executeViaMemfd to fail on seal error %v, got nil", tc.sealErr)
			}
			if !errors.Is(err, format.ErrMemfdSealingFailed) {
				t.Errorf("expected ErrMemfdSealingFailed in error chain, got: %v", err)
			}
			if execveCalled {
				t.Fatal("execve must NOT be called on unsealed memfd descriptor")
			}
		})

		t.Run(tc.name+"_executeVariant_auto_mode_cache_fallback", func(t *testing.T) {
			t.Setenv(format.EnvExecMode, "")
			t.Setenv(format.EnvDispatchMode, "")
			t.Setenv(format.EnvDebug, "1")

			var cacheExecuted bool
			expectedTarget := filepath.Join(cacheDir, entry.SHA256)
			execveFunc = func(argv0 string, argv []string, envv []string) error {
				target := argv0
				if link, err := os.Readlink(argv0); err == nil {
					target = strings.TrimSuffix(link, " (deleted)")
				}
				if target == expectedTarget {
					cacheExecuted = true
					return nil
				}
				return errors.New("unexpected exec path: " + argv0)
			}
			memfdSealFunc = func(fd int, seals int) error {
				return tc.sealErr
			}

			err := executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
			if err != nil {
				t.Fatalf("expected executeVariant to cleanly fallback to cache on seal error %v, got: %v", tc.sealErr, err)
			}
			if !cacheExecuted {
				t.Fatal("expected cache execution fallback when memfd sealing fails in auto mode")
			}
		})

		t.Run(tc.name+"_executeVariant_explicit_memfd_mode_fails_fast", func(t *testing.T) {
			t.Setenv(format.EnvExecMode, format.ExecModeMemfd)
			t.Setenv(format.EnvDebug, "1")

			var execveCalled bool
			execveFunc = func(argv0 string, argv []string, envv []string) error {
				execveCalled = true
				return nil
			}
			memfdSealFunc = func(fd int, seals int) error {
				return tc.sealErr
			}

			err := executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
			if err == nil {
				t.Fatalf("expected executeVariant to fail in explicit memfd mode on seal error %v, got nil", tc.sealErr)
			}
			if !errors.Is(err, format.ErrMemfdSealingFailed) {
				t.Errorf("expected ErrMemfdSealingFailed, got: %v", err)
			}
			if execveCalled {
				t.Fatal("execve must NOT be called when explicit memfd mode fails")
			}
		})
	}
}

func TestRedTeam_FormatV1_EmptySHA256_Rejected(t *testing.T) {
	origExecve := execveFunc
	defer func() { execveFunc = origExecve }()

	execveCalled := false
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		execveCalled = true
		return nil
	}

	payload := []byte("#!/bin/sh\necho 'untrusted payload'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)
	defer func() { _ = fatFile.Close() }()

	// Poison the entry: Format v1 with empty SHA-256
	entry.SHA256 = ""
	idx.Version = format.FormatVersion1

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{SelectedVariant: entry.Level}

	var buf bytes.Buffer
	err := extractVariantToWriter(fatFile, entry, idx, &buf)
	if err == nil {
		t.Fatal("expected extractVariantToWriter to reject entry with empty SHA-256, got nil")
	}
	if !errors.Is(err, format.ErrInvalidChecksum) {
		t.Fatalf("expected ErrInvalidChecksum, got: %v", err)
	}

	// Also verify executeVariant rejects it in memfd mode
	t.Setenv(format.EnvExecMode, format.ExecModeMemfd)
	execErr := executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
	if execErr == nil {
		t.Fatal("expected executeVariant to fail when variant has empty SHA-256")
	}
	if execveCalled {
		t.Fatal("execve must NOT be called for variant with empty SHA-256")
	}
}

func TestRedTeam_InvalidDimensions_Rejected(t *testing.T) {
	payload := []byte("TEST_PAYLOAD")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)
	defer func() { _ = fatFile.Close() }()

	var buf bytes.Buffer

	// Negative uncompressed size
	entry.UncompressedSize = -10
	err := extractVariantToWriter(fatFile, entry, idx, &buf)
	if err == nil || !errors.Is(err, format.ErrPayloadTooLarge) {
		t.Fatalf("expected ErrPayloadTooLarge for negative uncompressed size, got %v", err)
	}

	// Zero uncompressed size
	entry.UncompressedSize = 0
	err = extractVariantToWriter(fatFile, entry, idx, &buf)
	if err == nil || !errors.Is(err, format.ErrPayloadTooLarge) {
		t.Fatalf("expected ErrPayloadTooLarge for zero uncompressed size, got %v", err)
	}

	// Oversized uncompressed size > MaxPayloadSize
	entry.UncompressedSize = format.MaxPayloadSize + 1
	err = extractVariantToWriter(fatFile, entry, idx, &buf)
	if err == nil || !errors.Is(err, format.ErrPayloadTooLarge) {
		t.Fatalf("expected ErrPayloadTooLarge for oversized uncompressed size, got %v", err)
	}
}

func TestRedTeam_EnvironmentVariableSanitization(t *testing.T) {
	spoofedBaseEnv := []string{
		"PATH=/usr/bin:/bin",
		"USER=victim",
		format.EnvOriginalExe + "=/opt/fake/binary",
		format.EnvCgroupVersion + "=2",
		format.EnvCgroupLimitBytes + "=9999999999",
		format.EnvCgroupCPUs + "=128.00",
		format.EnvPolicyApplied + "=spoofed_policy",
		format.EnvOverrideReason + "=spoofed_reason",
		format.EnvSelectedVariant + "=fake_v4",
		format.EnvSelectedSHA256 + "=fake_sha",
	}

	entry := &format.VariantEntry{
		Level:            "v1",
		UncompressedSize: 1024,
		SHA256:           "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
	}
	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v1"}
	policyRes := microarch.PolicyResult{}

	origReadCgroup := readCgroupLimitsFunc
	defer func() { readCgroupLimitsFunc = origReadCgroup }()
	readCgroupLimitsFunc = func() (cgroup.Limits, error) {
		return cgroup.Limits{CgroupVersion: cgroup.VersionUnknown}, nil
	}

	env, _ := buildAutoTunedEnviron("/real/path/to/app", spoofedBaseEnv, entry, format.ExecModeMemfd, hostInfo, policyRes)

	envMap := make(map[string]string)
	for _, e := range env {
		k, v, ok := strings.Cut(e, "=")
		if ok {
			envMap[k] = v
		}
	}

	if envMap[format.EnvOriginalExe] != "/real/path/to/app" {
		t.Errorf("expected %s to be set to /real/path/to/app, got %q", format.EnvOriginalExe, envMap[format.EnvOriginalExe])
	}
	if _, exists := envMap[format.EnvCgroupVersion]; exists {
		t.Errorf("spoofed %s leaked into environment", format.EnvCgroupVersion)
	}
	if _, exists := envMap[format.EnvCgroupLimitBytes]; exists {
		t.Errorf("spoofed %s leaked into environment", format.EnvCgroupLimitBytes)
	}
	if _, exists := envMap[format.EnvCgroupCPUs]; exists {
		t.Errorf("spoofed %s leaked into environment", format.EnvCgroupCPUs)
	}
	if _, exists := envMap[format.EnvPolicyApplied]; exists {
		t.Errorf("spoofed %s leaked into environment", format.EnvPolicyApplied)
	}
	if _, exists := envMap[format.EnvOverrideReason]; exists {
		t.Errorf("spoofed %s leaked into environment", format.EnvOverrideReason)
	}
	if envMap[format.EnvSelectedVariant] != "v1" {
		t.Errorf("expected %s=v1, got %q", format.EnvSelectedVariant, envMap[format.EnvSelectedVariant])
	}
}

func TestRedTeam_DecompressionError_DoesNotFallbackToPreExistingCache(t *testing.T) {
	origExecve := execveFunc
	defer func() { execveFunc = origExecve }()

	execveCalled := false
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		execveCalled = true
		return nil
	}

	payload := []byte("#!/bin/sh\necho 'valid initial binary'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)
	defer func() { _ = fatFile.Close() }()

	cacheDir := t.TempDir()
	t.Setenv("XDG_CACHE_HOME", cacheDir)
	t.Setenv(format.EnvExecMode, format.ExecModeMemfd)
	t.Setenv(format.EnvDispatchMode, "")

	// Pre-populate cache directory with entry.SHA256
	microfatCacheDir := filepath.Join(cacheDir, "microfat")
	if err := os.MkdirAll(microfatCacheDir, 0o700); err != nil {
		t.Fatalf("failed to create cache dir: %v", err)
	}
	cachedBinPath := filepath.Join(microfatCacheDir, entry.SHA256)
	if err := os.WriteFile(cachedBinPath, payload, 0o700); err != nil {
		t.Fatalf("failed to write cached binary: %v", err)
	}

	// Corrupt payload stream in the fat file
	corruptBytes := make([]byte, entry.CompressedSize)
	for i := range corruptBytes {
		corruptBytes[i] = 0xFF
	}
	fRw, err := os.OpenFile(fatFile.Name(), os.O_WRONLY, 0)
	if err != nil {
		t.Fatalf("failed to open fat file for writing: %v", err)
	}
	if _, err := fRw.WriteAt(corruptBytes, entry.Offset); err != nil {
		_ = fRw.Close()
		t.Fatalf("failed to corrupt payload: %v", err)
	}
	_ = fRw.Close()

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{SelectedVariant: entry.Level}

	execErr := executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
	if execErr == nil {
		t.Fatal("expected executeVariant to fail on corrupted payload stream, but succeeded")
	}
	if execveCalled {
		t.Fatal("security violation: launcher executed pre-existing cached binary despite corrupted fat binary payload")
	}
}

func TestRedTeam_ChecksumMismatch_DoesNotFallbackToPreExistingCache(t *testing.T) {
	origExecve := execveFunc
	defer func() { execveFunc = origExecve }()

	execveCalled := false
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		execveCalled = true
		return nil
	}

	payload := []byte("#!/bin/sh\necho 'valid initial binary'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)
	defer func() { _ = fatFile.Close() }()

	cacheDir := t.TempDir()
	t.Setenv("XDG_CACHE_HOME", cacheDir)
	t.Setenv(format.EnvExecMode, format.ExecModeMemfd)
	t.Setenv(format.EnvDispatchMode, "")

	// Pre-populate cache directory with authentic entry.SHA256
	microfatCacheDir := filepath.Join(cacheDir, "microfat")
	if err := os.MkdirAll(microfatCacheDir, 0o700); err != nil {
		t.Fatalf("failed to create cache dir: %v", err)
	}
	cachedBinPath := filepath.Join(microfatCacheDir, entry.SHA256)
	if err := os.WriteFile(cachedBinPath, payload, 0o700); err != nil {
		t.Fatalf("failed to write cached binary: %v", err)
	}

	// Tamper payload: compress DIFFERENT bytes into the payload region
	// so decompression cleanly succeeds, but SHA-256 calculation produces a mismatch.
	differentPayload := []byte("#!/bin/sh\necho 'tampered payload content!'\n")
	zCodec := codec.NewZstdCodec()
	var compBuf bytes.Buffer
	if err := zCodec.Compress(&compBuf, differentPayload, "default"); err != nil {
		t.Fatalf("failed to compress different payload: %v", err)
	}
	tamperedCompBytes := compBuf.Bytes()

	entry.CompressedSize = int64(len(tamperedCompBytes))
	entry.UncompressedSize = int64(len(differentPayload))
	// Crucially, leave entry.SHA256 unchanged, pointing to the original legitimate payload digest!

	fRw, err := os.OpenFile(fatFile.Name(), os.O_RDWR, 0)
	if err != nil {
		t.Fatalf("failed to open fat file for writing: %v", err)
	}
	if _, err := fRw.WriteAt(tamperedCompBytes, entry.Offset); err != nil {
		_ = fRw.Close()
		t.Fatalf("failed to write tampered payload: %v", err)
	}
	_ = fRw.Close()

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{SelectedVariant: entry.Level}

	execErr := executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
	if execErr == nil {
		t.Fatal("expected executeVariant to fail on checksum mismatch, but succeeded")
	}
	if !errors.Is(execErr, format.ErrPayloadCorrupted) {
		t.Fatalf("expected ErrPayloadCorrupted on checksum mismatch, got %v", execErr)
	}
	if execveCalled {
		t.Fatal("security violation: launcher executed pre-existing cached binary despite payload checksum mismatch")
	}
}

func TestRedTeam_FileDescriptorHygiene_NoLeakOnExecveFailure(t *testing.T) {
	origExecve := execveFunc
	defer func() { execveFunc = origExecve }()

	// Mock execve to fail with EPERM (simulating seccomp filter blocking execve)
	execveFunc = func(argv0 string, argv []string, envv []string) error {
		return syscall.EPERM
	}

	payload := []byte("#!/bin/sh\necho 'fd hygiene test'\n")
	fatFile, entry, idx := createSyntheticFatFile(t, payload)
	defer func() { _ = fatFile.Close() }()

	cacheDir := t.TempDir()
	t.Setenv("XDG_CACHE_HOME", cacheDir)

	getOpenFDs := func() map[string]string {
		fds := make(map[string]string)
		entries, err := os.ReadDir("/proc/self/fd")
		if err != nil {
			return fds
		}
		for _, e := range entries {
			target, err := os.Readlink(filepath.Join("/proc/self/fd", e.Name()))
			if err == nil {
				fds[e.Name()] = target
			}
		}
		return fds
	}

	baselineFDs := getOpenFDs()

	hostInfo := microarch.Info{Arch: testArchAMD64, Level: "v3"}
	policyRes := microarch.PolicyResult{SelectedVariant: entry.Level}

	// 1. Test in memfd mode
	t.Setenv(format.EnvExecMode, format.ExecModeMemfd)
	err := executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
	if err == nil || !errors.Is(err, format.ErrExecve) {
		t.Fatalf("expected ErrExecve from executeVariant in memfd mode, got %v", err)
	}

	postMemfdFDs := getOpenFDs()
	for fd, target := range postMemfdFDs {
		if _, existed := baselineFDs[fd]; !existed {
			if strings.Contains(target, "memfd") || strings.Contains(target, "microfat") {
				t.Fatalf("FD leak detected after memfd execve failure: fd %s -> %s", fd, target)
			}
		}
	}

	// 2. Test in cache mode
	t.Setenv(format.EnvExecMode, format.ExecModeCache)
	err = executeVariant(fatFile.Name(), fatFile, entry, idx, []string{testAppArg}, []string{}, hostInfo, policyRes, time.Now())
	if err == nil || !errors.Is(err, format.ErrExecve) {
		t.Fatalf("expected ErrExecve from executeVariant in cache mode, got %v", err)
	}

	postCacheFDs := getOpenFDs()
	for fd, target := range postCacheFDs {
		if _, existed := baselineFDs[fd]; !existed {
			if strings.Contains(target, "microfat") || strings.Contains(target, cacheDir) {
				t.Fatalf("FD leak detected after cache execve failure: fd %s -> %s", fd, target)
			}
		}
	}
}
