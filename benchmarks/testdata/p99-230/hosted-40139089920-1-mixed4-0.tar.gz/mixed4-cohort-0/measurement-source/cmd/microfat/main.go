// Package main provides the microfat CLI developer and CI toolkit.
package main

import (
	"context"
	"encoding/json/jsontext"
	json "encoding/json/v2"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	// #nosec G108 -- opt-in profiling endpoint explicitly controlled via --pprof-port / MICROFAT_PPROF_PORT
	_ "net/http/pprof"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"github.com/EpicBlackWolfZ/microfat/internal/builder"
	"github.com/EpicBlackWolfZ/microfat/internal/codec"
	"github.com/EpicBlackWolfZ/microfat/internal/format"
	"github.com/EpicBlackWolfZ/microfat/internal/inputfile"
	"github.com/EpicBlackWolfZ/microfat/internal/lifecycle"
	"github.com/EpicBlackWolfZ/microfat/internal/microarch"
	"github.com/EpicBlackWolfZ/microfat/internal/pack"
	"github.com/EpicBlackWolfZ/microfat/internal/version"
	"github.com/spf13/cobra"
)

const (
	percentMultiplier       = 100.0
	keyValueParts           = 2
	defaultDirMode          = 0o750
	pprofHeaderTimeoutSec   = 3
	pprofReadHeaderTimeout  = pprofHeaderTimeoutSec * time.Second
	sourceDateEpochEnv      = "SOURCE_DATE_EPOCH"
	creationDateUnavailable = "unavailable"
	// UTC RFC3339 dates have four-digit years, from 0000 through 9999.
	minCreationDateUnix int64 = -62167219200
	maxCreationDateUnix int64 = 253402300799
)

var exitFunc = os.Exit

func main() {
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	rootCmd := newRootCmd()
	if err := rootCmd.ExecuteContext(ctx); err != nil {
		var updateErr updateCommandError
		if errors.As(err, &updateErr) {
			_, _ = fmt.Fprintln(rootCmd.ErrOrStderr(), "microfat update:", err)
			exitFunc(updateErr.code)
			return
		}
		exitFunc(1)
	}
}

func startPprofServer(ctx context.Context, port string, logWriter io.Writer) error {
	addr := net.JoinHostPort("localhost", port)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	_, _ = fmt.Fprintf(logWriter, "[microfat:pprof] serving pprof endpoints at http://%s/debug/pprof/\n", ln.Addr().String())
	server := &http.Server{
		ReadHeaderTimeout: pprofReadHeaderTimeout,
	}
	serverClosed := make(chan struct{})
	go func() {
		_ = server.Serve(ln)
		close(serverClosed)
	}()
	if ctx != nil && ctx.Done() != nil {
		go func() {
			select {
			case <-ctx.Done():
				_ = server.Close()
				_ = ln.Close()
			case <-serverClosed:
			}
		}()
	}
	return nil
}

func newRootCmd() *cobra.Command {
	var (
		showVersion        bool
		pprofPort          string
		pprofBlockRate     int
		pprofMutexFraction int
	)

	cmd := &cobra.Command{
		Use:   "microfat",
		Short: "Microfat - Dynamic CPU Microarchitecture Optimization and Packaging Tool",
		Long: `Microfat combines multiple microarchitecture-specific Go ELF binaries into a single,
self-dispatching fat executable with zero persistent process overhead and payload integrity verification.`,
		PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
			port := pprofPort
			if port == "" {
				port = os.Getenv("MICROFAT_PPROF_PORT")
			}
			blockRate := pprofBlockRate
			if blockRate == 0 {
				if envVal := os.Getenv("MICROFAT_PPROF_BLOCK_RATE"); envVal != "" {
					if parsed, err := strconv.Atoi(envVal); err == nil && parsed > 0 {
						blockRate = parsed
					}
				}
			}
			mutexFraction := pprofMutexFraction
			if mutexFraction == 0 {
				if envVal := os.Getenv("MICROFAT_PPROF_MUTEX_FRACTION"); envVal != "" {
					if parsed, err := strconv.Atoi(envVal); err == nil && parsed > 0 {
						mutexFraction = parsed
					}
				}
			}

			if blockRate > 0 {
				runtime.SetBlockProfileRate(blockRate)
			}
			if mutexFraction > 0 {
				runtime.SetMutexProfileFraction(mutexFraction)
			}

			if port != "" {
				if err := startPprofServer(cmd.Context(), port, cmd.ErrOrStderr()); err != nil {
					return fmt.Errorf("starting pprof server on port %s: %w", port, err)
				}
			}
			return nil
		},
		RunE: func(cmd *cobra.Command, args []string) error {
			if showVersion {
				fmt.Println(version.Info())
				return nil
			}
			return cmd.Help()
		},
	}

	cmd.Flags().BoolVarP(&showVersion, "version", "v", false, "Print version and build info")
	cmd.PersistentFlags().StringVar(&pprofPort, "pprof-port", "",
		"Port to run background pprof server (or via MICROFAT_PPROF_PORT env var)")
	cmd.PersistentFlags().IntVar(&pprofBlockRate, "pprof-block-rate", 0,
		"Block profile sampling rate (or via MICROFAT_PPROF_BLOCK_RATE env var)")
	cmd.PersistentFlags().IntVar(&pprofMutexFraction, "pprof-mutex-fraction", 0,
		"Mutex profile sampling fraction (or via MICROFAT_PPROF_MUTEX_FRACTION env var)")

	cmd.AddCommand(newDetectCmd())
	cmd.AddCommand(newInspectCmd())
	cmd.AddCommand(newVerifyCmd())
	cmd.AddCommand(newTrimCmd())
	cmd.AddCommand(newPackCmd())
	cmd.AddCommand(newPgoPackCmd())
	cmd.AddCommand(newPrewarmCmd())
	cmd.AddCommand(newDoctorCmd())
	cmd.AddCommand(newUpdateCmd())
	cmd.AddCommand(newBenchmarkCmd())

	return cmd
}

func newDetectCmd() *cobra.Command {
	var jsonOutput bool

	cmd := &cobra.Command{
		Use:   "detect",
		Short: "Detect host CPU microarchitecture level and features",
		RunE: func(cmd *cobra.Command, args []string) error {
			info := microarch.Detect()
			if jsonOutput {
				if err := json.MarshalWrite(os.Stdout, info, jsontext.WithIndent("  ")); err != nil {
					return fmt.Errorf("encoding json: %w", err)
				}
				fmt.Println()
				return nil
			}

			fmt.Printf("OS:       %s\n", info.OS)
			fmt.Printf("Arch:     %s\n", info.Arch)
			fmt.Printf("Level:    %s\n", info.Level)
			fmt.Printf("Features: %s\n", strings.Join(info.Features, ", "))
			return nil
		},
	}

	cmd.Flags().BoolVar(&jsonOutput, "json", false, "Output results in JSON format")
	return cmd
}

func newInspectCmd() *cobra.Command {
	var jsonOutput bool

	cmd := &cobra.Command{
		Use:     "inspect <binary>",
		Aliases: []string{"info"},
		Short:   "Inspect embedded variants and metadata inside a microfat binary",
		Args:    cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			path := filepath.Clean(args[0])
			// #nosec G304 -- user-supplied binary path to inspect
			f, err := inputfile.Open(path)
			if err != nil {
				return fmt.Errorf("opening %s: %w", path, err)
			}
			defer func() { _ = f.Close() }()

			stat, err := f.Stat()
			if err != nil {
				return fmt.Errorf("stat %s: %w", path, err)
			}

			if !format.IsFatBinary(f, stat.Size()) {
				return fmt.Errorf("'%s' is not a valid microfat fat binary (missing magic trailer)", path)
			}

			idx, err := format.ReadTrailerAndIndex(f, stat.Size())
			if err != nil {
				return fmt.Errorf("reading binary manifest: %w", err)
			}

			if idx.Version == format.FormatVersion1 {
				_, _ = fmt.Fprintf(
					cmd.ErrOrStderr(),
					"[microfat:warn] binary %q uses legacy Format v1 JSON manifest; "+
						"Format v1 is deprecated and scheduled for removal in v0.4.0 (use Format v2 for production)\n",
					path,
				)
			}

			if jsonOutput {
				if err := json.MarshalWrite(cmd.OutOrStdout(), idx, jsontext.WithIndent("  ")); err != nil {
					return fmt.Errorf("encoding json: %w", err)
				}
				_, _ = fmt.Fprintln(cmd.OutOrStdout())
				return nil
			}

			out := cmd.OutOrStdout()
			_, _ = fmt.Fprintf(out, "Binary Path:       %s\n", path)
			_, _ = fmt.Fprintf(out, "App Name:          %s\n", idx.AppName)
			_, _ = fmt.Fprintf(out, "Format Version:    v%d (%s)\n", idx.Version, formatVersionName(idx.Version))
			_, _ = fmt.Fprintf(out, "Target Platform:   %s/%s\n", idx.TargetOS, idx.TargetArch)
			_, _ = fmt.Fprintf(out, "Total Size:        %d bytes\n", stat.Size())
			if idx.DictionarySize > 0 {
				_, _ = fmt.Fprintf(out, "Shared Dictionary: %d bytes (offset %d, sha256: %.12s...)\n",
					idx.DictionarySize, idx.DictionaryOffset, idx.DictionarySHA256)
			}
			_, _ = fmt.Fprintf(out, "Created At:        %s\n", creationDate(idx.CreatedUnix))
			_, _ = fmt.Fprintf(out, "Created Unix:      %d\n\n", idx.CreatedUnix)

			_, _ = fmt.Fprintf(out, "Embedded Variants (%d total):\n", len(idx.Variants))
			for _, v := range idx.Variants {
				ratio := float64(v.CompressedSize) / float64(v.UncompressedSize) * percentMultiplier
				_, _ = fmt.Fprintf(out, "  • %-6s [%s] offset: %10d | comp: %10d B | raw: %10d B (%.1f%%) | sha256: %.12s...\n",
					v.Level, v.Compression, v.Offset, v.CompressedSize, v.UncompressedSize, ratio, v.SHA256)
			}
			return nil
		},
	}

	cmd.Flags().BoolVar(&jsonOutput, "json", false, "Output results in JSON format")
	return cmd
}

func newVerifyCmd() *cobra.Command {
	var jsonOutput bool

	cmd := &cobra.Command{
		Use:   "verify <binary>",
		Short: "Validate trailer, index SHA-256 hash, and payload integrity of all embedded variants",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			path := filepath.Clean(args[0])
			// #nosec G304 -- user-supplied binary path to verify
			f, err := inputfile.Open(path)
			if err != nil {
				return fmt.Errorf("opening %s: %w", path, err)
			}
			defer func() { _ = f.Close() }()

			stat, err := f.Stat()
			if err != nil {
				return fmt.Errorf("stat %s: %w", path, err)
			}

			idx, results, err := pack.VerifyBinary(f, stat.Size())
			if err != nil {
				return fmt.Errorf("verification failed: %w", err)
			}

			if jsonOutput {
				out := struct {
					AppName string                    `json:"app_name"`
					Valid   bool                      `json:"valid"`
					Results []pack.VerificationResult `json:"results"`
				}{
					AppName: idx.AppName,
					Valid:   true,
					Results: results,
				}
				for _, r := range results {
					if !r.Valid {
						out.Valid = false
						break
					}
				}
				if err := json.MarshalWrite(cmd.OutOrStdout(), out, jsontext.WithIndent("  ")); err != nil {
					return fmt.Errorf("encoding json: %w", err)
				}
				_, _ = fmt.Fprintln(cmd.OutOrStdout())
				if !out.Valid {
					return fmt.Errorf("one or more variants failed checksum/integrity verification")
				}
				return nil
			}

			out := cmd.OutOrStdout()
			_, _ = fmt.Fprintf(out, "Verifying '%s' (%s - %s/%s)...\n\n", path, idx.AppName, idx.TargetOS, idx.TargetArch)
			allValid := true
			for _, r := range results {
				if r.Valid {
					_, _ = fmt.Fprintf(out, "  [PASS] Variant %-6s (size: %d B, sha256: %.16s...)\n", r.Level, r.UncompressedSize, r.ActualSHA256)
				} else {
					allValid = false
					_, _ = fmt.Fprintf(out, "  [FAIL] Variant %-6s: %v\n", r.Level, r.Error)
				}
			}

			_, _ = fmt.Fprintln(out)
			if allValid {
				_, _ = fmt.Fprintln(out, "Result: All embedded variants verified successfully with matching SHA-256 checksums.")
				return nil
			}
			return fmt.Errorf("one or more variants failed checksum/integrity verification")
		},
	}

	cmd.Flags().BoolVar(&jsonOutput, "json", false, "Output results in JSON format")
	return cmd
}

func newTrimCmd() *cobra.Command {
	var (
		outputPath        string
		targetLevel       string
		maxLevel          string
		disabledVariants  string
		policyName        string
		metadataPolicyStr string
		breakHardlinks    bool
	)

	cmd := &cobra.Command{
		Use:   "trim <binary> [-o <output>] [--level <level>]",
		Short: "Trim away unneeded variant payloads, keeping the launcher stub and selected variant",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			if cmd.Flags().Changed("output") {
				if outputPath == "" {
					return errors.New("destination output path cannot be empty")
				}
			}

			metaPolicy, err := lifecycle.ParsePolicy(metadataPolicyStr)
			if err != nil {
				return err
			}
			srcPath := filepath.Clean(args[0])
			// #nosec G304 -- user-supplied binary path to trim
			f, err := inputfile.Open(srcPath)
			if err != nil {
				return fmt.Errorf("opening %s: %w", srcPath, err)
			}
			defer func() { _ = f.Close() }()

			stat, err := f.Stat()
			if err != nil {
				return fmt.Errorf("stat %s: %w", srcPath, err)
			}

			if !format.IsFatBinary(f, stat.Size()) {
				return fmt.Errorf("'%s' is not a valid microfat fat binary (missing magic trailer)", srcPath)
			}

			idx, err := format.ReadTrailerAndIndex(f, stat.Size())
			if err != nil {
				return fmt.Errorf("reading binary manifest: %w", err)
			}

			policy := microarch.ReadPolicyFromEnv()
			if targetLevel != "" {
				policy.ForceLevel = targetLevel
			}
			if maxLevel != "" {
				policy.MaxLevel = maxLevel
			}
			if disabledVariants != "" {
				for v := range strings.SplitSeq(disabledVariants, ",") {
					v = strings.TrimSpace(v)
					if v != "" {
						policy.DisabledVariants = append(policy.DisabledVariants, v)
					}
				}
			}
			if policyName != "" {
				policy.Name = strings.ToLower(strings.TrimSpace(policyName))
			}

			hostInfo := microarch.Detect()
			var policyRes microarch.PolicyResult
			var selErr error
			if targetLevel != "" {
				// Explicit trimming transforms an artifact; it does not execute it on this host.
				policyRes, selErr = microarch.SelectVariantWithPolicy(idx.TargetArch, targetLevel, idx.VariantLevels(), policy)
			} else {
				policyRes, selErr = microarch.SelectVariantForHost(idx.TargetArch, hostInfo, idx.VariantLevels(), policy)
			}
			if selErr != nil {
				return fmt.Errorf("selecting optimal variant with policy: %w", selErr)
			}
			targetLevel = policyRes.SelectedVariant

			intent := lifecycle.IntentReplaceSource
			destPath := srcPath
			if cmd.Flags().Changed("output") {
				intent = lifecycle.IntentCreateOnly
				destPath = filepath.Clean(outputPath)
			} else {
				realPath, err := filepath.EvalSymlinks(srcPath)
				if err == nil && realPath != srcPath {
					fmt.Printf("[microfat] Notice: resolved symlink '%s' -> target '%s'\n", srcPath, realPath)
					destPath = realPath
				}
			}

			var newIdx *format.Index
			err = lifecycle.Execute(lifecycle.Transaction{
				SrcPath:  srcPath,
				SrcFile:  f,
				DestPath: destPath,
				Intent:   intent,
				Opts: lifecycle.Options{
					Policy:         metaPolicy,
					BreakHardlinks: breakHardlinks,
				},
				Transform: func(staged *os.File) error {
					var trimErr error
					newIdx, trimErr = pack.TrimBinary(f, stat.Size(), targetLevel, staged)
					return trimErr
				},
			})
			if err != nil {
				return fmt.Errorf("trimming binary: %w", err)
			}

			newStat, _ := os.Stat(destPath)
			var newSize int64
			if newStat != nil {
				newSize = newStat.Size()
			}

			fmt.Printf("Successfully trimmed '%s' to variant '%s':\n", destPath, targetLevel)
			fmt.Printf("  • Size: %d bytes -> %d bytes\n", stat.Size(), newSize)
			fmt.Printf("  • Variants: %d embedded (%s)\n", len(newIdx.Variants), targetLevel)
			if policyRes.PolicyApplied != "" {
				fmt.Printf("  • Policy: %s (%s)\n", policyRes.PolicyApplied, policyRes.OverrideReason)
			}
			return nil
		},
	}

	cmd.Flags().StringVarP(&outputPath, "output", "o", "", "Destination output path (defaults to in-place replacement)")
	cmd.Flags().StringVar(&targetLevel, "level", "", "Target microarchitecture level to retain (defaults to auto-detected host level)")
	cmd.Flags().StringVar(&maxLevel, "max-level", "", "Maximum microarchitecture level ceiling to retain")
	cmd.Flags().StringVar(&disabledVariants, "disable-variants", "", "Comma-separated list of variant levels to exclude")
	cmd.Flags().StringVar(&policyName, "policy", "", "Policy preset name (e.g. safe_avx512, no_downclock)")
	cmd.Flags().StringVar(&metadataPolicyStr, "metadata-policy", "strict", "Metadata preservation policy: 'strict' (default) or 'strip'")
	cmd.Flags().BoolVar(&breakHardlinks, "break-hardlinks", false,
		"Allow in-place transformation to break hard links if multi-link file is detected")

	return cmd
}

func validateEmptyStubFlags(cmd *cobra.Command, flags builder.BuildOptions) error {
	if cmd.Flags().Changed("stub") && flags.StubPath == "" {
		return errors.New("flag --stub cannot be empty")
	}
	if cmd.Flags().Changed("stub-profile") && strings.TrimSpace(flags.StubProfile) == "" {
		return errors.New("flag --stub-profile cannot be empty")
	}
	return nil
}

func parseRawVariants(rawVariants []string) (map[string]string, error) {
	variants := make(map[string]string, len(rawVariants))
	for _, item := range rawVariants {
		parts := strings.SplitN(item, "=", keyValueParts)
		if len(parts) != keyValueParts || parts[0] == "" || parts[1] == "" {
			return nil, fmt.Errorf("invalid variant specification %q, expected <level>=<path> (e.g. v3=dist/app_v3)", item)
		}
		level := parts[0]
		if _, exists := variants[level]; exists {
			return nil, fmt.Errorf("duplicate variant level %q specified", level)
		}
		variants[level] = parts[1]
	}
	return variants, nil
}

func cmdWarnFunc(cmd *cobra.Command) func(string, ...any) {
	return func(format string, args ...any) {
		var msg string
		if len(args) == 0 {
			msg = format
		} else {
			msg = fmt.Sprintf(format, args...)
		}
		_, _ = fmt.Fprintln(cmd.ErrOrStderr(), msg)
	}
}

// sourceDateEpoch resolves the packaging epoch without modifying the environment
// inherited by compiler and other build children.
func sourceDateEpoch() (*int64, error) {
	raw, present := os.LookupEnv(sourceDateEpochEnv)
	if !present {
		return nil, nil
	}
	epoch, err := strconv.ParseInt(raw, 10, 64)
	if err != nil {
		return nil, fmt.Errorf("invalid %s %q: expected signed ASCII base-10 integer Unix seconds in the int64 range; "+
			"unset the variable to use the current time: %w", sourceDateEpochEnv, raw, err)
	}
	return &epoch, nil
}

func creationDate(epoch int64) string {
	// Bound the numeric input before constructing a time.Time: some int64 Unix
	// seconds overflow Go's internal time representation and produce bogus dates.
	if epoch < minCreationDateUnix || epoch > maxCreationDateUnix {
		return creationDateUnavailable
	}
	return time.Unix(epoch, 0).UTC().Format(time.RFC3339)
}

func newPackCmd() *cobra.Command {
	var flags builder.BuildOptions
	var (
		appName, targetOS, targetArch string
		rawVariants, rawCompression   []string
	)

	cmd := &cobra.Command{
		Use:   "pack [--manifest <file> | [--stub <stub>] -v <level>=<path> ... -o <output>]",
		Short: "Package multiple Go microarchitecture binaries into a single fat binary",
		Long: `Package multiple Go microarchitecture binaries into a single fat binary.
Set SOURCE_DATE_EPOCH to signed integer Unix seconds to supply reproducible creation metadata.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			epoch, err := sourceDateEpoch()
			if err != nil {
				return err
			}
			flags.CreatedUnix = epoch
			if err := validateEmptyStubFlags(cmd, flags); err != nil {
				return err
			}
			if flags.SkipELFValidation {
				_, _ = fmt.Fprintln(cmd.ErrOrStderr(),
					"[microfat] Warning: ELF platform, architecture and declared ABI validation explicitly skipped via --skip-elf-validation")
			}
			if flags.ManifestPath != "" {
				return runManifestPack(cmd, flags, rawCompression)
			}
			return runDirectPack(cmd, flags, appName, targetOS, targetArch, rawVariants, rawCompression)
		},
	}

	cmd.Flags().StringVarP(&flags.ManifestPath, "manifest", "m", "", "Path to YAML or JSON build manifest file")
	cmd.Flags().StringVar(&flags.StubPath, "stub", "", "Path to microfat launcher stub binary")
	cmd.Flags().StringVarP(&flags.OutputPath, "output", "o", "", "Destination output path for the fat binary")
	cmd.Flags().StringVar(&appName, "name", "", "Application name")
	cmd.Flags().StringVar(&targetOS, "os", "linux", "Target operating system (linux)")
	cmd.Flags().StringVar(&targetArch, "arch", "amd64", "Target architecture (amd64 or arm64)")
	cmd.Flags().StringArrayVarP(&rawVariants, "variant", "v", nil,
		"Variant mapping in <level>=<path> format (e.g. -v v1=bin/v1 -v v3=bin/v3 for amd64, or -v v8.0=bin/v80 -v v8.2=bin/v82 for arm64)")
	cmd.Flags().IntVarP(&flags.Concurrency, "concurrency", "j", 0, "Number of concurrent compiler workers (when using --manifest)")

	bindManifestBuildFlags(cmd, &flags, &rawCompression)
	return cmd
}

// An omitted flag must not override a declarative manifest setting. Zero lets
// the builder retain the manifest value (and the packer supply its default).
func explicitDictionarySize(cmd *cobra.Command, size int) int {
	if cmd.Flags().Changed("dict-size") {
		return size
	}
	return 0
}

func runManifestPack(cmd *cobra.Command, flags builder.BuildOptions, rawCompression []string) error {
	m, err := builder.LoadManifest(flags.ManifestPath)
	if err != nil {
		return err
	}
	flags.VariantCompression, err = manifestVariantCompression(m, rawCompression)
	if err != nil {
		return err
	}
	opts := manifestBuildOptions(cmd, flags)
	fmt.Printf("Compiling and packaging PGO matrix for '%s' (%s/%s)...\n", m.AppName, m.TargetOS, m.TargetArch)
	res, err := builder.BuildAndPack(cmd.Context(), m, opts)
	if err != nil {
		return fmt.Errorf("packaging error: %w", err)
	}
	fmt.Printf("Successfully packaged %d variants into '%s':\n", len(res.Index.Variants), res.OutputPath)
	for _, v := range res.Index.Variants {
		fmt.Printf("  • %-6s [%s] -> uncompressed: %d B | compressed: %d B\n", v.Level, v.Compression, v.UncompressedSize, v.CompressedSize)
	}
	if err := printABIReport(cmd.OutOrStdout(), res.ABIReport); err != nil {
		return fmt.Errorf("artifact published successfully to %s, but printing ABI report failed: %w", res.OutputPath, err)
	}
	return nil
}

func runDirectPack(
	cmd *cobra.Command,
	flags builder.BuildOptions,
	appName, targetOS, targetArch string,
	rawVariants, rawCompression []string,
) error {
	targetOS, err := pack.NormalizeTargetOS(targetOS)
	if err != nil {
		return err
	}
	if targetArch == "" {
		targetArch = microarch.ArchAMD64
	}
	targetArch, err = pack.NormalizeTargetArch(targetArch)
	if err != nil {
		return err
	}
	variants, err := parseRawVariants(rawVariants)
	if err != nil {
		return err
	}
	levels := make([]string, 0, len(variants))
	for level := range variants {
		levels = append(levels, level)
	}
	flags.VariantCompression, err = parseVariantCompression(rawCompression, targetArch, levels)
	if err != nil {
		return err
	}
	actualStubPath, err := builder.ResolveStubWithOptions(builder.ResolveStubOptions{
		CLIStub:    flags.StubPath,
		CLIProfile: flags.StubProfile,
		TargetArch: targetArch,
		WarnFunc:   cmdWarnFunc(cmd),
	})
	if err != nil {
		return fmt.Errorf("launcher stub resolution failed: %w (provide --stub flag or specify --manifest)", err)
	}
	if flags.StubPath == "" {
		_, _ = fmt.Fprintf(cmd.ErrOrStderr(),
			"Using auto-discovered launcher stub: %s\n", actualStubPath)
	}
	if flags.OutputPath == "" {
		return errors.New("required flag(s) \"output\" not set (or specify --manifest)")
	}
	if len(rawVariants) == 0 {
		return errors.New("required flag(s) \"variant\" not set (or specify --manifest)")
	}

	opts := pack.DefaultOptions()
	opts.StubPath = actualStubPath
	opts.OutputPath = flags.OutputPath
	opts.AppName = appName
	if targetOS != "" {
		opts.TargetOS = targetOS
	}
	if targetArch != "" {
		opts.TargetArch = targetArch
	}
	opts.Variants = variants
	opts.VariantCompression = flags.VariantCompression
	opts.CreatedUnix = flags.CreatedUnix
	opts.SkipELFValidation = flags.SkipELFValidation
	opts.AllowMixedABI = flags.AllowMixedABI
	var artifactABIReport *pack.ArtifactABIReport
	opts.ABIReportCallback = func(report *pack.ArtifactABIReport) {
		artifactABIReport = report
	}
	if flags.Profile != "" {
		opts.Profile = flags.Profile
	}
	if flags.Compression != "" {
		opts.Compression = flags.Compression
		if _, inlineLevel := codec.ParseCompressionSpec(flags.Compression); inlineLevel != "" {
			opts.CompressionLevel = inlineLevel
		}
	}
	if flags.CompressionLevel != "" {
		opts.CompressionLevel = flags.CompressionLevel
	}
	if flags.EnableDict {
		opts.EnableDict = flags.EnableDict
	}
	if flags.DictSize > 0 {
		opts.DictSize = flags.DictSize
	}
	if flags.FormatVersion != 0 {
		opts.FormatVersion = flags.FormatVersion
	}
	opts.WarnFunc = func(format string, args ...any) {
		var msg string
		if len(args) == 0 {
			msg = format
		} else {
			msg = fmt.Sprintf(format, args...)
		}
		_, _ = fmt.Fprintf(cmd.ErrOrStderr(), "[microfat:warn] %s\n", msg)
	}

	fmt.Printf("Packaging fat binary '%s'...\n", flags.OutputPath)
	idx, err := pack.Pack(opts)
	if err != nil {
		return fmt.Errorf("packaging error: %w", err)
	}

	fmt.Printf("Successfully packaged %d variants into '%s':\n", len(idx.Variants), flags.OutputPath)
	for _, v := range idx.Variants {
		fmt.Printf("  • %-6s [%s] -> uncompressed: %d B | compressed: %d B\n", v.Level, v.Compression, v.UncompressedSize, v.CompressedSize)
	}
	if err := printABIReport(cmd.OutOrStdout(), artifactABIReport); err != nil {
		return fmt.Errorf("artifact published successfully to %s, but printing ABI report failed: %w", flags.OutputPath, err)
	}
	return nil
}

// Copy flag values before applying per-invocation streams and manifest defaults.
// An omitted dictionary size must not overwrite the manifest's explicit value.
func manifestBuildOptions(cmd *cobra.Command, flags builder.BuildOptions) builder.BuildOptions {
	flags.DictSize = explicitDictionarySize(cmd, flags.DictSize)
	flags.Stdout = cmd.OutOrStdout()
	flags.Stderr = cmd.ErrOrStderr()
	if flags.WarnFunc == nil {
		flags.WarnFunc = cmdWarnFunc(cmd)
	}
	return flags
}

func bindManifestBuildFlags(cmd *cobra.Command, flags *builder.BuildOptions, rawCompression *[]string) {
	cmd.Flags().StringVar(&flags.StubProfile, "stub-profile", "", "Launcher stub profile: full (default) or minimal")
	cmd.Flags().StringVar(&flags.Profile, "profile", "", "Compression profile preset: latency, balanced, size")
	cmd.Flags().StringVar(&flags.Compression, "compression", "", "Compression algorithm: lz4, zstd, none (e.g. lz4 or zstd:11)")
	cmd.Flags().StringVar(&flags.CompressionLevel, "compression-level", "",
		"Compression level override: fastest, default, better, best, or number")
	cmd.Flags().StringArrayVar(rawCompression, "variant-compression", nil,
		"Per-variant override in level=codec[:level] format (repeat for each variant; e.g. v1=none or v3=zstd:best)")
	cmd.Flags().BoolVar(&flags.EnableDict, "dict", false, "Enable shared Zstandard dictionary compression across variants")
	cmd.Flags().BoolVar(&flags.EnableDict, "zstd-dict", false, "Alias for --dict")
	cmd.Flags().IntVar(&flags.DictSize, "dict-size", codec.DefaultDictSize,
		"Target shared Zstandard dictionary size in bytes (default: 112 KB)")
	cmd.Flags().IntVar(&flags.FormatVersion, "format-version", format.FormatVersionCurrent,
		"Binary format specification version (1 for JSON, 2 for binary table)")
	cmd.Flags().BoolVar(&flags.SkipELFValidation, "skip-elf-validation", false,
		"Skip ELF platform, architecture and executable structure validation")
	cmd.Flags().BoolVar(&flags.AllowMixedABI, "allow-mixed-abi", false,
		"Allow packaging variants with differing declared ABI requirements (interpreters, dependencies, symbol versions)")
	cmd.Flags().BoolVar(&flags.KeepIntermediates, "keep-intermediates", false, "Keep intermediate compiled variant ELF binaries")
	cmd.Flags().StringVar(&flags.GoBinary, "go-binary", "", "Path to Go toolchain binary (defaults to $GO or 'go')")
}

func newPgoPackCmd() *cobra.Command {
	var flags builder.BuildOptions
	var rawCompression []string

	cmd := &cobra.Command{
		Use:   "pgo-pack --manifest <manifest-file> [-o <output>]",
		Short: "Compile and package microarchitecture variants with Profile-Guided Optimization (PGO)",
		Long: `pgo-pack automates concurrent Go compilation across multiple microarchitecture levels
(e.g., v1, v3, v4 on AMD64 or v8.0, v8.2 on ARM64) with Profile-Guided Optimization (-pgo) profiles,
then packages them into a self-dispatching microfat binary.
Set SOURCE_DATE_EPOCH to signed integer Unix seconds to supply reproducible creation metadata.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			epoch, err := sourceDateEpoch()
			if err != nil {
				return err
			}
			flags.CreatedUnix = epoch
			if err := validateEmptyStubFlags(cmd, flags); err != nil {
				return err
			}
			if flags.SkipELFValidation {
				_, _ = fmt.Fprintln(cmd.ErrOrStderr(),
					"[microfat] Warning: ELF platform, architecture and declared ABI validation explicitly skipped via --skip-elf-validation")
			}
			if flags.ManifestPath == "" && len(args) > 0 {
				flags.ManifestPath = args[0]
			}
			if flags.ManifestPath == "" {
				return errors.New("manifest file path is required (use --manifest <file> or specify as first argument)")
			}

			m, err := builder.LoadManifest(flags.ManifestPath)
			if err != nil {
				return err
			}
			flags.VariantCompression, err = manifestVariantCompression(m, rawCompression)
			if err != nil {
				return err
			}

			opts := manifestBuildOptions(cmd, flags)

			fmt.Printf("Compiling and packaging PGO matrix for '%s' (%s/%s)...\n", m.AppName, m.TargetOS, m.TargetArch)
			res, err := builder.BuildAndPack(cmd.Context(), m, opts)
			if err != nil {
				return fmt.Errorf("PGO matrix packaging failed: %w", err)
			}

			fmt.Printf("\nSuccessfully built and packaged %d variants into '%s':\n", len(res.Index.Variants), res.OutputPath)
			for _, v := range res.Index.Variants {
				pgoFlag := res.VariantPGOApplied[v.Level]
				fmt.Printf("  • %-6s [%s] (pgo: %-20s) -> uncompressed: %d B | compressed: %d B\n",
					v.Level, v.Compression, pgoFlag, v.UncompressedSize, v.CompressedSize)
			}
			if err := printABIReport(cmd.OutOrStdout(), res.ABIReport); err != nil {
				return fmt.Errorf("artifact published successfully to %s, but printing ABI report failed: %w", res.OutputPath, err)
			}
			return nil
		},
	}

	cmd.Flags().StringVarP(&flags.ManifestPath, "manifest", "m", "", "Path to YAML or JSON build manifest file")
	cmd.Flags().StringVarP(&flags.OutputPath, "output", "o", "", "Destination output path for the fat binary (overrides manifest)")
	cmd.Flags().StringVar(&flags.StubPath, "stub", "", "Path to microfat launcher stub binary (overrides manifest)")
	cmd.Flags().IntVarP(&flags.Concurrency, "concurrency", "j", 0, "Number of concurrent compiler workers (defaults to NumCPU)")

	bindManifestBuildFlags(cmd, &flags, &rawCompression)
	return cmd
}

func printABIReport(out io.Writer, report *pack.ArtifactABIReport) error {
	return pack.RenderABIReport(out, report)
}

func formatVersionName(version int) string {
	switch version {
	case format.FormatVersion1:
		return "legacy JSON manifest"
	case format.FormatVersion2:
		return "compact binary table"
	default:
		return "unknown"
	}
}
