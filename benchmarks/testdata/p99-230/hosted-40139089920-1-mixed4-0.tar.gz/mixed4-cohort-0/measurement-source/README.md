# Microfat

[![Go Reference](https://pkg.go.dev/badge/github.com/EpicBlackWolfZ/microfat.svg)](https://pkg.go.dev/github.com/EpicBlackWolfZ/microfat)
[![GitHub Release](https://img.shields.io/github/v/release/EpicBlackWolfZ/microfat?logo=github)](https://github.com/EpicBlackWolfZ/microfat/releases)
[![CI Status](https://img.shields.io/github/actions/workflow/status/EpicBlackWolfZ/microfat/ci.yml?branch=main&logo=github&label=CI)](https://github.com/EpicBlackWolfZ/microfat/actions/workflows/ci.yml)
[![CodeQL](https://img.shields.io/github/actions/workflow/status/EpicBlackWolfZ/microfat/codeql.yml?branch=main&logo=github&label=CodeQL)](https://github.com/EpicBlackWolfZ/microfat/actions/workflows/codeql.yml)
[![CodeFactor](https://www.codefactor.io/repository/github/epicblackwolfz/microfat/badge)](https://www.codefactor.io/repository/github/epicblackwolfz/microfat)
[![codecov](https://codecov.io/gh/EpicBlackWolfZ/microfat/branch/main/graph/badge.svg)](https://codecov.io/gh/EpicBlackWolfZ/microfat)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)

**Microfat** combines multiple CPU microarchitecture-specific ELF binaries (`v1`, `v2`, `v3`, `v4` or `v8.0`..`v9.5`) into a single, self-dispatching Linux executable with no persistent launcher process, automatic container resource tuning (`GOMEMLIMIT` & `GOMAXPROCS`), and payload integrity verification.

---

## Key Highlights

- 🚀 **Dynamic Hardware Dispatch**: Automatically probes host CPU instruction extensions (`AVX2`, `FMA`, `BMI2`, `AVX-512`, `SVE`, `SVE2`) and selects a compatible variant according to the configured policy.
- ⚡ **Zero Persistent Process Overhead**: Replaces the launcher through `syscall.Exec` using a verified existing cache entry or sealed Linux `memfd` (no wrapper daemon, PID 1 preserved in containers).
- 🛡️ **Container Auto-Tuning**: Automatically parses Linux cgroup v1 & v2 limits to set a soft Go-runtime memory budget (`GOMEMLIMIT`) and CPU parallelism (`GOMAXPROCS`); neither guarantees freedom from OOM kills or CPU throttling.
- ✂️ **Flexible Lifecycle Modes**:
  - **Universal Fat Binary**: Distribute one Linux executable per architecture, selecting among the included compatible variants.
  - **Trimmed Fat Binary (`--microfat:trim` / `microfat trim`)**: Discard unneeded variants on disk while retaining launcher auto-tuning and cache/memfd dispatch.
  - **Raw Native ELF (`--microfat:optimize`)**: Permanently specialize to raw uncompressed ELF machine code with no microfat launcher or decompression stage; normal ELF startup still applies.
- 🔒 **Payload Integrity Verification**: 56-byte trailer with SHA-256 index hashing and variant checksum validation.
- 📦 **Shared Inter-Variant Dictionary**: Multi-variant compression with trained Zstandard dictionaries; measure size savings on your own variants.

> [!NOTE]
> **Payload Integrity vs Producer Authenticity**: Embedded SHA-256 digests provide payload integrity verification; they do not authenticate the producer of the fat binary. To establish provenance and origin authenticity in production pipelines, sign fat executables with external tools such as Sigstore Cosign or GPG. See [SECURITY.md](SECURITY.md#6-payload-integrity-vs-producer-authenticity-hashing-vs-signing) for security architecture details.

---

## Documentation Guide

Explore the specialized deep-dive documentation in the [`docs/`](docs/) and [`examples/`](examples/) directories:

| Guide | Description |
| :--- | :--- |
| [**v0.3.0 Release Notes**](docs/releases/v0.3.0.md) | Verified installation, updates, Linux Homebrew and release acceptance evidence. |
| [**v0.3.1 Release Notes**](docs/releases/v0.3.1.md) | Installer and dictionary fixes, dependency updates, and release acceptance evidence. |
| [**v0.2.5 Release Notes**](docs/releases/v0.2.5.md) | Go/Task tooling, modern SBOMs, staged CI and benchmark correctness. |
| [**Release Artifacts Guide**](docs/release-artifacts.md) | Universal fat archives, bundled launcher stubs, and Format v1 deprecation. |
| [**Native Runtime Qualification**](docs/runtime-qualification.md) | Concurrent cache and kernel-policy testing, replay, and signed-candidate release gates. |
| [**Production Roadmap**](docs/roadmap.md) | Release priorities, safety gates and experimental scope. |
| 📊 [**Demo & Benchmark Suite**](examples/demo/README.md) | Multi-workload benchmark application testing SIMD vector math, JSON/Zstd processing, and concurrent workers. |
| [**Reproducible Server Benchmarks**](docs/benchmarks/README.md) | Paired native/fat server trials, external Fortio load, resource telemetry, and verifiable evidence. |
| 📖 [**Architecture & Binary Format**](docs/architecture.md) | Technical specification of the 56-byte trailer, Format v2 binary table layout, shared dictionaries, and `memfd_create` lifecycle. |
| 💻 [**CLI & Launcher Stub Reference**](docs/cli-reference.md) | Complete reference for `microfat` CLI commands, flags, launcher stub meta-commands, exit codes, and environment variables. |
| ⚙️ [**Container Resource Auto-Tuning**](docs/runtime-tuning.md) | Linux cgroup v1/v2 auto-tuning (`GOMEMLIMIT` / `GOMAXPROCS`), GC mechanics, and workload `GOGC` tuning recipes. |
| [**Application Runtime Metadata**](docs/runtimeinfo.md) | Supported read-only accessor, source/unknown semantics, and runnable Prometheus/OpenTelemetry recipes. |
| [**Launcher Diagnostics Cost**](docs/disabled-telemetry-snapshot-results.md) | Both clock-removal evaluations, retained implementation, and reproducible process/allocation evidence. |
| 🔄 [**Binary Lifecycle Modes**](docs/lifecycle-modes.md) | Comprehensive comparison and workflows for Universal Fat, Trimmed Fat, Raw Native ELF, and node cache prewarming. |
| 🚀 [**Advanced Optimizations & Compression Matrix**](docs/advanced-optimizations.md) | AVX-512 downclocking mitigation, Compression Decision Matrix, declarative PGO matrices, and high-performance C allocators. |
| 🩺 [**Troubleshooting & Runbook**](docs/troubleshooting.md) | Diagnostic workflows with `microfat doctor`, seccomp `memfd_create` remediation, read-only rootfs fallback, and FAQ. |

---

### Checking for updates

Starting with v0.3.0, `microfat update --check` reports the latest stable release without changing
the installation. Use `microfat update` to authenticate and apply an update to an installer-owned
installation, or `brew upgrade microfat` for Homebrew. Ordinary commands never check in the background.
See [update options and recovery](docs/installation.md#explicit-release-checks-and-updates).


## Quick Start

### 1. Installation

#### Homebrew on Linux

The official shared tap is [`EpicBlackWolfZ/homebrew-tap`](https://github.com/EpicBlackWolfZ/homebrew-tap).
The authenticated v0.3.1 recipe is available and its public installation passed on native amd64 and arm64.
The Linux cask installs the CLI and both launcher stubs together:

```bash
brew install --cask EpicBlackWolfZ/tap/microfat
brew upgrade --cask microfat
brew uninstall --cask microfat
```

Supported platforms are Linux amd64 and arm64. Qualification follows `HOMEBREW_SOURCE` in
[the shared tool definitions](.config/tool-versions.env).
See [Homebrew installation and recovery](docs/installation.md#homebrew-linux-amd64-and-arm64) and
the [v0.3.1 acceptance record](docs/releases/v0.3.1.md#release-acceptance).

#### Verified Linux installer and release archives

The v0.3.1 bootstrap authenticates its pinned verifier and v0.3.1 native helper before the helper
downloads and verifies the selected product release. It installs the CLI and both companions
coherently into user-owned generation storage. Public bootstrap installation passed in fresh nonroot
containers on native amd64 and arm64 without Go or preinstalled Cosign. Latest/pinned installation,
reinstall, authenticated product hashes, memfd/cache execution and conservative uninstall passed.

See [installation and recovery](docs/installation.md) for trusted source-helper use, pinned/latest versions,
custom destinations, manual-install migration and uninstall. See the [release verification contract](docs/release-verification.md)
before executing any downloaded program. The [release artifact guide](docs/release-artifacts.md) describes
the two architecture archives, each containing the CLI plus both launcher stubs. The
[v0.3.1 acceptance record](docs/releases/v0.3.1.md#release-acceptance) identifies the current release gates.
The [v0.3.0 record](docs/releases/v0.3.0.md#release-acceptance) retains the completed historical public checks.

#### Via Go Toolchain
```bash
go install github.com/EpicBlackWolfZ/microfat/cmd/microfat@latest
go install github.com/EpicBlackWolfZ/microfat/cmd/microfat-stub@latest
```

### 2. Detect Host CPU Capabilities & Environment Readiness

```bash
# Check CPU microarchitecture level
microfat detect

# Comprehensive host environment verification (CPU, memfd, cache, cgroups)
microfat doctor

# Machine-readable JSON output for CI/CD gating
microfat doctor --json
```

Illustrative output (values depend on the host and installed version):

```text
=== Microfat Host Environment Doctor ===

[✔] Host CPU Microarchitecture
    • OS/Arch:        linux/amd64
    • Detected Level: v3
    • Key Features:   cx16, popcnt, sse3, ssse3, sse4.1, sse4.2, avx, avx2, bmi1, bmi2, fma, osxsave, f16c, lzcnt, movbe
    • AVX-512 Status: not present (no downclock risk)

[✔] In-Memory Execution (memfd_create)
    • Kernel Support: Available (Linux 6.8.0-generic)
    • Seccomp Filter: Permitted

[✔] Disk Cache Execution Fallback
    • Resolved Path:  /home/deployer/.cache/microfat
    • Permissions:    0700 (read/write OK)

[✔] Container Resource Limits (cgroup v2)
    • Memory Limit:   2147483648 B (2.00 GiB)
    • CFS CPU Quota:  4.00 cores
    • Auto GOMEMLIMIT: 1932735283 B (~1.80 GiB)
    • Auto GOMAXPROCS: 4

[✔] Toolchain & Version Metadata
    • Version:        v0.2.1
    • Commit:         7cba82c
    • Build Date:     2026-09-02T20:00:00Z

Summary: Environment is fully ready for high-performance Microfat dispatch!
```

### 3. Compile & Package a Fat Binary

Packaging targets Linux amd64 or arm64. Direct `--os` and manifest `target_os` accept only Linux
(case-insensitively), with Linux as the default. ELF validation rejects conflicting OSABI values
and embedded Go `GOOS` settings in both payloads and custom launcher stubs. Generic SysV ELF
(`ELFOSABI_NONE`) remains accepted because Linux binaries commonly use it; this value alone
does not establish operating-system compatibility or the availability of a required loader or libc.
`--skip-elf-validation` explicitly bypasses ELF evidence checks but does not enable other target systems.

#### AMD64 (x86_64) Packaging
```bash
# 1. Compile variants with Go microarchitecture targets
GOAMD64=v1 go build -o bin/app_v1 main.go
GOAMD64=v3 go build -o bin/app_v3 main.go
GOAMD64=v4 go build -o bin/app_v4 main.go

# 2. Package with microfat
microfat pack \
  --stub bin/microfat-stub \
  --name myapp \
  -v v1=bin/app_v1 \
  -v v3=bin/app_v3 \
  -v v4=bin/app_v4 \
  -o bin/myapp
```

#### ARM64 (aarch64) Packaging
```bash
# 1. Compile ARM64 variants (Graviton 2/3/4, Apple Silicon, Ampere)
GOOS=linux GOARCH=arm64 GOARM64=v8.0 go build -o bin/app_arm64_v8.0 main.go
GOOS=linux GOARCH=arm64 GOARM64=v8.2 go build -o bin/app_arm64_v8.2 main.go
GOOS=linux GOARCH=arm64 GOARM64=v9.0 go build -o bin/app_arm64_v9.0 main.go

# 2. Package universal ARM64 fat binary with shared dictionary compression
microfat pack \
  --stub bin/microfat-stub-arm64 \
  --name myapp \
  --arch arm64 \
  --dict \
  -v v8.0=bin/app_arm64_v8.0 \
  -v v8.2=bin/app_arm64_v8.2 \
  -v v9.0=bin/app_arm64_v9.0 \
  -o bin/myapp-arm64
```

#### Declarative PGO Matrix Packaging (`microfat pgo-pack`)
Automate variant compilation and Profile-Guided Optimization packaging in a single step using a YAML/JSON manifest:

```yaml
# pgo.yaml
name: myapp
package: ./cmd/myapp
output: bin/myapp
stub: bin/microfat-stub
variants:
  - level: v1
    pgo: "off"
  - level: v3
    pgo: profiles/v3.pgo
  - level: v4
    pgo: profiles/v4.pgo
```

```bash
microfat pgo-pack --manifest pgo.yaml
```

### 4. Try the Demonstration & Benchmark Suite

```bash
# Build and run the AMD64 demo workloads:
task demo

# Build the ARM64 demo fat binary:
task demo-arm64

# Run the standard benchmark suite (~110ms):
task bench

# Run the heavy sustained compute benchmark suite (~500ms):
task bench-heavy

# Run the ultra sustained compute benchmark suite (5-15s per run):
task bench-ultra
```

---

## Standalone Container Tuning (`runtimeinit`)

For Go services running directly in Docker or Kubernetes without the fat binary wrapper, microfat provides both zero-code startup auto-tuning via `runtimeinit/autoload` and programmatic tuning via `runtimeinit`:

### Zero-Code Startup Auto-Tuning
Add a blank import to auto-tune `debug.SetMemoryLimit` (90% container ceiling) and `runtime.GOMAXPROCS` (CFS quota) before `main()` executes:

```go
package main

import (
	_ "github.com/EpicBlackWolfZ/microfat/runtimeinit/autoload"
)

func main() {
	// GOMEMLIMIT and GOMAXPROCS are auto-configured
}
```

### Programmatic Auto-Tuning
For explicit control, custom profiles, or headroom overrides:

```go
package main

import (
	"github.com/EpicBlackWolfZ/microfat/runtimeinit"
)

func main() {
	res := runtimeinit.AutoTune(
		runtimeinit.WithProfile(runtimeinit.ProfileLatencyCritical),
		runtimeinit.WithMemoryRatio(0.85),
	)
	_ = res
}
```

To keep memory and GC tuning while preserving Go's native CPU adaptation, set
`MICROFAT_CPU_POLICY=native` for the launcher or autoload, or use the programmatic option:

```go
res := runtimeinit.AutoTune(runtimeinit.WithCPUPolicy(runtimeinit.CPUPolicyNative))
```

The default remains `static` (floor-rounded quota, minimum one CPU). Native mode preserves
explicit CPU settings and does not re-enable adaptation disabled by an earlier setter or
`GODEBUG`. See [CPU policies and Go-version caveats](docs/runtime-tuning.md#b-gomaxprocs-cpu-quota).

### Dry-Run Simulation (`WithDryRun`)
To simulate container resource tuning and inspect computed parameters without mutating active Go runtime state (`debug.SetMemoryLimit`, `runtime.GOMAXPROCS`, `debug.SetGCPercent`):

```go
res := runtimeinit.AutoTune(
	runtimeinit.WithDryRun(true),
	runtimeinit.WithProfile(runtimeinit.ProfileLatencyCritical),
)
// res.DryRun is true, res.MemLimitApplied is false, res.GOMEMLIMIT and res.GOMAXPROCS are populated
```

### Locating Original Executable & Sibling Assets (`runtimeinit.Executable`)
When running packaged inside a microfat binary, `os.Executable()` identifies the extracted payload: a content-addressed cache path in cache mode or `memfd:microfat_payload (deleted)` in memfd mode. Use `runtimeinit.Executable()` to retrieve the path to the original fat binary for locating neighboring configuration files, assets, plugins, or sibling CLI binaries:

```go
exePath, err := runtimeinit.Executable()
if err != nil {
	log.Fatalf("cannot determine executable path: %v", err)
}
configPath := filepath.Join(filepath.Dir(exePath), "config.yaml")
```

> [!NOTE]
> **Authenticity Boundary**: `MICROFAT_ORIGINAL_EXE` and `runtimeinit.Executable()` are informational asset-resolution hints. They must NOT be used as cryptographic identity, access-control tokens, or trusted binary origin claims.

---

## Application Runtime Metadata (`runtimeinfo`)

Read launcher hints, current environment configuration and observed Go runtime
settings through the standard-library-only `runtimeinfo.Read()` accessor. Missing
metadata stays explicit; cgroup recommendations do not imply applied tuning.
See the [field and source contract](docs/runtimeinfo.md) and the separate
[Prometheus/OpenTelemetry recipes](examples/runtimeinfo/README.md).

## Runtime Meta-Commands

Fat executables using the full launcher support reserved meta-commands for diagnostics and disk specialization:

```bash
# View host capabilities, cgroup limits, and embedded variants
./myapp --microfat:info

# Pre-extract selected compatible variant into cache (avoids decompression on a warm cache hit)
./myapp --microfat:prewarm

# Trim unneeded variants in-place (keeps stub & cgroup auto-tuning, reduces artifact size)
./myapp --microfat:trim

# Extract trimmed single-variant fat binary to a target path
./myapp --microfat:trim-to /usr/local/bin/myapp

# Permanently replace with raw uncompressed native ELF
./myapp --microfat:optimize

# Extract raw uncompressed native ELF to a target path
./myapp --microfat:optimize-to /usr/local/bin/myapp
```

---

## Environment Variable & Policy Configuration

| Variable | Default | Description |
| :--- | :--- | :--- |
| `MICROFAT_AUTOTUNE` | `1` / `true` | Set to `0` or `false` to disable automatic `GOMEMLIMIT` and `GOMAXPROCS` injection. |
| `MICROFAT_CPU_POLICY` | `static` | Use `native` to preserve Go CPU behavior while retaining independent memory and GC tuning. |
| `MICROFAT_MEM_RATIO` | `0.90` | Fraction of container cgroup memory limit to assign to `GOMEMLIMIT` (e.g. `0.85`). |
| `MICROFAT_GC_PROFILE` | `default` | Workload GC profile preset (`latency_critical`, `memory_constrained`, `batch_etl`, `adaptive`, `default`). |
| `MICROFAT_FORCE_LEVEL` | *(unset)* | Pin execution strictly to a specific level (`v1`, `v2`, `v3`, `v4`, `v8.0`..`v9.5`). Fails fast on incompatibility. |
| `MICROFAT_MAX_LEVEL` | *(unset)* | Cap selection ceiling level (e.g. `v3` or `v8.2`). |
| `MICROFAT_DISABLE_VARIANTS` | *(unset)* | Comma-separated list of variant levels to exclude from selection (e.g. `v4`). |
| `MICROFAT_POLICY` | *(unset)* | Preset policy name (`safe_avx512`, `no_downclock`). |
| `MICROFAT_AVX512_DOWNCLOCK_PROTECTION` | `0` / `false` | Enable automatic Intel Skylake-X / Cascade Lake Xeon downclocking mitigation. |
| `MICROFAT_EXEC_MODE` | *(unset: auto)* | Auto checks an existing verified cache entry, then sealed memfd on a miss; cold memfd denial can materialize cache. Explicit `memfd` bypasses cache and fails closed; `cache` materializes verified disk entries. |
| `MICROFAT_CACHE_DIR` | *(unset)* | Custom node cache directory (defaults to `$XDG_CACHE_HOME/microfat` or `~/.cache/microfat`). |
| `MICROFAT_VERIFY_CACHE` | *(ignored)* | Cache size, ownership, permissions and SHA-256 checks are mandatory on every hit; this variable cannot disable them. |
| `GOMEMLIMIT` | *(unset)* | If already set by the user or Kubernetes YAML, `microfat` **never** overrides it. |
| `GOMAXPROCS` | *(unset)* | If already set by the user or Kubernetes YAML, `microfat` **never** overrides it. |

The default `auto` mode performs a read-only lookup before creating a memfd. A valid hit executes
the same descriptor whose size, owner, mode and SHA-256 were checked, without decompressing the
source payload or dictionary. An absent directory/entry or corrupt safe regular entry remains
untouched and uses sealed memfd. A symlink, special file, foreign owner or unsafe entry mode is
rejected, as is an entry whose metadata cannot be inspected after a failed open. Cache hashing,
launcher work and normal ELF startup still have a cost.

If memfd creation, sealing or execution fails after a miss, auto may materialize and verify a disk
cache entry. If an existing verified cache entry cannot execute, auto tries sealed memfd once;
failure reports both attempts without retrying the cache. Corruption found during extraction
terminates dispatch. Explicit `cache` mode and prewarming can populate the cache; a successful cold
auto memfd launch does not. Read-only roots therefore work with a usable warm cache or permitted
sealed memfd, while cold cache fallback needs writable storage.

Cache execution trusts same-UID writers: pinning the descriptor prevents pathname substitution,
but the cached inode remains mutable. Use explicit `memfd` when immutable extracted storage is
required, and authenticate the complete distribution externally before execution. See the
[execution policy](docs/architecture.md#7-cache-first-auto-dispatch--descriptor-bound-execution)
and [security boundary](SECURITY.md#7-launcher-and-cache-deployment-boundary). The
[startup measurements](docs/cache-first-startup.md) compare complete cold and warm processes
across both formats, stub profiles and all codecs with identical tuning.

---

## Compression Profiles & CLI Integration

`microfat` provides three compression profiles to balance cold-start startup overhead against disk size and network transfer bandwidth:

| Profile | Codec | Trade-off |
| --- | --- | --- |
| `latency` | `none` / `lz4` | Avoid or reduce decompression work; larger artifacts |
| `balanced` (default) | `zstd` | Balance artifact size and startup work |
| `size` | `zstd:best` (+`--dict`) | Favor storage/transfer reduction; measure extraction cost |

Startup latency and compression ratios depend on the payload, host and execution mode.
The [complete-cost evaluation](docs/codec-policy-results.md) retains these defaults
after comparing fixed explicit settings, complete bytes, packing wall/CPU time
and full process completion. It preserves the failed telemetry-enabled cohort
and discloses unresolved codec memory attribution in the wait4 observations.
Warm verified-cache launches still hash payloads; they do not decompress them.

For full benchmarks and sizing recipes, see the [Advanced Optimizations Guide](docs/advanced-optimizations.md#4-compression-profiles--decision-matrix).

### Programmatic CLI Integration

External Go applications integrate through the supported CLI. Packages under `internal/` are
private to this repository; a public Go packaging API is not provided.

Run this program with four arguments: the CLI path, the matching launcher stub path, a native
baseline payload path, and the output path. The example targets Linux AMD64; use the matching
architecture and variant level for other targets.

```go
package main

import (
    "log"
    "os"
    "os/exec"
)

func main() {
    if len(os.Args) != 5 {
        log.Fatal("usage: pack-example CLI STUB PAYLOAD OUTPUT")
    }
    cmd := exec.Command(os.Args[1], "pack", "--stub", os.Args[2],
        "--os", "linux", "--arch", "amd64",
        "-v", "v1="+os.Args[3], "-o", os.Args[4])
    cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
    if err := cmd.Run(); err != nil {
        log.Fatalf("packaging failed: %v", err)
    }
}
```

Use absolute input paths when invoking this example from another working directory. The E2E suite
compiles and executes this exact snippet outside the module, then inspects, verifies and launches
its output. Measure process startup separately from sustained throughput; compare ISA specialization
with identical runtime settings, and evaluate tuning on/off as a separate experiment.

---

## GoReleaser Integration

Add microarchitecture matrix builds to your [`.goreleaser.yaml`](.goreleaser.yaml) for both AMD64 and ARM64:

```yaml
version: 2

builds:
  - id: myapp-amd64
    main: ./main.go
    binary: myapp
    goos: [linux]
    goarch: [amd64]
    goamd64: [v1, v3, v4]

  - id: myapp-arm64
    main: ./main.go
    binary: myapp
    goos: [linux]
    goarch: [arm64]
    goarm64: [v8.0, v8.2, v9.0]
```

---

## Development & Developer Workflow

All daily development operations use [Task](https://taskfile.dev/) through the root `Taskfile.yml`.
Install the version in [the shared tool pins](.config/tool-versions.env) with
`source .config/tool-versions.env && go install github.com/go-task/task/v3/cmd/task@v${TASK_VERSION}` and put
`$(go env GOPATH)/bin` on PATH. See [contributor setup](CONTRIBUTING.md#3-development-prerequisites--setup)
for required validation tools.

```bash
# View all targets and descriptions (respects NO_COLOR=1 and COLOR=0)
task help

# Run complete verification pipeline: tidy-check, fmt-check, lint, vuln, test, coverage gate, build
task all

# Format code across the repository with $(GOFMT) -s
task fmt

# Verify all Go source files are formatted cleanly (non-mutating)
task fmt-check

# Run Go API modernizations ('go fix'), linter auto-fixes, and format code
task fix

# Verify Go module dependencies are tidy (non-mutating 'go mod tidy -diff')
task tidy-check

# Run tests with Go 1.27 goroutine leak detection enabled (MICROFAT_TEST_LEAKS=1)
task test-leaks

# Check for Go 1.27 goroutine leaks on the running benchmark workload
task check-leaks

# Run regression tests for developer workflows (port safety, formatting, TTY detection)
task test-dx

# Open interactive browser UI for pprof profiles (heap, cpu, goroutine, allocs, mutex, block, goroutineleak)
# (block and mutex sampling rates are enabled only when PROFILE=block or PROFILE=mutex)
task pprof PROFILE=heap
task pprof PROFILE=block PORT=6061 HTTP_PORT=8081

# Verify finished fat binary stub commands (info, optimize-to, trim-to, prewarm)
task demo-check
```

> **Terminal Detection & Port Safety**:
> - Piped or redirected stdout automatically disables ANSI escapes and uses ASCII markers (`[OK]`, `[FAIL]`). Use `NO_COLOR=1` or `COLOR=0` to force disable colors.
> - Profiling targets check port occupancy before spawning servers and fail cleanly without terminating unrelated processes. Cleanup sends graceful `SIGTERM` before `SIGKILL` strictly to target-spawned child processes.
> - Developer workflow regressions (`test-dx`, `test-leaks`, `check-leaks`, `demo-check`) are CI-enforced in GitHub Actions.

---

## License

Apache 2.0
